import sys
import re

def sanitize_for_bigquery_dataset(name: str) -> str:
    """
    Sanitize a string (e.g., a GitHub branch name) to be a valid BigQuery dataset name.
    - Only letters (a-z, A-Z), numbers (0-9), and underscores (_)
    - Must start with a letter or underscore
    - Max length 1024
    """
    if not name:
        return ""
    sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', name)
    if not re.match(r'^[a-zA-Z_]', sanitized):
        sanitized = '_' + sanitized
    return sanitized[:1024]

if __name__ == "__main__":
    branch_name = sys.argv[1] if len(sys.argv) > 1 else ""
    print(sanitize_for_bigquery_dataset(branch_name))
