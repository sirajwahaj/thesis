"""
Improvement opportunity: remove once the Fivetran dbt run cache package is published to PyPI and available on the default index.

This script extracts the url values from the [[tool.uv.index]] blocks in pyproject.toml and prints them in the format:
--extra-index-url <url>, which is compatible with requirements.txt files.

This was needed for IN-1341 when the dbt run cache package was not yet published to PyPI

Usage (first line deletes existing --extra-index-url lines from requirements.txt, second line appends the new indexes):
    sed -i '' '/^--extra-index-url /d' requirements.txt
    python3 path/to/extract_uv_indexes_for_requirements.py >> requirements.txt

"""
import toml

with open("pyproject.toml") as f:
    data = toml.load(f)

# Handles both single and multiple [[tool.uv.index]] blocks
indexes = data.get("tool", {}).get("uv", {}).get("index", [])
if not isinstance(indexes, list):
    indexes = [indexes]

for idx in indexes:
    url = idx.get("url")
    if url:
        print(f"--extra-index-url {url}")