#!/bin/bash

# This script deletes all 'runner' SSH keys stored in compute engine metadata.

# These keys are created by workflows every time they are run. When 400 keys are created, a prompt appears asking if keys can be deleted. However, the workflows don't type yes, so they would break.

# Instead, these workflows now execute this script at the end:
# * deploy_cube_core.yml
# * deploy_dagster_oss.yml

set -euo pipefail

GCP_PROJECT_ID=insighta-021324

echo "Checking for gcloud CLI"
if ! command -v gcloud &> /dev/null; then
  echo "gcloud not found. Installing Google Cloud SDK"
  sudo apt-get update && sudo apt-get install -y curl apt-transport-https ca-certificates gnupg
  echo "deb [signed-by=/usr/share/keyrings/cloud.google.gpg] https://packages.cloud.google.com/apt cloud-sdk main" | \
    sudo tee -a /etc/apt/sources.list.d/google-cloud-sdk.list
  curl https://packages.cloud.google.com/apt/doc/apt-key.gpg | sudo apt-key --keyring /usr/share/keyrings/cloud.google.gpg add -
  sudo apt-get update && sudo apt-get install -y google-cloud-sdk
else
  echo "gcloud CLI is already installed"
fi

echo "Authenticating to GCP with service account key file 'gcp-key.json'"
gcloud auth activate-service-account --key-file=gcp-key.json
gcloud config set project "$GCP_PROJECT_ID"

echo "Fetching current SSH keys from project metadata"
current_keys=$(gcloud compute project-info describe --project "$GCP_PROJECT_ID" --format="get(commonInstanceMetadata.items[ssh-keys])")

filtered_keys=$(echo "$current_keys" | grep -v '^runner:' || true)

echo "Updating project metadata without runner keys"
gcloud compute project-info add-metadata --project "$GCP_PROJECT_ID" --metadata "ssh-keys=$filtered_keys"

echo "SSH keys called runner deleted from GCP project metadata."