---
name: pull-requests
description: Use this skill for any PR operation.
---

# Pull Request Guide

## GitHub CLI

You should study skill "github" to learn how to interact with GitHub repositories using the `gh` CLI. This skill focuses specifically on pull request operations, but you will need to use the commands and techniques from the "github" skill to perform these actions effectively.

## Creating a Pull Request: Full Workflow

1. Check what branch is checked out with
```bash
git branch --show-current
```
2. Make sure the latest changes are in origin by a simple `git push` to the branch. If you have uncommitted changes, commit them first.
3. Create a PR using the repo template in `.github/pull_request_template.md`
3.1 Always create pull requests against the `staging` branch, never `main`.
4. Study the diff so you know what changes are being introduced.
5. Give the PR a title in past tense (if saying what you did) or present tense (if saying what is now possible). E.g. "fixed bug in X" or "Y now supports Z".
5.1 If the branch name includes the Jira issue key (e.g., `IN-1234-add-new-feature`), include that key in the PR title as well (e.g., "IN-1234: added new feature"). This creates a link between the PR and the Jira issue, making it easier to track the work across systems.
6. Populate the PR description 

## Common Mistakes

- **Creating non-draft PRs**: All PRs must be created with `--draft` flag first.
- **Skipping the PR template**: The PR body must follow `.github/pull_request_template.md` exactly.