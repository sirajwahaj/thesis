---
name: python-packages
description: >
  Use this skill when adding, removing, or updating Python dependencies in any package in this
  monorepo. Use this skill when asked about which package manager to use, how pyproject.toml is
  structured, or where a Python package lives. DO NOT use for general coding conventions — see the
  "coding-general" skill for those.
---

# Python Package Management

## Package Manager

All Python packages in this monorepo use `uv`. Never use `pip install` directly.

```bash
uv add <package>       # add a dependency
uv remove <package>    # remove a dependency
uv sync                # install all deps from pyproject.toml + lockfile
```

## Packages in This Monorepo

Each Python package has its own `pyproject.toml` and (after first sync) a `.venv/` under its directory. Here are some of our main packages:

| Directory | Purpose |
|-----------|---------|
| `dagster/` | Main Dagster platform (`insighta_platform`) |
| `dagster/reporting/` | Internal reporting sub-package |
| `supabase/` | Supabase seed/migration tooling |
| `account-management/` | Account management scripts |
| `terraform/terraform-cdktf/` | CDKTF infrastructure code |

Always `cd` into the relevant package directory before running `uv` commands.

## Common Mistakes

- **Using `pip install`**: Always use `uv add` instead. `pip install` bypasses the lockfile and `pyproject.toml`.
- **Running `uv add` from the repo root**: Each package has its own `pyproject.toml` — run `uv` commands from inside the target package directory.
- **Editing `pyproject.toml` manually to add deps**: Use `uv add` so the lockfile stays in sync.
