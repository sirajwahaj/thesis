---
name: skill-maintenance
description: >
  Always-active background skill. After following guidance from any skill in .github/skills/,
  monitor session memory for repeated user corrections against that guidance.
  After 3 corrections pointing the same way against the same skill, prompt the user once to
  consider updating it. DO NOT use for general coding help or one-off overrides.
---

# Skill Maintenance

## Background

Skills in `.github/skills/` encode team conventions. When the agent follows a skill and the user
repeatedly corrects the outcome, the skill may be stale or wrong. This skill ensures that gap
surfaces without being disruptive.

Only skills in `.github/skills/` are in scope — not VS Code built-in skills or external skills.

## When to Use This Skill

- After completing any task guided by a `.github/skills/` skill
- When the user corrects or overrides the agent's skill-driven behavior

## Workflow

### 1. Recognize a skill-driven correction

A correction is when:
- The agent followed guidance from a `.github/skills/` skill, AND
- The user explicitly pushes back, says it's wrong, says it's annoying, or asks for something
  that contradicts what the skill directed

Skip logging if the user signals it's a one-off (e.g. "just this once", "in this case", "for now").

### 2. Log to session memory

After recognizing a correction, append to `/memories/session/skill-corrections.md` (create if absent):

```
- skill: <skill-name>
  skill-directed: <one sentence — what the skill told the agent to do>
  user-wanted: <one sentence — what the user asked for instead>
```

### 3. Check the threshold

After logging, count entries for that skill in `/memories/session/skill-corrections.md`.

If the count reaches **3**, and the agent has not already asked the user about this skill this
session (check for a `asked: true` flag in the file), proceed to step 4.

### 4. Ask the user — once, briefly

At the **end** of the current response, add a single short paragraph. Do not interrupt the main
answer. Example:

> "Side note: you've now steered me away from what the `[skill-name]` skill directs, three times
> this session. Should I update it? If so, just say yes and I'll describe the proposed change in
> plain English for your approval."

After asking, append `asked: <skill-name>` on a new line in `/memories/session/skill-corrections.md`
so this question is never repeated for that skill this session.

### 5. Handle the user's response

**Yes** → describe the minimal change in plain English (no diff yet), wait for user to confirm,
then apply it to the SKILL.md file directly using the file-edit tool.

**No / not now / silence** → do nothing. Do not ask again this session.

## Common Mistakes

- **Asking after a single correction.** One override is almost always contextual. Wait for 3.
- **Asking mid-response.** Always put the check-in at the end, after the main answer is complete.
- **Asking twice for the same skill.** Check for the `asked:` flag before surfacing the question.
- **Logging one-off overrides.** If the user says "just this once" or similar, do not log it.
- **Touching skills outside `.github/skills/`.** Do not flag or propose changes to VS Code
  built-in skills or any skill not owned by this repository.
- **Writing a diff immediately.** Describe the change in plain English first and wait for approval.
