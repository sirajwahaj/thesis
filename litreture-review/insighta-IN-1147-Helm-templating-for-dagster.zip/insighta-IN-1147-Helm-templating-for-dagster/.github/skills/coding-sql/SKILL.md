---
name: coding-sql
description: >
  Use this skill when writing or reviewing SQL queries in this repository.
  DO NOT use for general coding conventions — see the "coding-general" skill for those.
---

# SQL Coding Conventions

## Dialect

All SQL targets **BigQuery**. Follow the [Google BigQuery SQL style guide](https://google.github.io/styleguide/sqlguide.html).

## Key Rules

- **Lowercase keywords**: `select`, `from`, `where`, `join`, etc.
- **Trailing commas**: BigQuery supports them; always use them (see `coding-general` skill for rationale).

```sql
select
  column1,
  column2,
from table_name
```
