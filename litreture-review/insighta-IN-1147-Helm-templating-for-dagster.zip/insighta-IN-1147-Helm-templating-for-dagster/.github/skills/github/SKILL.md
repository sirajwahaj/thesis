---
name: github
description: Use this skill for any GitHub operation. This can be listing, viewing, creating, reviewing, merging, or commenting on pull requests or issues; checking CI/workflow status; or any other interaction with the GitHub repository.
---

# GitHub Usage Guide

## Background

This repository interacts with GitHub exclusively through the `gh` CLI. Do not use GitHub MCP server tools (e.g., `list_pull_requests`, `create_issue`, `get_pull_request`) for any GitHub operations — use `gh` CLI commands instead.

Secrets and environment variables are managed through Infisical, not GitHub Actions secrets directly.


## When to Use This Skill


## Determining the Current User

Use `@me` as the author/assignee value in `gh` commands to refer to the currently authenticated user. This is more efficient than running `gh auth status` first.

Example:
```bash
gh pr list --author @me
gh issue list --assignee @me
```

## Key Commands

### Pull Requests

```bash
# List open PRs (current repo)
gh pr list

# List PRs with filters
gh pr list --state open --author "@me"
gh pr list --label "ready_for_review"
gh pr list --base main

# View a specific PR
gh pr view <number>
gh pr view <number> --web          # open in browser

# View PR diff
gh pr diff <number>

# Check CI status for a PR
gh pr checks <number>

# Create a draft PR (always use --draft per repo convention)
gh pr create --draft --title "IN-XXXX: ..." --body "$(cat .github/pull_request_template.md)"

# Merge a PR (only after approval and green CI)
gh pr merge <number> --squash

# Request a review
gh pr review <number> --request <github-username>

# Add a comment
gh pr comment <number> --body "..."

# List reviews on a PR
gh pr view <number> --json reviews
```

### Issues

```bash
# List open issues
gh issue list

# Filter issues
gh issue list --label "ready_for_refinement"
gh issue list --assignee "@me"
gh issue list --state open

# View a specific issue
gh issue view <number>

# Add a comment
gh issue comment <number> --body "..."

# Close an issue
gh issue close <number>
```

### Workflow / CI Runs

```bash
# List recent workflow runs
gh run list

# List runs for a specific branch
gh run list --branch <branch-name>

# View a specific run
gh run view <run-id>

# View logs for a failed run
gh run view <run-id> --log-failed

# Watch a run in real time
gh run watch <run-id>
```


## Reference: Key Files

- `.github/pull_request_template.md` — Required PR body structure
- `.github/workflows/` — CI workflow definitions (dagster validation, terraform plan, unit tests, deploys)


## Common Mistakes

- **Using MCP server tools**: Do not call `list_pull_requests`, `create_pull_request`, or similar MCP tools. Always use `gh` commands.
