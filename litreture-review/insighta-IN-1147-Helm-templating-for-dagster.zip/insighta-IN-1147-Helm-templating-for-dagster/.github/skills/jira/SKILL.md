---
name: jira
description: >
  Use this skill for any Jira operation: creating, updating, viewing, or searching issues.
  DO NOT use for GitHub PR or issue operations — use the "github" or "pull-requests" skills for those.
---

# Jira Usage Guide

## Background

Issues are managed in the **Software Engineering** project (`IN`). Board: https://insighta-inc.atlassian.net/jira/software/projects/IN/boards/3

Some issues reference the **Account Management** project, but that is rare and will be explicitly stated in the chat. Default to the `IN` project unless told otherwise.

Issues must be concise but descriptive — enough context for a human to understand the issue without being verbose. All issues should be of type **Task**.


## Tool: jira-cli

All Jira operations use [`jira-cli`](https://github.com/ankitpokhrel/jira-cli) (the `jira` command). Do **not** use MCP functions.

### Installation & Setup

If `jira` is not found, install and configure it automatically — do not ask the user:

```bash
# 1. Install
brew install ankitpokhrel/jira-cli/jira-cli

# 2. Configure (non-interactive)
jira init \
  --installation cloud \
  --server https://insighta-inc.atlassian.net \
  --login <user-email> \
  --auth-type basic \
  --project IN \
  --force
```

**Credential storage — `~/.netrc`** (never pass tokens on the command line):

```
machine insighta-inc.atlassian.net login <email> password <api-token>
```

Append the entry (do not overwrite other entries) and enforce safe permissions:

```bash
echo "machine insighta-inc.atlassian.net login <email> password <api-token>" >> ~/.netrc
chmod 600 ~/.netrc
```

After setup, `jira` reads credentials automatically — no env var or flag needed per call.

#### Getting the API token

- **Google SSO users** (e.g. `amir@insighta.io`): generate an API token at https://id.atlassian.com/manage-profile/security/api-tokens and use it as the `.netrc` password.
- **Email/password users**: use their Jira account password as the `.netrc` password, or generate an API token the same way.


## When to Use This Skill

- Creating a new Jira issue
- Updating an existing Jira issue (fields, labels, acceptance criteria)
- Searching for or viewing Jira issues


## Issue Fields

### Required Fields (Tasks only)

| Field | Notes |
|---|---|
| `summary` | Concise, descriptive title |
| `description` | See structure below |

#### Description Structure

The description must contain these two sections:
1. **Background / Context** — what is this about and what is the current state
2. **Motivation / What this enables** — why this matters or what it unlocks

Do **not** repeat the acceptance criteria in the description. If content would duplicate acceptance criteria, omit it from the description and keep it only in the acceptance criteria field.

### Acceptance Criteria

Custom field key: `customfield_10087`

Rules:
- Use `taskList`/`taskItem` ADF nodes (native Jira checkboxes) — do **not** use `[]` prefix text in `paragraph` nodes
- Write in current tense: e.g. "User is able to view their profile"
- The **final item must always be**: `The code changes have been merged to the release branch via an approved PR`

### Labels

Always include `ready_for_refinement` on every create and every update.


## Setting Acceptance Criteria (customfield_10087)

**Critical:** `customfield_10087` requires **Atlassian Document Format (ADF)** — a structured JSON object. The `jira` CLI's `--custom` flag only handles primitive types and does **not** support ADF, so it silently drops the field. This is a jira-cli limitation.

Use `curl` with the `-n` flag, which reads credentials from `~/.netrc` automatically — no tokens on the command line.

### Step 1 — Create the issue (without acceptance criteria)

```bash
jira issue create \
  -t Task \
  -s "Summary here" \
  -b $'## Background / Context\n\n...\n\n## Motivation / What this enables\n\n...' \
  -l ready_for_refinement \
  --no-input
```

Capture the returned issue key (e.g. `IN-456`).

### Step 2 — Set acceptance criteria via curl

Use ADF `taskList`/`taskItem` nodes to render native Jira checkboxes. Each criterion is a `taskItem` inside a single `taskList`. Each `taskItem` needs a unique `localId`.

```bash
ISSUE_KEY="IN-456"
curl -s -n -X PUT \
  "https://insighta-inc.atlassian.net/rest/api/3/issue/${ISSUE_KEY}" \
  -H "Content-Type: application/json" \
  -d '{
    "fields": {
      "customfield_10087": {
        "type": "doc",
        "version": 1,
        "content": [
          {
            "type": "taskList",
            "attrs": {"localId": "tl-1"},
            "content": [
              {
                "type": "taskItem",
                "attrs": {"localId": "ti-1", "state": "TODO"},
                "content": [{"type": "text", "text": "AC item 1"}]
              },
              {
                "type": "taskItem",
                "attrs": {"localId": "ti-2", "state": "TODO"},
                "content": [{"type": "text", "text": "AC item 2"}]
              },
              {
                "type": "taskItem",
                "attrs": {"localId": "ti-3", "state": "TODO"},
                "content": [{"type": "text", "text": "The code changes have been merged to the release branch via an approved PR"}]
              }
            ]
          }
        ]
      }
    }
  }'
```

A `204` response (no output) means success. Any other response body indicates an error.

> **Note:** Do **not** include `[]` in the `text` values — the `taskItem` node renders the native checkbox automatically.

### Edit an existing issue (non-AC fields only)

```bash
jira issue edit IN-123 \
  -l ready_for_refinement \
  --no-input
```

To update acceptance criteria on an existing issue, use the same `curl` approach above (Step 2) with the existing issue key.

### View an issue

```bash
jira issue view IN-123
```

### List / search issues

```bash
# List In Progress issues (plain, no headers)
jira issue list -s "In Progress" --plain --no-headers --columns key,summary,status

# Raw JQL query
jira issue list -q "project = IN AND labels = ready_for_refinement ORDER BY created DESC" --paginate 20

# Paginate: <from>:<limit>
jira issue list --paginate 0:10
```

### Open in browser

```bash
jira open IN-123
```


## Creating Issues: Step-by-Step

> Create **one issue at a time**. Focus fully on each issue to avoid running out of tokens.

1. Compose the summary, description, and acceptance criteria.
2. Run `jira issue create` with `-l ready_for_refinement` (no `--custom` for AC). Capture the returned issue key (e.g. `IN-456`).
3. Set acceptance criteria via `curl` (see **Setting Acceptance Criteria** above).
4. Share the issue key with the user.


## Common Mistakes

- **Creating all issues in one go.** Create one issue at a time to maintain quality and avoid token limits.
- **Forgetting `ready_for_refinement`.** This label must be applied on every create and every update.
- **Using bullet points in acceptance criteria.** Use `[]` action items, not `-` or `1.`.
- **Writing acceptance criteria in the description.** Keep them separate — description covers background and motivation only.
- **Missing the final acceptance criterion.** The last item must always be: `The code changes have been merged to the release branch via an approved PR`.
- **Wrong project key.** Default to `IN` unless the chat explicitly specifies otherwise.
- **Omitting `--no-input`.** Always include it when running as an agent to avoid hanging on interactive prompts.
- **Passing `customfield_10087` via `--custom` in the CLI.** This field requires Atlassian Document Format (ADF) which the CLI does not support. Always use the `curl` approach to set acceptance criteria. Passing it via `--custom` will be silently dropped.
- **Using `paragraph` nodes for acceptance criteria.** This renders `[]` as literal text, not checkboxes. Always use `taskList`/`taskItem` ADF nodes for native Jira checkboxes. Do not include `[]` in the text values — the `taskItem` node renders the checkbox automatically.
- **Forgetting `localId` attributes on `taskList`/`taskItem`.** Both require unique `localId` string attributes (`"tl-1"`, `"ti-1"`, etc.) or Jira will reject the ADF.
