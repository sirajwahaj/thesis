---
name: infisical
description: >
  Use this skill when creating, reading, updating, or deleting secrets in Infisical,
  or when running commands that need secrets injected as environment variables.
  DO NOT use for general environment variable questions unrelated to Infisical.
---

# Infisical Secret Management

## Background

Secrets are managed in [Infisical](https://app.infisical.com). The CLI (`infisical`) reads/writes secrets and injects them into processes. All subdirectories with a `.infisical.json` point to the same project (`d053f15b-3ffc-481a-8557-03573541ad37`).

Three environments exist: `dev`, `staging`, `prod`. They share the same secret names — differences are in values only.

## When to Use This Skill

- Creating new secrets for a service (e.g. n8n, Dagster, Lightdash)
- Reading or listing existing secrets
- Injecting secrets into a local command
- Checking which secrets exist in an environment

## CLI Reference

All commands must run from a directory containing `.infisical.json` (repo root or any subdirectory that has one).

### List secrets

```bash
infisical secrets --env=prod --path=/
```

### Get a single secret

```bash
infisical secrets get SECRET_NAME --env=prod --path=/
```

### Set secrets

```bash
infisical secrets set KEY1=value1 KEY2=value2 --env=prod --path=/
```

Set across multiple environments by running the command once per env:

```bash
infisical secrets set N8N_ENCRYPTION_KEY=abc123 --env=prod --path=/
infisical secrets set N8N_ENCRYPTION_KEY=dev-placeholder --env=dev --path=/
infisical secrets set N8N_ENCRYPTION_KEY=staging-placeholder --env=staging --path=/
```

### Delete a secret

```bash
infisical secrets delete SECRET_NAME --env=prod --path=/
```

### Inject secrets into a command

```bash
infisical run --env=prod -- <command>
```

This is the pattern used in Makefiles:

```makefile
INFISICAL := infisical run --env=prod --
# ...
$(INFISICAL) uv run my_script.py
```

### Folder management

```bash
infisical secrets folders get --env=prod --path=/
infisical secrets folders create --env=prod --path=/ --name=my-folder
infisical secrets folders delete --env=prod --path=/ --name=my-folder
```

## Conventions

- **Secret names**: `SCREAMING_SNAKE_CASE` (e.g. `N8N_ENCRYPTION_KEY`, `POSTGRES_PASSWORD`)
- **Path**: Always `--path=/` unless explicitly told otherwise. Secrets live at the root.
- **Environment flag**: Always pass `--env=<env>` explicitly. The `.infisical.json` default is `dev`, but most operations target `prod`.
- **Shared type**: All secrets are `shared` (not personal). Do not pass `--type=personal`.
- **No secrets in code**: Never hardcode secret values in source files, commits, or chat messages.

## Common Mistakes

- **Forgetting `--env`**: Defaults to `dev`. Always specify the target environment.
- **Running from wrong directory**: The CLI needs `.infisical.json` in the current or ancestor directory. Run from the repo root if unsure.
- **Setting in one env only**: When creating a new secret, set it in all three environments (`dev`, `staging`, `prod`) — even if `dev`/`staging` values are placeholders.
- **Printing secret values**: Avoid dumping full secret values in terminal output. Use `infisical secrets get <name>` for targeted lookups instead of listing all secrets.
