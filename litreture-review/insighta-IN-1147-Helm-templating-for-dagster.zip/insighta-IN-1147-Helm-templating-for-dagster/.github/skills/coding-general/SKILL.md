---
name: coding-general
description: >
  Use this skill when writing or reviewing code in any language in this repository.
  Covers cross-language conventions such as comma style and function decomposition.
---

# General Coding Conventions

## Function Decomposition

Break code into composable functions or methods instead of writing monolithic ones. Each function should do one thing and be easy to name, test, and reuse.

- **Extract when** a block of code has a distinct purpose, is reused, or makes the caller hard to follow.
- **Don't extract** a trivial two-liner that is only used once and is already clear in context.
- **Keep call stacks shallow** — avoid deep chains of single-use wrappers that just add indirection without clarity.
- **Prefer pure functions** where practical: take inputs, return outputs, minimise side effects.

Use the same judgment you'd see in well-maintained projects like Dagster or Pydantic — pragmatic decomposition, not ritual.

## Type Hints & Documentation

Write code that is friendly to IDEs and intellisense. Type hints and docstrings/JSDoc are the primary way to achieve this.

### Type hints

- **Python:** add type hints to function signatures (parameters and return types). Use modern syntax (`list[str]`, `X | None`) over legacy (`List[str]`, `Optional[X]`).
- **TypeScript:** leverage the type system — prefer explicit types on function signatures; let inference handle local variables.
- **Skip** when the type is obvious from context (e.g. `x = 5`) or when fighting the type checker adds noise without safety.

### Docstrings / JSDoc

- **Add a docstring** when a function's name and signature alone don't make the behaviour, edge cases, or return value obvious.
- **Don't add** a docstring that just restates the function name — `def get_user(id): """Get a user."""` adds nothing.
- For Python, use a plain docstring style (no enforced format like NumPy/Google) — just describe what matters.
- For TypeScript/JavaScript, use JSDoc (`/** ... */`) on exported functions and types.

### General

- Aim for code that a teammate can understand from hover-tooltips alone, without jumping to the implementation.
- When in doubt, a clear function name + typed signature is worth more than a paragraph of docs.

## Scripts

Standalone utility scripts (shell, Python, etc.) belong in `scripts/` at the repo root — not inside a package subdirectory.

## Commas

Prefer trailing commas where supported — makes it easy to add/remove elements without touching adjacent lines.

- **Trailing commas** (for systems that support it, e.g. BigQuery SQL, Python, JS/TS):
  ```sql
  select
    column1,
    column2,
  ```

- **Leading commas** (for systems that do NOT allow trailing commas on the last element, e.g. JSON):
  ```json
  {
    "key1": "value1"
    ,"key2": "value2"
  }
  ```
