The `account-management` package contains utility scripts used by the Account Management team to manage customer accounts and their associated data within the Insighta platform. These scripts facilitate tasks such as onboarding new customers, managing existing accounts, and handling billing and subscription details.

# Get the daily partition start date for all organizations
This script fetches the `dagster_daily_partition_start_date` for all organizations and prints them out. This date is used to define the start date for daily partitions in Dagster. Once you have the date for an organization it should be manually added to the column `dagster_daily_partition_start_date` in the `organizations` table in Supabase.

## Running the script
1. Make sure you have materialized the `dispatch` dbt model into the environment of your `BIGQUERY_DATASET` with dagster using config `full-refresh: true`. Config example:
```yaml
ops:
  organization_obagi_dbt_assets:
    config:
      full_refresh: true
```
2. run the following command from the `account-management/` directory:
```bash
make dates
```

## Environment variables

### Required
```sh
export BIGQUERY_DATASET='your_bigquery_dataset_name'
```

### Optional
To limit which organizations to load dagster definitions for:
```sh
export LIST_ORGANIZATION_NAMES_TO_LOAD_DAGSTER_DEFINITIONS_FOR='["client1", "client2"]'
```