# standard library imports
import asyncio
from collections.abc import Awaitable

# third-party imports
import pandas as pd
from google.cloud import bigquery
import dotenv

dotenv.load_dotenv(override=True)

# local imports
from insighta_platform.resources.supabase import organizations_df # type: ignore (intellisence does not recognize the editable install)
from insighta_platform.assets.conforming import compile_conforming_sql, physical_model_dbml_schema # type: ignore (intellisence does not recognize the editable install)
from insighta_platform.resources.gcp import dict_bigquery_resources # type: ignore (intellisence does not recognize the editable install)

async def get_earliest_dates_for_all_orgs():
    """
    Get the earliest date across all conformed sources for all organizations.  
    This is the minimum date observed across all their conformed sources.
    """
    org_names: list[str] = [str(row["organization_name"]) for _, row in organizations_df.iterrows()]
    print(f"Processing {len(org_names)} organizations: {org_names}")
    
    if not org_names:
        print("No organizations found. Check organizations_df data source.")
        return
    
    tasks: list[Awaitable[str]] = [_get_earliest_date_across_all_conformed_sources_for_one_org(org) for org in org_names]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    
    print("\n=== RESULTS ===")
    for org_name, result in zip(org_names, results):
        if isinstance(result, Exception):
            print(f"ERROR for {org_name}: {result}")
        else:
            print(f"{org_name}: earliest partition start date = {result}")
    
    print("=== COMPLETED ===")

async def _get_earliest_date_across_all_conformed_sources_for_one_org(
        organization_name: str,
) -> str:
    """
    Get the earliest date across all conformed sources for an organization.
    This is the minimum date observed across all their conformed sources.
    """
    
    # Get the organization row from organizations_df
    organization_rows = organizations_df[organizations_df['organization_name'] == organization_name]
    if organization_rows.empty:
        raise ValueError(f"Organization '{organization_name}' not found in organizations_df")
    
    organization_row = organization_rows.iloc[0]
    conformed_sources_df: pd.DataFrame = compile_conforming_sql(organization_row=organization_row)

    # extract from physical_model_dbml_schema all tables and their time columns
    conformed_source_time_columns: dict[str, str] = _get_conformed_source_names_with_time_columns()

    # Build a single SQL query with CTEs for each (conformed_source, connector_source)
    cte_sqls = []
    cte_names = []
    for conformed_source_name, time_column in conformed_source_time_columns.items():
        conformed_sources_this_conformed_source_name_df: pd.DataFrame = conformed_sources_df[conformed_sources_df['conformed_source_name'] == conformed_source_name]
        for _, conformed_source_pre_union in conformed_sources_this_conformed_source_name_df.iterrows():
            conformed_source_pre_union_sql: str = conformed_source_pre_union['conforming_sql']
            connector_source_name: str = conformed_source_pre_union['connector_source_name']
            # Sanitize CTE name
            cte_name = f"earliest_date_{conformed_source_name}_{connector_source_name}".replace("-", "_").replace(".", "_")
            cte_names.append(cte_name)
            cte_sql = f"""
                {cte_name} as (
                    select min(cast({time_column} as date)) as earliest_date from (
                        {conformed_source_pre_union_sql}
                    )
                )
            """
            cte_sqls.append(cte_sql)

    # Union all CTEs
    union_selects = [f"select earliest_date from {cte_name}" for cte_name in cte_names]
    union_sql = "\nunion all\n".join(union_selects)

    # Compose final SQL
    cte_sqls_joined = ",\n".join(cte_sqls)
    final_sql = f"""
        with
        {cte_sqls_joined}
        , unioned as (
            {union_sql}
        )
        select min(earliest_date) as earliest_date_across_all_pre_union_conformed_sources from unioned
    """

    print(f"Executing SQL to get earliest_date_across_all_pre_union_conformed_sources for organization {organization_name}")
    import asyncio
    try:
        bigquery_resource = dict_bigquery_resources[f"bigquery_resource_{organization_name}"]
        # Run the blocking BigQuery query and result fetching in a thread
        def run_query():
            with bigquery_resource.get_client() as client:
                query_job = client.query(
                    final_sql,
                    job_config=bigquery.QueryJobConfig(
                        use_query_cache=True,
                    ),
                )
                df = query_job.result().to_dataframe()
                return df.iloc[0]['earliest_date_across_all_pre_union_conformed_sources']

        earliest_date_across_all_pre_union_conformed_sources = await asyncio.to_thread(run_query)
        print(f"earliest date found for organization {organization_name}: {earliest_date_across_all_pre_union_conformed_sources}")
        return str(earliest_date_across_all_pre_union_conformed_sources)
    except Exception as e:
        print(f"Error occurred while getting earliest date for organization {organization_name}: {e}")
        raise e

def _get_conformed_source_names_with_time_columns() -> dict[str, str]:
    """
    Get a dict mapping conformed source names to the first column ending with _timestamp or _date, if any.
    """
    result = {}
    for table_name, columns in physical_model_dbml_schema.items():
        first_time_column = None
        for column in columns:
            if isinstance(column, (list, tuple)) and isinstance(column[0], str) and column[0].endswith(("_timestamp", "_date")):
                first_time_column = column[0]
                break
        if first_time_column:
            result[table_name] = first_time_column
    return result

if __name__ == "__main__":
    asyncio.run(get_earliest_dates_for_all_orgs())
