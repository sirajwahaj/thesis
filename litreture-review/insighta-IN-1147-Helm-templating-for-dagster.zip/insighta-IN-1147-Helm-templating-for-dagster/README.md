# secrets manager: Infisical

## Setup
1. [Install the CLI](https://infisical.com/docs/cli/overview)
1. [Authenticate by running `infisical login`](https://infisical.com/docs/cli/usage)
> Note: our instance is an EU one

## Usage
Many of our projects have a Makefile that removes the need for all the boilerplate below. Check the relevant Makefile first.

<details><summary>If you still want to know how to manually run commands with Infisical, expand this section</summary>

```sh
infisical run --project-config-dir={/path/to/root} -- {command that needs environment variables}`
```

Example:
```sh
infisical run --project-config-dir=/Users/amirjaberinsighta/Documents/GitHub/work/insighta/ -- uv run generate_seed_file.py
```

</details>

### Inspect env vars
> Note: this won't show you any `.env` file variables that may overwrite the secrets from Infisical at runtime.

```sh
infisical run --project-config-dir={/path/to/root} -- {sh/bash} -c 'echo ${ENV_VAR_NAME}'
```

Example:
```sh
infisical run --project-config-dir=/Users/amirjaberinsighta/Documents/GitHub/work/insighta/ -- sh -c 'echo $SUPABASE_URL'
```

# dbt

## dbt run cache
Read [the design partner docs on confluence](https://insighta-inc.atlassian.net/wiki/spaces/IN/pages/295829505/dbt+run+cache) for
- Installation
- Local Authentication
- Config
- CI/CD Config

For use in dagster, see [dbt-run-cache (fivetran package) in dagster/README.md](./dagster/README.md#dbt-run-cache-fivetran-package).

## Running dbt from the CLI or with dbt power user

Because our setup is rather unorthodox, the dbt power user extension needs special setup.

### dbt_project.yaml
Dagster injects the dbt_project into a dbt `var` at runtime. But when running the extension, this var needs to be set explicitly. This involves temporarily changing the `var` `bigquery_project_id` in the `dbt_project.yml` file to e.g. `client1-istag`

> Note: make sure you don't commit this.

### Environment variables
- The extension reads from an `.env` file at the _**root**_ of the repo.
- The env vars in that file can't have `export` before the assignment.

- These env vars need to be set:
```bash
BIGQUERY_PROJECT_ID=client1-istag
BIGQUERY_DATASET=dev_amir
```