# Running cube core
GCP setup is detailed in confluence article [VM - cube core prod](https://insighta-inc.atlassian.net/wiki/x/DIB4Cg). There you can also see how you can query cube core deployments.

Below are the steps to run cube core locally.
1. Navigate to `cube/`
1. Ensure you have an `.env` file in this location with the following variables:
```bash
CUBEJS_DB_BQ_CREDENTIALS=<same as GOOGLE_APPLICATION_CREDENTIALS_BASE64>
CUBEJS_API_SECRET=<set a long, random secret. At least 32 characters long e.g. bkbikznohxipa4sbi44apeyqbdfega2a>
CUBEJS_DB_TYPE=bigquery
CUBEJS_EXTERNAL_DEFAULT=true
CUBEJS_SCHEDULED_REFRESH_DEFAULT=true
CUBEJS_DEV_MODE=true
CUBEJS_SCHEMA_PATH=model
CUBEJS_DB_BQ_LOCATION=us
```
3. Run `docker compose up --build -d`
4. [If in dev mode]: set the security context to e.g.:
```bash
{
  "projectId": "demoorganization",
  "datasetId": "analytics"
}
```