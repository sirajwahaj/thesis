// imports
// const https = require('https');

// Helper functions
function replaceNonAlphanumericsWithUnderscore(string) {
  return string.replace(/[^a-zA-Z0-9_]/g, '_');
}
function hashObject(obj) {
  const jsonString = JSON.stringify(obj);
  let hash = 0, i, chr;
  for (i = 0; i < jsonString.length; i++) {
    chr = jsonString.charCodeAt(i);
    hash = ((hash << 5) - hash) + chr;
    hash |= 0; // Convert to 32bit integer
  }
  return hash.toString(16);
}

// async function fetchTenantsFromSupabase() {
//   return new Promise((resolve, reject) => {
//     // Get SUPABASE_URL from environment variables
//     const supabaseUrl = process.env.SUPABASE_URL; // e.g., 'https://your-project.supabase.co'
//     if (!supabaseUrl) {
//       return reject(new Error('SUPABASE_URL is not defined'));
//     }

//     // Extract hostname from SUPABASE_URL
//     const hostname = supabaseUrl.replace(/^https?:\/\//, '').split('/')[0]; // 'your-project.supabase.co'

//     // Define the path to your tenants table and select the projectId column
//     const path = '/rest/v1/organizations?select=organization_conformed_source_gcp_project_id';

//     // Use the appropriate API key for authentication
//     const apiKey = process.env.SUPABASE_KEY; // Use SUPABASE_KEY (anon key) or SUPABASE_SERVICE_ROLE_KEY
//     if (!apiKey) {
//       return reject(new Error('SUPABASE_KEY is not defined'));
//     }

//     const options = {
//       hostname,
//       path,
//       method: 'GET',
//       headers: {
//         'apikey': apiKey,
//         'Authorization': `Bearer ${apiKey}`,
//         'Accept': 'application/json',
//       },
//     };

//     const req = https.request(options, (res) => {
//       let data = '';

//       // Accumulate data chunks
//       res.on('data', (chunk) => {
//         data += chunk;
//       });

//       // On end, parse the data and resolve the promise
//       res.on('end', () => {
//         try {
//           const tenants = JSON.parse(data);
//           resolve(tenants);
//         } catch (error) {
//           reject(new Error(`Failed to parse tenant data from Supabase: ${error.message}`));
//         }
//       });
//     });

//     req.on('error', (error) => {
//       reject(new Error(`Error fetching tenants from Supabase: ${error.message}`));
//     });

//     req.end();
//   });
// }

// Configuration
module.exports = {

  // separates cached definitions of data models (e.g. cubes)
  // This could in theory likely be removed (or made static) because it should be the same for all tenants
  // BUT in case that ever changes, (or if our understanding of what this does is incorrect)
  // it couldn't hurt to keep it separate. Our opinion here might change if the management of
  // the model cache causes performance issues.
  // https://cube.dev/docs/reference/configuration/config#context_to_app_id
  contextToAppId: ({ securityContext }) => {
    const hashedSecurityContext = hashObject(securityContext);
    return `CUBE_APP_${hashedSecurityContext}`;
  },

  // separates cache for query execution resources like database connections, query queues, and pre-aggregations
  // note: if this is dynamic, preAggregationsSchema needs to be as well
  // https://cube.dev/docs/reference/configuration/config#context_to_orchestrator_id
  contextToOrchestratorId: ({ securityContext }) =>{
    const hashedSecurityContext = hashObject(securityContext);
    return `CUBE_ORCHESTRATOR_${hashedSecurityContext}`;
  },

  // Set pre-aggregations schema to avoid name clashes
  // https://cube.dev/docs/reference/configuration/config#pre_aggregations_schema
  preAggregationsSchema: ({ securityContext }) =>{
    const hashedSecurityContext = hashObject(securityContext);
    return `pre_aggregations_${hashedSecurityContext}`;
  },

  // Driver factory provides tenant-specific BigQuery credentials
  driverFactory: ({ securityContext }) => ({
    type: 'bigquery',
    projectId: securityContext.projectId,
  }),

  // // Asynchronous function to generate scheduled refresh contexts
  // feb 2025: this might be an alternative (or the same) solution: https://cube-js.slack.com/archives/C04NYBJP7RQ/p1731934459049699?thread_ts=1731930970.039659&cid=C04NYBJP7RQ
  // scheduledRefreshContexts: async () => {
  //   // Fetch the list of tenants from Supabase
  //   const tenants = await fetchTenantsFromSupabase();

  //   // Construct security contexts for each tenant
  //   return tenants.map((tenant) => ({
  //     securityContext: {
  //       projectId: tenant.projectId,
  //     },
  //   }));
  // },

  // temp: manually set scheduledRefreshContexts
  scheduledRefreshContexts: () => [
    {
      securityContext: {
        projectId: 'americanflags-416504',
        datasetId: 'analytics',
      },
    },
    {
      securityContext: {
        projectId: 'bostonbrainscience',
        datasetId: 'analytics',
      },
    },
    {
      securityContext: {
        projectId: 'carrottop-416504',
        datasetId: 'analytics',
      },
    },
    {
      securityContext: {
        projectId: 'lagence-420415',
        datasetId: 'analytics',
      },
    },
    {
      securityContext: {
        projectId: 'looloo-408216',
        datasetId: 'analytics',
      },
    },
    {
      securityContext: {
        projectId: 'shoptaby',
        datasetId: 'analytics',
      },
    },
  ]

};


//////////// NOTE FROM CUBE BELOW //////////////////////

// Cube configuration options: https://cube.dev/docs/config

// NOTE: third-party dependencies and the use of require(...) are disabled for
// CubeCloud users by default.  Please contact support if you need them
// enabled for your account.  You are still allowed to require
// @cubejs-backend/*-driver packages.