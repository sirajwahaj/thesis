/**
 * Ensures that a required filter is applied for a given dimension.
 *
 * This function is used to enforce fan-out protection in Cube.js models by verifying
 * that the provided filter expression is not the default no-op (i.e., `(1 = 1)`).
 * If no specific filter is provided, it throws an error and stops the query.
 *
 * @param {string} filterParamCall - The filter parameter expression, expected to be a valid SQL condition.
 * @param {string} filterName - The name of the dimension that must be filtered on (used in the error message).
 * @param {string} cubeName - The name of the cube (used in the error message).
 * @param {boolean} [applyFilterWithinCubeSqlProperty=false] - If true, returns a string indicating the filter is applied on another cube instead of the actual filterParam as the successfull output
 * @returns {string} The validated filter parameter SQL condition, or a message if condition is true.
 */
export const requireFilterParam = (filterParamCall, filterName, cubeName, applyFilterWithinCubeSqlProperty = true) => {
  const filterParam = String(filterParamCall); // Ensure it's a string
  if (filterParam === "(1 = 1)") {
    throw new Error(
      `Missing required filter: You must filter on '${filterName}' because your query uses cube ${cubeName}.`
    );
  }
  if (!applyFilterWithinCubeSqlProperty) {
    return `required filter on '${filterName}' is successfully applied on another cube`;
  }
  return filterParam;
};