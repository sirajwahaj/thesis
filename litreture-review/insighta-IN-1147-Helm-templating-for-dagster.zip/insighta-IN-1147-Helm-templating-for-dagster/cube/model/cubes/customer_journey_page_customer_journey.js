import { requireFilterParam } from './utils/filter_enforcement';

const refresh_sql_fanned_out_value_summary_table = `select count(*) from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_fanned_out_value_summary`;

const refresh_key_sql_fanned_out_value_summary = `
  ${refresh_sql_fanned_out_value_summary_table}
`;

cube(`cube_customer_journey_page_customer_journey`, {

  extends: auto_generated_base_cube_customer_journey_page_customer_journey,

  title: `value_summary`,

  description: `
    This cube has the same filters and notes from marketing_attribution_page_cube.

    The cube is built to be used on the customer journey page for the summary tiles and sample of conversions table at the bottom of the page.  This cube rolls up from the individual conversion grain.
  `,
  
  refresh_key: {
    sql: refresh_key_sql_fanned_out_value_summary,
  },

  sql: `with

    xa_fanned_out_value_summary as (
      select * from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_fanned_out_value_summary
    ),

    enforce_filtering_that_removes_fan_out as (

      select * from xa_fanned_out_value_summary where true
      
        and ${requireFilterParam(
          FILTER_PARAMS.cube_customer_journey_page_customer_journey.attribution_model_name.filter('attribution_model_name'),
          'attribution_model_name',
          CUBE,
        )}
        and ${requireFilterParam(
          FILTER_PARAMS.cube_customer_journey_page_customer_journey.future_value_horizon_days.filter('future_value_horizon_days'),
          'future_value_horizon_days',
          CUBE,
        )}
        and ${requireFilterParam(
          FILTER_PARAMS.cube_customer_journey_page_customer_journey.marketing_level.filter('marketing_level'),
          'marketing_level',
          CUBE,
        )}

    ),

    group_to_conversion_grain as (

      select

        date_trunc(apportionment_date_conversion, day) apportionment_date_conversion,
        date_trunc(apportionment_date_cost, day) apportionment_date_cost,
        attribution_model_name,
        future_value_horizon_days,
        marketing_level,

        -- conversion dimensions
        conversion_compound_key,
        conversion_natural_key,
        conversion_contact_blended_key,
        conversion_natural_key_customer_facing,
        conversion_is_marketing_attributed,
        conversion_sequence_number,
        conversion_type,

        -- campaigns
        campaign_name,
        distinct_attributed_marketing_level_connector_sources,
        distinct_attributed_marketing_level_campaign_or_ad_names,
        marketing_connector_source,
        
        -- conversion journey metrics
        count_distinct_session_compound_key_since_beginning,
        count_distinct_session_compound_key_since_preceding_conversion,
        conversion_days_since_first_event,
        conversion_days_since_preceding_conversion,
        timestamp_event_first,

        -- conversion value metrics
        sum(amount_cost_apportioned) as amount_cost_apportioned,
        sum(amount_value_attributed_immediate) as amount_value_attributed_immediate,
        sum(amount_value_attributed_incremental_lifetime_value) as amount_value_attributed_incremental_lifetime_value,
        sum(amount_value_attributed_future_value) as amount_value_attributed_future_value,

      from enforce_filtering_that_removes_fan_out
      group by all

    )

  select * from group_to_conversion_grain
  
  `,
 
  measures: {

    number_roas_immediate: {
      type: `number`,
      sql: `SAFE_DIVIDE(
        ${CUBE.sum_amount_value_attributed_immediate},
        ${CUBE.sum_amount_cost_apportioned}
      )`,
    },

    number_roas_incremental_lifetime: {
      type: `number`,
      sql: `SAFE_DIVIDE(
        ${CUBE.sum_amount_value_attributed_incremental_lifetime_value},
        ${CUBE.sum_amount_cost_apportioned}
      )`,
    },

    number_roas_incremental_future: {
      type: `number`,
      sql: `SAFE_DIVIDE(
        ${CUBE.sum_amount_value_attributed_future_value},
        ${CUBE.sum_amount_cost_apportioned}
      )`,
    },

    count_distinct_conversion_contact_blended_key_marketing_attributed: {
      type: `count_distinct`,
      sql: `case when ${CUBE.conversion_is_marketing_attributed} is true then ${CUBE.conversion_contact_blended_key} else null end`,
    },
    conversion_marketing_penetration: {
      type: `number`,
      title: `Conversion Marketing Penetration`,
      sql: `${CUBE.count_distinct_conversion_contact_blended_key_marketing_attributed} / ${CUBE.count_distinct_conversion_contact_blended_key}`,
    },
    working_media_cac: {
      type: `number`,
      title: `Working Media CAC`,
      sql: `${CUBE.sum_amount_cost_apportioned}`,
    },


  },

});


// the cube below is auto generated with Cube Code Generator spreadsheet https://drive.google.com/drive/folders/18eblS2J3nWqhHoL1fiBte154bDTg2rMG
// the cube above is manually maintained and extends the cube below
// ideally, the base and extending cubes would be in separate files (improvement opportunity)
// the top one would be named xa_fanned_out_value_summary.js and the bottom one xa_fanned_out_value_summary_base.js
const auto_generated_base_cube_customer_journey_page_customer_journey = cube(`auto_generated_base_cube_customer_journey_page_customer_journey`, {
  
  sql: `placeholder`,
  
  dimensions: {
    
    conversion_compound_key: {
      sql: `conversion_compound_key`,
      type: `string`,
    },

    conversion_contact_blended_key: {
      shown: false,
      sql: `conversion_contact_blended_key`,
      type: `string`,
    },

    conversion_natural_key_customer_facing: {
      sql: `conversion_natural_key_customer_facing`,
      type: `string`,
    },

    conversion_natural_key: {
      sql: `conversion_natural_key`,
      type: `string`,
    },

    apportionment_date_conversion: {
      sql: `cast( apportionment_date_conversion as timestamp )`,
      type: `time`,
    },

    apportionment_date_cost: {
      sql: `cast( apportionment_date_cost as timestamp )`,
      type: `time`,
    },

    attribution_model_name: {
      sql: `attribution_model_name`,
      type: `string`,
    },

    campaign_name: {
      sql: `campaign_name`,
      type: `string`,
    },

    future_value_horizon_days: {
      sql: `future_value_horizon_days`,
      type: `number`,
    },

    marketing_connector_source: {
      sql: `marketing_connector_source`,
      type: `string`,
    },

    marketing_level: {
      sql: `marketing_level`,
      type: `string`,
    },

    ratio_value_attribution: {
      sql: `ratio_value_attribution`,
      type: `number`,
    },

    is_first_conversion_of_customer: {
      sql: `is_first_conversion_of_customer`,
      type: `boolean`,
    },

    conversion_sequence_number: {
      sql: `conversion_sequence_number`,
      type: `number`,
    },

    conversion_type: {
      sql: `conversion_type`,
      type: `string`,
    },

    timestamp_event_first: {
      sql: `timestamp_event_first`,
      type: `time`,
    },

    count_distinct_session_compound_key_since_beginning: {
      sql: `count_distinct_session_compound_key_since_beginning`,
      type: `number`,
    },

    count_distinct_session_compound_key_since_preceding_conversion: {
      sql: `count_distinct_session_compound_key_since_preceding_conversion`,
      type: `number`,
    },

    conversion_days_since_first_event: {
      sql: `conversion_days_since_first_event`,
      type: `number`,
    },

    conversion_days_since_preceding_conversion: {
      sql: `conversion_days_since_preceding_conversion`,
      type: `number`,
    },

    conversion_is_marketing_attributed: {
      sql: `conversion_is_marketing_attributed`,
      type: `boolean`,
    },

    distinct_attributed_marketing_level_connector_sources: {
      sql: `distinct_attributed_marketing_level_connector_sources`,
      type: `string`,
    },

    distinct_attributed_marketing_level_campaign_or_ad_names: {
      sql: `distinct_attributed_marketing_level_campaign_or_ad_names`,
      type: `string`,
    },

    conversion_days_since_first_marketing_touchpoint: {
      sql: `conversion_days_since_first_marketing_touchpoint`,
      type: `number`,
    },

    conversion_days_since_last_marketing_touchpoint: {
      sql: `conversion_days_since_last_marketing_touchpoint`,
      type: `number`,
    },

    amount_value_attributed_immediate: {
      sql: `amount_value_attributed_immediate`,
      type: `number`,
    },

    amount_value_attributed_incremental_lifetime_value: {
      sql: `amount_value_attributed_incremental_lifetime_value`,
      type: `number`,
    },

    amount_value_attributed_future_value: {
      sql: `amount_value_attributed_future_value`,
      type: `number`,
    },

    amount_cost_apportioned: {
      sql: `amount_cost_apportioned`,
      type: `number`,
    },

  },
  
  measures: {
    
    count_distinct_apportionment_date_cost: {
      type: `count_distinct`,
      sql: `${CUBE.apportionment_date_cost}`,
    },
    
    count_distinct_conversion_compound_key: {
      type: `count_distinct`,
      sql: `${CUBE.conversion_compound_key}`,
    },

    count_distinct_conversion_contact_blended_key: {
      type: `count_distinct`,
      sql: `${CUBE.conversion_contact_blended_key}`,
    },

    count_distinct_marketing_connector_source: {
      type: `count_distinct`,
      sql: `${CUBE.marketing_connector_source}`,
    },

    count_distinct_campaign_name: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_name}`,
    },

    min_apportionment_date_conversion: {
      type: `min`,
      sql: `${CUBE.apportionment_date_conversion}`,
    },

    max_apportionment_date_conversion: {
      type: `max`,
      sql: `${CUBE.apportionment_date_conversion}`,
    },

    min_apportionment_date_cost: {
      type: `min`,
      sql: `${CUBE.apportionment_date_cost}`,
    },

    max_apportionment_date_cost: {
      type: `max`,
      sql: `${CUBE.apportionment_date_cost}`,
    },

    min_timestamp_event_first: {
      type: `min`,
      sql: `${CUBE.timestamp_event_first}`,
    },

    avg_count_distinct_session_compound_key_since_beginning: {
      type: `avg`,
      sql: `${CUBE.count_distinct_session_compound_key_since_beginning}`,
    },

    min_count_distinct_session_compound_key_since_beginning: {
      type: `min`,
      sql: `${CUBE.count_distinct_session_compound_key_since_beginning}`,
    },

    max_count_distinct_session_compound_key_since_beginning: {
      type: `max`,
      sql: `${CUBE.count_distinct_session_compound_key_since_beginning}`,
    },

    number_approx_percentile_count_distinct_session_compound_key_since_beginning_95: {
      type: `number`,
      title: `95th percentile days since first event (approximate)`,
      sql: `
        approx_quantiles(
        ${CUBE.count_distinct_session_compound_key_since_beginning},
        100
        )[OFFSET(95)]
        `,
    },

    number_standard_deviation_count_distinct_session_compound_key_since_beginning: {
      type: `number`,
      title: `standard deviation of days since first event`,
      sql: `stddev( ${CUBE.count_distinct_session_compound_key_since_beginning} )`,
    },

    avg_count_distinct_session_compound_key_since_preceding_conversion: {
      type: `avg`,
      sql: `${CUBE.count_distinct_session_compound_key_since_preceding_conversion}`,
    },

    min_count_distinct_session_compound_key_since_preceding_conversion: {
      type: `min`,
      sql: `${CUBE.count_distinct_session_compound_key_since_preceding_conversion}`,
    },

    max_count_distinct_session_compound_key_since_preceding_conversion: {
      type: `max`,
      sql: `${CUBE.count_distinct_session_compound_key_since_preceding_conversion}`,
    },

    number_approx_percentile_count_distinct_session_compound_key_since_preceding_conversion_95: {
      type: `number`,
      title: `95th percentile days since first event (approximate)`,
      sql: `
        approx_quantiles(
        ${CUBE.count_distinct_session_compound_key_since_preceding_conversion},
        100
        )[OFFSET(95)]
        `,
    },

    number_standard_deviation_count_distinct_session_compound_key_since_preceding_conversion: {
      type: `number`,
      title: `standard deviation of days since first event`,
      sql: `stddev( ${CUBE.count_distinct_session_compound_key_since_preceding_conversion} )`,
    },

    avg_conversion_days_since_first_event: {
      type: `avg`,
      sql: `${CUBE.conversion_days_since_first_event}`,
    },

    min_conversion_days_since_first_event: {
      type: `min`,
      sql: `${CUBE.conversion_days_since_first_event}`,
    },

    max_conversion_days_since_first_event: {
      type: `max`,
      sql: `${CUBE.conversion_days_since_first_event}`,
    },

    number_approx_percentile_conversion_days_since_first_event_95: {
      type: `number`,
      title: `95th percentile days since first event (approximate)`,
      sql: `
        approx_quantiles(
        ${CUBE.conversion_days_since_first_event},
        100
        )[OFFSET(95)]
        `,
    },

    number_standard_deviation_conversion_days_since_first_event: {
      type: `number`,
      title: `standard deviation of days since first event`,
      sql: `stddev( ${CUBE.conversion_days_since_first_event} )`,
    },

    avg_conversion_days_since_preceding_conversion: {
      type: `avg`,
      sql: `${CUBE.conversion_days_since_preceding_conversion}`,
    },

    min_conversion_days_since_preceding_conversion: {
      type: `min`,
      sql: `${CUBE.conversion_days_since_preceding_conversion}`,
    },

    max_conversion_days_since_preceding_conversion: {
      type: `max`,
      sql: `${CUBE.conversion_days_since_preceding_conversion}`,
    },

    number_approx_percentile_conversion_days_since_preceding_conversion_95: {
      type: `number`,
      title: `95th percentile days since first event (approximate)`,
      sql: `
        approx_quantiles(
        ${CUBE.conversion_days_since_preceding_conversion},
        100
        )[OFFSET(95)]
        `,
    },

    number_standard_deviation_conversion_days_since_preceding_conversion: {
      type: `number`,
      title: `standard deviation of days since first event`,
      sql: `stddev( ${CUBE.conversion_days_since_preceding_conversion} )`,
    },

    avg_conversion_days_since_first_marketing_touchpoint: {
      type: `avg`,
      sql: `${CUBE.conversion_days_since_first_marketing_touchpoint}`,
    },

    min_conversion_days_since_first_marketing_touchpoint: {
      type: `min`,
      sql: `${CUBE.conversion_days_since_first_marketing_touchpoint}`,
    },

    max_conversion_days_since_first_marketing_touchpoint: {
      type: `max`,
      sql: `${CUBE.conversion_days_since_first_marketing_touchpoint}`,
    },

    avg_conversion_days_since_last_marketing_touchpoint: {
      type: `avg`,
      sql: `${CUBE.conversion_days_since_last_marketing_touchpoint}`,
    },

    min_conversion_days_since_last_marketing_touchpoint: {
      type: `min`,
      sql: `${CUBE.conversion_days_since_last_marketing_touchpoint}`,
    },

    max_conversion_days_since_last_marketing_touchpoint: {
      type: `max`,
      sql: `${CUBE.conversion_days_since_last_marketing_touchpoint}`,
    },

    sum_amount_value_attributed_immediate: {
      type: `sum`,
      sql: `${CUBE.amount_value_attributed_immediate}`,
    },

    avg_amount_value_attributed_immediate: {
      type: `avg`,
      sql: `${CUBE.amount_value_attributed_immediate}`,
    },

    sum_amount_value_attributed_incremental_lifetime_value: {
      type: `sum`,
      sql: `${CUBE.amount_value_attributed_incremental_lifetime_value}`,
    },

    avg_amount_value_attributed_incremental_lifetime_value: {
      type: `avg`,
      sql: `${CUBE.amount_value_attributed_incremental_lifetime_value}`,
    },

    sum_amount_value_attributed_future_value: {
      type: `sum`,
      sql: `${CUBE.amount_value_attributed_future_value}`,
    },

    avg_amount_value_attributed_future_value: {
      type: `avg`,
      sql: `${CUBE.amount_value_attributed_future_value}`,
    },

    sum_amount_cost_apportioned: {
      type: `sum`,
      sql: `${CUBE.amount_cost_apportioned}`,
    },

    avg_amount_cost_apportioned: {
      type: `avg`,
      sql: `${CUBE.amount_cost_apportioned}`,
    },


  },

});