cube(`cube_ads`, {

  extends: auto_generated_base_cube_ads,

  refresh_key: {
    sql: `select count(*) from ${COMPILE_CONTEXT.securityContext.datasetId}.dim_ads`,
  },

  sql: `select * from ${COMPILE_CONTEXT.securityContext.datasetId}.dim_ads`,

  joins: {

    cube_ad_summary_daily: {
      sql: `${CUBE.ad_pk} = ${cube_ad_summary_daily.ad_fk}`,
      relationship: `one_to_many`,
    },
    
  },
  
  dimensions: {

    ad_pk: {
      shown: true, // reason for extend
      primary_key: true,
      sql: `ad_pk`,
      type: `string`,
    },

  },
 
  measures: {

    count_ads: {
      type: `count`,
    },

    distinct_ad_names: {
      sql: `string_agg(distinct ${CUBE.ad_name}, ', ' order by ${CUBE.ad_name})`,
      type: `string`,
      description: `(a comma-separated string instead of an array) the unique list of ad names. sorted alphabetically. example: 'facebook, google ads', 'facebook'`,
    },

    distinct_connector_sources: {
      sql: `string_agg(distinct ${CUBE.ad_connector_source}, ', ' order by ${CUBE.ad_connector_source})`,
      type: `string`,
      description: `(a comma-separated string instead of an array) the unique list of connector sources, sorted alphabetically. example: 'black friday 2021, summer sale 2021', 'black friday 2021'`,
    },

  },

});


// the cube below is auto generated with Cube Code Generator spreadsheet https://drive.google.com/drive/folders/18eblS2J3nWqhHoL1fiBte154bDTg2rMG
// the cube above is manually maintained and extends the cube below
// ideally, the base and extending cubes would be in separate files (improvement opportunity)
// the top one would be named dim_ads.js and the bottom one dim_ads_base.js
const auto_generated_base_cube_ads = cube(`auto_generated_base_cube_ads`, {
  
  sql: `placeholder`,
  
  dimensions: {
    
    ad_pk: {
      shown: false,
      primary_key: true,
      sql: `ad_pk`,
      type: `string`,
    },

    ad_natural_key: {
      sql: `ad_natural_key`,
      type: `string`,
    },

    ad_connector_source: {
      sql: `ad_connector_source`,
      type: `string`,
    },

    ad_medium_name: {
      sql: `ad_medium_name`,
      type: `string`,
    },

    ad_name: {
      sql: `ad_name`,
      type: `string`,
    },

    ad_text: {
      sql: `ad_text`,
      type: `string`,
    },

    ad_url: {
      sql: `ad_url`,
      type: `string`,
    },

  },
  
  measures: {
    
    count_distinct_ad_natural_key: {
      type: `count_distinct`,
      sql: `${CUBE.ad_natural_key}`,
    },

    count_distinct_approx_ad_natural_key: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_natural_key}`,
    },

    count_distinct_ad_connector_source: {
      type: `count_distinct`,
      sql: `${CUBE.ad_connector_source}`,
    },

    count_distinct_approx_ad_connector_source: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_connector_source}`,
    },

    count_distinct_ad_medium_name: {
      type: `count_distinct`,
      sql: `${CUBE.ad_medium_name}`,
    },

    count_distinct_approx_ad_medium_name: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_medium_name}`,
    },

    count_distinct_ad_name: {
      type: `count_distinct`,
      sql: `${CUBE.ad_name}`,
    },

    count_distinct_approx_ad_name: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_name}`,
    },

    count_distinct_ad_text: {
      type: `count_distinct`,
      sql: `${CUBE.ad_text}`,
    },

    count_distinct_approx_ad_text: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_text}`,
    },

    count_distinct_ad_url: {
      type: `count_distinct`,
      sql: `${CUBE.ad_url}`,
    },

    count_distinct_approx_ad_url: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_url}`,
    },

  },

});