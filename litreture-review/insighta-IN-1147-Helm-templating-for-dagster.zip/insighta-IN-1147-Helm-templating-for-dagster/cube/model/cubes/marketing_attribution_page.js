import { requireFilterParam } from './utils/filter_enforcement';

const refresh_sql_fanned_out_value_summary_table = `select count(*) from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_fanned_out_value_summary`;

const refresh_key_sql_fanned_out_value_summary = `
  ${refresh_sql_fanned_out_value_summary_table}
`;

cube(`cube_marketing_attribution_page`, {

  extends: auto_generated_base_cube_marketing_attribution_page,

  title: `value_summary`,

  description: `
    IMPORTANT: if you query this cube you have to filter on ALL of these:
    * attribution_model_name
    * future_value_horizon_days
    * marketing level

    This is a fanned out join across all the tables that are needed to calculate value. They fan out marketing apportionments by the permutation of those two columns.

    This cube should not join to any other cube.

    If you want to use a time dimension (e.g. to filter), use the apportionment date conversion or apportionment date cost on this cube.
  `,
  
  refresh_key: {
    sql: refresh_key_sql_fanned_out_value_summary,
  },

  sql: `with

    xa_fanned_out_value_summary as (
      select * from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_fanned_out_value_summary
    ),

    enforce_filtering_that_removes_fan_out as (

      select * from xa_fanned_out_value_summary where true
      
        and ${requireFilterParam(
          FILTER_PARAMS.cube_marketing_attribution_page.attribution_model_name.filter('attribution_model_name'),
          'attribution_model_name',
          CUBE,
        )}
        and ${requireFilterParam(
          FILTER_PARAMS.cube_marketing_attribution_page.future_value_horizon_days.filter('future_value_horizon_days'),
          'future_value_horizon_days',
          CUBE,
        )}
        and ${requireFilterParam(
          FILTER_PARAMS.cube_marketing_attribution_page.marketing_level.filter('marketing_level'),
          'marketing_level',
          CUBE,
        )}

    ),

    value_summary_filtered_by_time_range_for_fractional_customer_calc as (
    
      select enforce_filtering_that_removes_fan_out.*
      
      from enforce_filtering_that_removes_fan_out

      where true

        and ${FILTER_PARAMS.cube_marketing_attribution_page.apportionment_date_conversion.filter('cast( apportionment_date_conversion as timestamp )')}
        and ${FILTER_PARAMS.cube_marketing_attribution_page.apportionment_date_cost.filter('cast( apportionment_date_cost as timestamp )')}

    ),

    value_summary_with_fractional_customers as (

        select *,


          case 
            when is_first_conversion_of_customer
            then 
              safe_divide(
                ratio_value_attribution,
                sum(ratio_value_attribution) over (partition by conversion_contact_blended_key, is_first_conversion_of_customer)
              )
            else 0
          end as fractional_new_customers_within_filtered_time_range,

          case 
            when not is_first_conversion_of_customer
            then 
              safe_divide(
                ratio_value_attribution,
                sum(ratio_value_attribution) over (partition by conversion_contact_blended_key, is_first_conversion_of_customer)
              )
            else 0
          end as fractional_existing_customers_within_filtered_time_range,

          safe_divide(

                ratio_value_attribution,

                sum(ratio_value_attribution)
                over (partition by conversion_contact_blended_key)
                
            )
            
            as fractional_customers_within_filtered_time_range,

        from value_summary_filtered_by_time_range_for_fractional_customer_calc

    )

    select * from value_summary_with_fractional_customers
  
  `,
  
  dimensions: {

    fractional_new_customer: {
      sql: `fractional_new_customers_within_filtered_time_range`,
      type: `number`,
    },

    fractional_existing_customer: {
      sql: `fractional_existing_customers_within_filtered_time_range`,
      type: `number`,
    },
    
    fractional_customer: {
      sql: `fractional_customers_within_filtered_time_range`,
      type: `number`,
    },

  },
 
  measures: {

    number_roas_immediate: {
      type: `number`,
      sql: `SAFE_DIVIDE(
        ${CUBE.sum_amount_value_attributed_immediate},
        ${CUBE.sum_amount_cost_apportioned}
      )`,
    },

    number_roas_incremental_lifetime: {
      type: `number`,
      sql: `SAFE_DIVIDE(
        ${CUBE.sum_amount_value_attributed_incremental_lifetime_value},
        ${CUBE.sum_amount_cost_apportioned}
      )`,
    },

    number_roas_incremental_future: {
      type: `number`,
      sql: `SAFE_DIVIDE(
        ${CUBE.sum_amount_value_attributed_future_value},
        ${CUBE.sum_amount_cost_apportioned}
      )`,
    },

    number_cost_per_conversion: {
      type: `number`,
      sql: `SAFE_DIVIDE(
        ${CUBE.sum_amount_cost_apportioned},
        ${CUBE.sum_conversions}
      )`,
    },

    number_cost_per_customer: {
      type: `number`,
      sql: `SAFE_DIVIDE(
        ${CUBE.sum_amount_cost_apportioned},
        ${CUBE.sum_fractional_customer}
      )`,
    },

    sum_fractional_new_customer: {
      type: `sum`,
      sql: `${CUBE.fractional_new_customer}`,
    },

    sum_fractional_existing_customer: {
      type: `sum`,
      sql: `${CUBE.fractional_existing_customer}`,
    },
    
    sum_fractional_customer: {
      type: `sum`,
      sql: `${CUBE.fractional_customer}`,
    },
    
  },

});


// the cube below is auto generated with Cube Code Generator spreadsheet https://drive.google.com/drive/folders/18eblS2J3nWqhHoL1fiBte154bDTg2rMG
// the cube above is manually maintained and extends the cube below
// ideally, the base and extending cubes would be in separate files (improvement opportunity)
// the top one would be named xa_fanned_out_value_summary.js and the bottom one xa_fanned_out_value_summary_base.js
const auto_generated_base_cube_marketing_attribution_page = cube(`auto_generated_base_cube_marketing_attribution_page`, {
  
  sql: `placeholder`,
  
  dimensions: {
    
    conversion_compound_key: {
      sql: `conversion_compound_key`,
      type: `string`,
    },

    conversion_contact_blended_key: {
      shown: false,
      sql: `conversion_contact_blended_key`,
      type: `string`,
    },

    conversion_natural_key: {
      sql: `conversion_natural_key`,
      type: `string`,
    },

    apportionment_date_conversion: {
      sql: `cast( apportionment_date_conversion as timestamp )`,
      type: `time`,
    },

    apportionment_date_cost: {
      sql: `cast( apportionment_date_cost as timestamp )`,
      type: `time`,
    },

    attribution_model_name: {
      sql: `attribution_model_name`,
      type: `string`,
    },

    future_value_horizon_days: {
      sql: `future_value_horizon_days`,
      type: `number`,
    },

    marketing_level: {
      sql: `marketing_level`,
      type: `string`,
    },

    is_first_conversion_of_customer: {
      sql: `is_first_conversion_of_customer`,
      type: `boolean`,
    },

    conversion_sequence_number: {
      sql: `conversion_sequence_number`,
      type: `number`,
    },

    conversion_is_marketing_attributed: {
      sql: `conversion_is_marketing_attributed`,
      type: `boolean`,
    },

    distinct_attributed_marketing_level_connector_sources: {
      sql: `distinct_attributed_marketing_level_connector_sources`,
      type: `string`,
    },

    distinct_attributed_marketing_level_campaign_or_ad_names: {
      sql: `distinct_attributed_marketing_level_campaign_or_ad_names`,
      type: `string`,
    },

    marketing_connector_source: {
      sql: `marketing_connector_source`,
      type: `string`,
    },

    campaign_name: {
      sql: `campaign_name`,
      type: `string`,
    },

    conversion_type: {
      sql: `conversion_type`,
      type: `string`,
    },

    ad_natural_key: {
      sql: `ad_natural_key`,
      type: `string`,
    },

    ad_name: {
      sql: `ad_name`,
      type: `string`,
    },

    ad_text: {
      sql: `ad_text`,
      type: `string`,
    },

    ad_url: {
      sql: `ad_url`,
      type: `string`,
    },

    amount_value_attributed_immediate: {
      sql: `amount_value_attributed_immediate`,
      type: `number`,
    },

    amount_value_attributed_incremental_lifetime_value: {
      sql: `amount_value_attributed_incremental_lifetime_value`,
      type: `number`,
    },

    amount_value_attributed_future_value: {
      sql: `amount_value_attributed_future_value`,
      type: `number`,
    },

    amount_cost_apportioned: {
      sql: `amount_cost_apportioned`,
      type: `number`,
    },

    ratio_value_attribution: {
      sql: `ratio_value_attribution`,
      type: `number`,
    },

  },
  
  measures: {
    
    count_distinct_conversion_compound_key: {
      type: `count_distinct`,
      sql: `${CUBE.conversion_compound_key}`,
    },

    min_apportionment_date_conversion: {
      type: `min`,
      sql: `${CUBE.apportionment_date_conversion}`,
    },

    max_apportionment_date_conversion: {
      type: `max`,
      sql: `${CUBE.apportionment_date_conversion}`,
    },

    count_distinct_apportionment_date_conversion: {
      type: `count_distinct`,
      sql: `${CUBE.apportionment_date_conversion}`,
    },

    min_apportionment_date_cost: {
      type: `min`,
      sql: `${CUBE.apportionment_date_cost}`,
    },

    max_apportionment_date_cost: {
      type: `max`,
      sql: `${CUBE.apportionment_date_cost}`,
    },

    count_distinct_apportionment_date_cost: {
      type: `count_distinct`,
      sql: `${CUBE.apportionment_date_cost}`,
    },

    min_conversion_sequence_number: {
      type: `min`,
      sql: `${CUBE.conversion_sequence_number}`,
    },

    max_conversion_sequence_number: {
      type: `max`,
      sql: `${CUBE.conversion_sequence_number}`,
    },

    count_distinct_marketing_connector_source: {
      type: `count_distinct`,
      sql: `${CUBE.marketing_connector_source}`,
    },

    count_distinct_campaign_name: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_name}`,
    },

    count_distinct_ad_natural_key: {
      type: `count_distinct`,
      sql: `${CUBE.ad_natural_key}`,
    },

    count_distinct_ad_name: {
      type: `count_distinct`,
      sql: `${CUBE.ad_name}`,
    },

    sum_amount_value_attributed_immediate: {
      type: `sum`,
      sql: `${CUBE.amount_value_attributed_immediate}`,
    },

    avg_amount_value_attributed_immediate: {
      type: `avg`,
      sql: `${CUBE.amount_value_attributed_immediate}`,
    },

    min_amount_value_attributed_immediate: {
      type: `min`,
      sql: `${CUBE.amount_value_attributed_immediate}`,
    },

    max_amount_value_attributed_immediate: {
      type: `max`,
      sql: `${CUBE.amount_value_attributed_immediate}`,
    },

    sum_amount_value_attributed_incremental_lifetime_value: {
      type: `sum`,
      sql: `${CUBE.amount_value_attributed_incremental_lifetime_value}`,
    },

    avg_amount_value_attributed_incremental_lifetime_value: {
      type: `avg`,
      sql: `${CUBE.amount_value_attributed_incremental_lifetime_value}`,
    },

    min_amount_value_attributed_incremental_lifetime_value: {
      type: `min`,
      sql: `${CUBE.amount_value_attributed_incremental_lifetime_value}`,
    },

    max_amount_value_attributed_incremental_lifetime_value: {
      type: `max`,
      sql: `${CUBE.amount_value_attributed_incremental_lifetime_value}`,
    },

    sum_amount_value_attributed_future_value: {
      type: `sum`,
      sql: `${CUBE.amount_value_attributed_future_value}`,
    },

    avg_amount_value_attributed_future_value: {
      type: `avg`,
      sql: `${CUBE.amount_value_attributed_future_value}`,
    },

    min_amount_value_attributed_future_value: {
      type: `min`,
      sql: `${CUBE.amount_value_attributed_future_value}`,
    },

    max_amount_value_attributed_future_value: {
      type: `max`,
      sql: `${CUBE.amount_value_attributed_future_value}`,
    },

    sum_amount_cost_apportioned: {
      type: `sum`,
      sql: `${CUBE.amount_cost_apportioned}`,
    },

    avg_amount_cost_apportioned: {
      type: `avg`,
      sql: `${CUBE.amount_cost_apportioned}`,
    },

    min_amount_cost_apportioned: {
      type: `min`,
      sql: `${CUBE.amount_cost_apportioned}`,
    },

    max_amount_cost_apportioned: {
      type: `max`,
      sql: `${CUBE.amount_cost_apportioned}`,
    },

    sum_conversions: {
      type: `sum`,
      sql: `${CUBE.ratio_value_attribution}`,
    },

  },

});