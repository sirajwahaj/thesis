import { requireFilterParam } from './utils/filter_enforcement';

const refresh_sql_fanned_out_value_summary_table = `select count(*) from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_merchandising_fanned_out_value_summary`;

const refresh_key_sql_fanned_out_value_summary = `
  ${refresh_sql_fanned_out_value_summary_table}
`;

cube(`cube_merchandising_analytics_page`, {

  extends: auto_generated_base_cube_merchandising_analytics_page,

  title: `value_summary`,

  description: `
    IMPORTANT: if you query this cube you have to filter on ALL of these:
    * future_value_horizon_days

    This is a fanned out join across all the tables that are needed to calculate value. They fan out orders to line orders to sku by the permutation of those columns.

    This cube should not join to any other cube.

    If you want to use a time dimension (e.g. to filter), use the conversion timestamp.
  `,
  
  refresh_key: {
    sql: refresh_key_sql_fanned_out_value_summary,
  },

  sql: `with

    xa_merchandising_fanned_out_value_summary as (
      select * from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_merchandising_fanned_out_value_summary
    ),

    enforce_filtering_that_removes_fan_out as (

      select * from xa_merchandising_fanned_out_value_summary where true
      
        and ${requireFilterParam(
          FILTER_PARAMS.cube_merchandising_analytics_page.future_value_horizon_days.filter('future_value_horizon_days'),
          'future_value_horizon_days',
          CUBE,
        )}

    ),

    value_summary_filtered_by_time_range as (
    
      select enforce_filtering_that_removes_fan_out.*
      
      from enforce_filtering_that_removes_fan_out

      where true

        and ${FILTER_PARAMS.cube_merchandising_analytics_page.conversion_timestamp.filter('cast( conversion_timestamp as timestamp )')}
        and ${FILTER_PARAMS.cube_merchandising_analytics_page.conversion_timestamp.filter('cast( conversion_timestamp as timestamp )')}

    )

    select * from value_summary_filtered_by_time_range
  
  `,
 
  measures: {

    number_roas_immediate: {
      type: `number`,
      sql: `SAFE_DIVIDE(
        ${CUBE.sum_conversion_value_immediate_attributed},
        ${CUBE.sum_conversion_amount_cost_apportioned_campaign_attributed}
      )`,
    },

    number_incremental_lifetime_per_qty: {
      type: `number`,
      sql: `SAFE_DIVIDE( 
        ${CUBE.sum_conversion_value_incremental_lifetime_value_attributed},
        ${CUBE.sum_order_line_quantity}
      )`,
    },

    number_cac: {
      type: `number`,
      sql: `SAFE_DIVIDE(
        ${CUBE.sum_new_customer_conversion_amount_cost_apportioned_campaign_attributed},
        ${CUBE.sum_new_customer_ratio_line_item}
      )`,
    },

    perc_rank_roas: {
      type: `number`,
      sql: `percent_rank() over (partition by ${CUBE.sku_attribute_group_name} order by ${CUBE.number_roas_immediate} asc)`,
    },

    perc_rank_cac: {
      type: `number`,
      sql: `percent_rank() over (partition by ${CUBE.sku_attribute_group_name} order by ${CUBE.number_cac} desc)`,
    },

    quadrant: {
      type: `number`,
      sql: `case 
              when ${CUBE.perc_rank_roas} >= .5 and ${CUBE.perc_rank_cac} >= .5 and ${CUBE.number_cac} is not null then 1
              when ${CUBE.perc_rank_roas} >= 0 and ${CUBE.perc_rank_cac} >= .5 then 2
              when ${CUBE.perc_rank_roas} < .5 and ${CUBE.perc_rank_cac} < .5 then 3
              when ${CUBE.perc_rank_roas} < 1 and ${CUBE.perc_rank_cac} < .5 then 4
              else 5
            end`,
    },
    
  },

});


// the cube below is auto generated with Cube Code Generator spreadsheet https://drive.google.com/drive/folders/18eblS2J3nWqhHoL1fiBte154bDTg2rMG
// the cube above is manually maintained and extends the cube below
// ideally, the base and extending cubes would be in separate files (improvement opportunity)
// the top one would be named xa_merchandising_fanned_out_value_summary.js and the bottom one xa_merchandising_fanned_out_value_summary_base.js
const auto_generated_base_cube_merchandising_analytics_page = cube(`auto_generated_base_cube_merchandising_analytics_page`, {
  
  sql: `placeholder`,
  
  dimensions: {
    
    sku_natural_key: {
      sql: `sku_natural_key`,
      type: `string`,
    },

    conversion_contact_blended_key: {
      sql: `conversion_contact_blended_key`,
      type: `string`,
    },
    
    attribute_value: {
      sql: `attribute_value`,
      type: `string`,
    },
    
    distinct_attributed_campaign_connector_sources: {
      sql: `distinct_attributed_campaign_connector_sources`,
      type: `string`,
    },
    
    distinct_attributed_campaign_names: {
      sql: `distinct_attributed_campaign_names`,
      type: `string`,
    },
    
    sku_attribute_group_name: {
      sql: `sku_attribute_group_name`,
      type: `string`,
    },
    
    conversion_timestamp: {
      sql: `cast( conversion_timestamp as timestamp )`,
      type: `time`,
    },

    future_value_horizon_days: {
      sql: `future_value_horizon_days`,
      type: `number`,
    },

    conversion_sequence_number: {
      sql: `conversion_sequence_number`,
      type: `number`,
    },

    conversion_type: {
      sql: `conversion_type`,
      type: `string`,
    },

    conversion_is_marketing_attributed: {
      sql: `conversion_is_marketing_attributed`,
      type: `boolean`,
    },

    conversion_amount_cost_apportioned_campaign_attributed: {
      sql: `conversion_amount_cost_apportioned_campaign_attributed`,
      type: `number`,
    },

    conversion_value_immediate_attributed: {
      sql: `conversion_value_immediate_attributed`,
      type: `number`,
    },

    conversion_value_incremental_lifetime_value_attributed: {
      sql: `conversion_value_incremental_lifetime_value_attributed`,
      type: `number`,
    },

    order_line_quantity: {
      sql: `order_line_quantity`,
      type: `number`,
    },

    ratio_line_item: {
      sql: `ratio_line_item`,
      type: `number`,
    },

  },
  
  measures: {
    
    min_conversion_timestamp: {
      type: `min`,
      sql: `${CUBE.conversion_timestamp}`,
    },

    max_conversion_timestamp: {
      type: `max`,
      sql: `${CUBE.conversion_timestamp}`,
    },

    min_conversion_sequence_number: {
      type: `min`,
      sql: `${CUBE.conversion_sequence_number}`,
    },

    max_conversion_sequence_number: {
      type: `max`,
      sql: `${CUBE.conversion_sequence_number}`,
    },

    sum_conversion_amount_cost_apportioned_campaign_attributed: {
      type: `sum`,
      sql: `${CUBE.conversion_amount_cost_apportioned_campaign_attributed}`,
    },

    sum_conversion_value_immediate_attributed: {
      type: `sum`,
      sql: `${CUBE.conversion_value_immediate_attributed}`,
    },

    sum_conversion_value_incremental_lifetime_value_attributed: {
      type: `sum`,
      sql: `${CUBE.conversion_value_incremental_lifetime_value_attributed}`,
    },

    sum_order_line_quantity: {
      type: `sum`,
      sql: `${CUBE.order_line_quantity}`,
    },

    count_distinct_conversion_contact_blended_key: {
      type: `count_distinct`,
      sql: `${CUBE.conversion_contact_blended_key}`,
    },

    sum_new_customer_conversion_amount_cost_apportioned_campaign_attributed: {
      type: `sum`,
      sql: `case when ${CUBE.conversion_sequence_number} = 1 then ${CUBE.conversion_amount_cost_apportioned_campaign_attributed} else 0 end`,
    },

    sum_new_customer_ratio_line_item: {
      type: `sum`,
      sql: `case when ${CUBE.conversion_sequence_number} = 1 then ${CUBE.ratio_line_item} else 0 end`,
    },

  },

});