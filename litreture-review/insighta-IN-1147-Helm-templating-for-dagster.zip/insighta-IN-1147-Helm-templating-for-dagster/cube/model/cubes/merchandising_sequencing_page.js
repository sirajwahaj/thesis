import { requireFilterParam } from './utils/filter_enforcement';

const refresh_sql_sequencing_summary = `select count(*) from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_merchandising_order_sequencing_summary`;

const refresh_key_sql_sequencing_summary = `
  ${refresh_sql_sequencing_summary}
`;

cube(`cube_merchandising_order_sequencing_page`, {

  title: `value_summary`,

  description: `
    IMPORTANT: if you query this cube you have to filter on ALL of these:
    * future_value_horizon_days
    * conversion_sequence_number
    * conversion_timestamp
    * first_conversion_timestamp

    This is a fanned out join across all the tables that are needed to calculate value. They fan out orders to line orders to sku by the permutation of those columns.

    This cube should not join to any other cube.
  `,
  
  refresh_key: {
    sql: refresh_key_sql_sequencing_summary,
  },

  sql: `with

    xa_merchandising_order_sequencing_summary as (
      select * from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_merchandising_order_sequencing_summary
    ),

    enforce_filtering_that_removes_fan_out as (

      select
        distinct
        attribute_value,
        conversion_contact_blended_key,
        conversion_sequence_number,
        conversion_timestamp,
        future_value_amount,
        future_value_horizon_days,
        first_attribute_value,
        first_conversion_timestamp,
        first_sku_attribute_group_name,
      
      from xa_merchandising_order_sequencing_summary where true
      
        and ${requireFilterParam(
          FILTER_PARAMS.cube_merchandising_order_sequencing_page.future_value_horizon_days.filter('future_value_horizon_days'),
          'future_value_horizon_days',
          CUBE,
        )}

        and ${requireFilterParam(
          FILTER_PARAMS.cube_merchandising_order_sequencing_page.conversion_sequence_number.filter('conversion_sequence_number'),
          'conversion_sequence_number',
          CUBE,
        )}

        and ${requireFilterParam(
          FILTER_PARAMS.cube_merchandising_order_sequencing_page.first_conversion_timestamp.filter('first_conversion_timestamp'),
          'first_conversion_timestamp',
          CUBE,
        )}

        and ${requireFilterParam(
          FILTER_PARAMS.cube_merchandising_order_sequencing_page.conversion_timestamp.filter('conversion_timestamp'),
          'conversion_timestamp',
          CUBE,
        )}

        and first_sku_attribute_group_name = sku_attribute_group_name

    ),

    agg as (
    
      select 
        attribute_value,
        conversion_sequence_number,
        future_value_horizon_days,
        first_attribute_value,
        first_sku_attribute_group_name,
        avg(future_value_amount) avg_future_value_amount,
        count(distinct conversion_contact_blended_key) number_distinct_customers,
        min(conversion_timestamp) as conversion_timestamp,
        min(first_conversion_timestamp) as first_conversion_timestamp
      from enforce_filtering_that_removes_fan_out
      group by all

    ),

    eligible as (
    
      select *
      from agg
      where true
        and ${FILTER_PARAMS.cube_merchandising_order_sequencing_page.customers_in_group.filter('number_distinct_customers')}
      
    ),


  scored as (

    select
      *,

      percentile_cont(avg_future_value_amount, 0.5) over (
        partition by first_sku_attribute_group_name,
                    first_attribute_value,
                    conversion_sequence_number
      ) as median_future_value_amount_by_first_attribute_value,
      
      avg_future_value_amount/nullif(percentile_cont(avg_future_value_amount, 0.5) over (
        partition by first_sku_attribute_group_name,
                    first_attribute_value,
                    conversion_sequence_number
      ), 0) as ltv_index,

      max(conversion_sequence_number) over (
        partition by first_sku_attribute_group_name,
                    first_attribute_value
      ) as max_conv_seq_number,

      max(number_distinct_customers) over (
        partition by first_sku_attribute_group_name,
                    first_attribute_value
      ) as max_number_customers

    from eligible

  )

  select * from scored where true
  
  `,
 
  dimensions: {
    attribute_value: { sql: `attribute_value`, type: `string` },
    conversion_sequence_number: { sql: `conversion_sequence_number`, type: `number` },
    conversion_timestamp: {sql: `cast(conversion_timestamp as timestamp)`, type: `time`},
    customers_in_group: {sql: `number_distinct_customers`, type: `number`},
    future_value_horizon_days: { sql: `future_value_horizon_days`, type: `number` },
    first_attribute_value: { sql: `first_attribute_value`, type: `string` },
    first_conversion_timestamp: {sql: `cast(first_conversion_timestamp as timestamp)`, type: `time`},
    first_sku_attribute_group_name: { sql: `first_sku_attribute_group_name`, type: `string` },
  },

  measures: {
    avg_future_value_amount: { type: `max`, sql: `${CUBE}.avg_future_value_amount` },
    median_future_value_amount: { type: `max`, sql: `${CUBE}.median_future_value_amount_by_first_attribute_value` },
    ltv_index:  { type: `max`, sql: `${CUBE}.ltv_index` },
    max_conv_seq_number: { type: `max`, sql: `${CUBE}.max_conv_seq_number` },
    max_number_customers: { type: `max`, sql: `${CUBE}.max_number_customers` },
    number_distinct_customers: { type: `max`, sql: `${CUBE}.number_distinct_customers` },
  },

});