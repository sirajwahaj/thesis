cube(`cube_ad_summary_daily`, {

  extends: auto_generated_base_cube_ad_summary_daily,

  refresh_key: {
    sql: `select max(ad_summary_daily_date) || '-' || count(*) from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_ad_summary_daily`,
  },

  sql: `select * from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_ad_summary_daily`,
  
  joins: {

    cube_ads: {
      sql: `${CUBE.ad_fk} = ${cube_ads.ad_pk}`,
      relationship: `many_to_one`,
    },

  },
  
  dimensions: {

  },
 
  measures: {

    count_ad_summary_daily: {
      type: `count`,
    },

    number_click_through_rate: {
      description: `CTR. Clicks divided by impressions.`,
      type: `number`,
      sql: `safe_divide(
        ${CUBE.sum_ad_summary_daily_clicks},
        ${CUBE.sum_ad_summary_daily_impressions}
        )`,
    },

    number_cost_per_click: {
      description: `CPC. Cost incurred divided by clicks.`,
      type: `number`,
      sql: `safe_divide(
        ${CUBE.sum_ad_summary_daily_cost_incurred},
        ${CUBE.sum_ad_summary_daily_clicks}
        )`,
    },

    number_cost_per_mille: {
      description: `CPM. Cost incurred divided by thousands of impressions.`,
      type: `number`,
      sql: `safe_divide(
        ${CUBE.sum_ad_summary_daily_cost_incurred},
        ${CUBE.sum_ad_summary_daily_impressions} / 1000
        )`,
    },

    number_cost_per_order: {
      description: `CPO as reported by the platform. Generally not accurate. Cost incurred divided by conversions.`,
      type: `number`,
      sql: `safe_divide(
        ${CUBE.sum_ad_summary_daily_cost_incurred},
        ${CUBE.sum_ad_summary_daily_conversions}
        )`,
    },

    number_conversion_value_over_cost: {
      description: `ROAS as reported by the platform. Generally not accurate. Conversion value divided by cost incurred.`,
      type: `number`,
      sql: `safe_divide(
        ${CUBE.sum_ad_summary_daily_conversions_value},
        ${CUBE.sum_ad_summary_daily_cost_incurred}
        )`,
    },

  },


});


// the cube below is auto generated with Cube Code Generator spreadsheet https://drive.google.com/drive/folders/18eblS2J3nWqhHoL1fiBte154bDTg2rMG
// the cube above is manually maintained and extends the cube below
// ideally, the base and extending cubes would be in separate files (improvement opportunity)
// the top one would be named xa_ad_summary_daily.js and the bottom one xa_ad_summary_daily_base.js
const auto_generated_base_cube_ad_summary_daily = cube(`auto_generated_base_cube_ad_summary_daily`, {
  
  sql: `placeholder`,
  
  dimensions: {
    
    ad_summary_daily_pk: {
      shown: false,
      primary_key: true,
      sql: `ad_summary_daily_pk`,
      type: `string`,
    },

    ad_fk: {
      shown: false,
      sql: `ad_fk`,
      type: `string`,
    },

    ad_summary_daily_connector_source: {
      sql: `ad_summary_daily_connector_source`,
      type: `string`,
    },

    ad_summary_daily_clicks: {
      sql: `ad_summary_daily_clicks`,
      type: `number`,
    },

    ad_summary_daily_conversions: {
      sql: `ad_summary_daily_conversions`,
      type: `number`,
    },

    ad_summary_daily_conversions_value: {
      sql: `ad_summary_daily_conversions_value`,
      type: `number`,
    },

    ad_summary_daily_cost_incurred: {
      sql: `ad_summary_daily_cost_incurred`,
      type: `number`,
    },

    ad_summary_daily_cost_allocatable: {
      sql: `ad_summary_daily_cost_allocatable`,
      type: `number`,
    },

    ad_summary_daily_impressions: {
      sql: `ad_summary_daily_impressions`,
      type: `number`,
    },

    ad_summary_daily_date: {
      sql: `cast( ad_summary_daily_date as timestamp )`,
      type: `time`,
    },

  },
  
  measures: {
    
    count_distinct_ad_summary_daily_connector_source: {
      type: `count_distinct`,
      sql: `${CUBE.ad_summary_daily_connector_source}`,
    },

    count_distinct_approx_ad_summary_daily_connector_source: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_summary_daily_connector_source}`,
    },

    sum_ad_summary_daily_clicks: {
      type: `sum`,
      sql: `${CUBE.ad_summary_daily_clicks}`,
    },

    avg_ad_summary_daily_clicks: {
      type: `avg`,
      sql: `${CUBE.ad_summary_daily_clicks}`,
    },

    min_ad_summary_daily_clicks: {
      type: `min`,
      sql: `${CUBE.ad_summary_daily_clicks}`,
    },

    max_ad_summary_daily_clicks: {
      type: `max`,
      sql: `${CUBE.ad_summary_daily_clicks}`,
    },

    count_distinct_ad_summary_daily_clicks: {
      type: `count_distinct`,
      sql: `${CUBE.ad_summary_daily_clicks}`,
    },

    count_distinct_approx_ad_summary_daily_clicks: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_summary_daily_clicks}`,
    },

    sum_ad_summary_daily_conversions: {
      type: `sum`,
      sql: `${CUBE.ad_summary_daily_conversions}`,
    },

    avg_ad_summary_daily_conversions: {
      type: `avg`,
      sql: `${CUBE.ad_summary_daily_conversions}`,
    },

    min_ad_summary_daily_conversions: {
      type: `min`,
      sql: `${CUBE.ad_summary_daily_conversions}`,
    },

    max_ad_summary_daily_conversions: {
      type: `max`,
      sql: `${CUBE.ad_summary_daily_conversions}`,
    },

    count_distinct_ad_summary_daily_conversions: {
      type: `count_distinct`,
      sql: `${CUBE.ad_summary_daily_conversions}`,
    },

    count_distinct_approx_ad_summary_daily_conversions: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_summary_daily_conversions}`,
    },

    sum_ad_summary_daily_conversions_value: {
      type: `sum`,
      sql: `${CUBE.ad_summary_daily_conversions_value}`,
    },

    avg_ad_summary_daily_conversions_value: {
      type: `avg`,
      sql: `${CUBE.ad_summary_daily_conversions_value}`,
    },

    min_ad_summary_daily_conversions_value: {
      type: `min`,
      sql: `${CUBE.ad_summary_daily_conversions_value}`,
    },

    max_ad_summary_daily_conversions_value: {
      type: `max`,
      sql: `${CUBE.ad_summary_daily_conversions_value}`,
    },

    count_distinct_ad_summary_daily_conversions_value: {
      type: `count_distinct`,
      sql: `${CUBE.ad_summary_daily_conversions_value}`,
    },

    count_distinct_approx_ad_summary_daily_conversions_value: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_summary_daily_conversions_value}`,
    },

    sum_ad_summary_daily_cost_incurred: {
      type: `sum`,
      sql: `${CUBE.ad_summary_daily_cost_incurred}`,
    },

    avg_ad_summary_daily_cost_incurred: {
      type: `avg`,
      sql: `${CUBE.ad_summary_daily_cost_incurred}`,
    },

    min_ad_summary_daily_cost_incurred: {
      type: `min`,
      sql: `${CUBE.ad_summary_daily_cost_incurred}`,
    },

    max_ad_summary_daily_cost_incurred: {
      type: `max`,
      sql: `${CUBE.ad_summary_daily_cost_incurred}`,
    },

    count_distinct_ad_summary_daily_cost_incurred: {
      type: `count_distinct`,
      sql: `${CUBE.ad_summary_daily_cost_incurred}`,
    },

    count_distinct_approx_ad_summary_daily_cost_incurred: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_summary_daily_cost_incurred}`,
    },

    sum_ad_summary_daily_cost_allocatable: {
      type: `sum`,
      sql: `${CUBE.ad_summary_daily_cost_allocatable}`,
    },

    avg_ad_summary_daily_cost_allocatable: {
      type: `avg`,
      sql: `${CUBE.ad_summary_daily_cost_allocatable}`,
    },

    min_ad_summary_daily_cost_allocatable: {
      type: `min`,
      sql: `${CUBE.ad_summary_daily_cost_allocatable}`,
    },

    max_ad_summary_daily_cost_allocatable: {
      type: `max`,
      sql: `${CUBE.ad_summary_daily_cost_allocatable}`,
    },

    count_distinct_ad_summary_daily_cost_allocatable: {
      type: `count_distinct`,
      sql: `${CUBE.ad_summary_daily_cost_allocatable}`,
    },

    count_distinct_approx_ad_summary_daily_cost_allocatable: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_summary_daily_cost_allocatable}`,
    },

    sum_ad_summary_daily_impressions: {
      type: `sum`,
      sql: `${CUBE.ad_summary_daily_impressions}`,
    },

    avg_ad_summary_daily_impressions: {
      type: `avg`,
      sql: `${CUBE.ad_summary_daily_impressions}`,
    },

    min_ad_summary_daily_impressions: {
      type: `min`,
      sql: `${CUBE.ad_summary_daily_impressions}`,
    },

    max_ad_summary_daily_impressions: {
      type: `max`,
      sql: `${CUBE.ad_summary_daily_impressions}`,
    },

    count_distinct_ad_summary_daily_impressions: {
      type: `count_distinct`,
      sql: `${CUBE.ad_summary_daily_impressions}`,
    },

    count_distinct_approx_ad_summary_daily_impressions: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_summary_daily_impressions}`,
    },

    min_ad_summary_daily_date: {
      type: `min`,
      sql: `${CUBE.ad_summary_daily_date}`,
    },

    max_ad_summary_daily_date: {
      type: `max`,
      sql: `${CUBE.ad_summary_daily_date}`,
    },

    count_distinct_ad_summary_daily_date: {
      type: `count_distinct`,
      sql: `${CUBE.ad_summary_daily_date}`,
    },

    count_distinct_approx_ad_summary_daily_date: {
      type: `count_distinct_approx`,
      sql: `${CUBE.ad_summary_daily_date}`,
    },

  },

});