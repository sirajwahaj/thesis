cube(`cube_executive_summary_page`, {

  refresh_key: {
    sql: `select max(conversion_timestamp) || '-' || count(*) from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_conversions`,
  },

  // sql: `select * from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_conversions`,

  sql: `
  select
    conversion_pk,
    contact_fk,
    conversion_timestamp,
    conversion_channel,
    conversion_sub_channel,
    conversion_type,
    conversion_is_directly_attributable,
    conversion_sequence_number,
    conversion_value_immediate,
    false as is_total_channel_row
  from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_conversions

  union all

  select
    conversion_pk,
    contact_fk,
    conversion_timestamp,
    'total' as conversion_channel,
    conversion_sub_channel,
    conversion_type,
    conversion_is_directly_attributable,
    conversion_sequence_number,
    conversion_value_immediate,
    true as is_total_channel_row
  from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_conversions`,

  
  
  dimensions: {
    
    conversion_pk: {
      shown: false,
      primary_key: true,
      sql: `conversion_pk`,
      type: `string`,
    },

    contact_fk: {
      shown: false,
      sql: `contact_fk`,
      type: `string`,
    },

    conversion_timestamp: {
      sql: `conversion_timestamp`,
      type: `time`,
    },

    conversion_channel: {
      sql: `conversion_channel`,
      type: `string`,
    },

    conversion_sub_channel: {
      sql: `conversion_sub_channel`,
      type: `string`,
    },

    conversion_type: {
      sql: `conversion_type`,
      type: `string`,
    },

    conversion_is_directly_attributable: {
      sql: `conversion_is_directly_attributable`,
      type: `boolean`,
    },

    conversion_sequence_number: {
      sql: `conversion_sequence_number`,
      type: `number`,
    },

    conversion_value_immediate: {
      shown: false,
      sql: `conversion_value_immediate`,
      type: `number`,
    },

  },
 
  measures: {

    sum_conversion_value_immediate: {
      description: `Total conversion value.`,
      type: `sum`,
      sql: `${CUBE.conversion_value_immediate}`,
    },

    number_new_customers: {
      description: `Distinct count of new customers.`,
      type: `count_distinct`,
      sql: `case when ${CUBE.conversion_sequence_number} = 1 then ${CUBE.contact_fk} else null end`,
    },

    number_repeat_customers: {
      description: `Distinct count of repeat customers.`,
      type: `count_distinct`,
      sql: `case when ${CUBE.conversion_sequence_number} > 1 then ${CUBE.contact_fk} else null end`,
    },

    number_conversions: {
      description: `Total number of conversions (orders).`,
      type: `count_distinct`,
      sql: `${CUBE.conversion_pk}`,
    },

    number_aov: {
      description: `Average Order Value. Conversion value divided by conversions.`,
      type: `number`,
      sql: `safe_divide(
        ${CUBE.sum_conversion_value_immediate},
        ${CUBE.number_conversions}
        )`,
    },

  },

});