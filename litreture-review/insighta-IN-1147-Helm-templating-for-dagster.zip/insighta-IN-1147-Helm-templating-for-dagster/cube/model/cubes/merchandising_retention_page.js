import { requireFilterParam } from './utils/filter_enforcement';

const refresh_sql_retention_summary = `select count(*) from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_merchandising_order_retention_summary`;

const refresh_key_sql_retention_summary = `
  ${refresh_sql_retention_summary}
`;

cube(`cube_merchandising_order_retention_page`, {

  title: `value_summary`,

  description: `
    IMPORTANT: if you query this cube you have to filter on ALL of these:
    * future_value_horizon_days
    * conversion_sequence_number
    * conversion_timestamp
    * first_conversion_timestamp

    This is a fanned out join across all the tables that are needed to calculate value. They fan out orders to line orders to sku by the permutation of those columns.

    This cube should not join to any other cube.
  `,
  
  refresh_key: {
    sql: refresh_key_sql_retention_summary,
  },

  sql: `with

    xa_merchandising_order_retention_summary as (
      select * from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_merchandising_order_retention_summary
    ),

    enforce_filtering_that_removes_fan_out as (

      select
        distinct
        conversion_contact_blended_key,
        first_attribute_value,
        first_conversion_timestamp,
        first_sku_attribute_group_name,
        max_conversion_timestamp,
        min_retention_conversion_timestamp,
      
      from xa_merchandising_order_retention_summary where true
      
        and ${requireFilterParam(
          FILTER_PARAMS.cube_merchandising_order_retention_page.first_conversion_timestamp.filter('first_conversion_timestamp'),
          'first_conversion_timestamp',
          CUBE,
        )}

    ),

    agg as (

    select 
      enforce_filtering_that_removes_fan_out.first_sku_attribute_group_name,
      enforce_filtering_that_removes_fan_out.first_attribute_value,
      min(first_conversion_timestamp) first_conversion_timestamp,
      count(distinct conversion_contact_blended_key) number_distinct_customers,
      count(distinct case when first_conversion_timestamp <= timestamp_sub(max_conversion_timestamp, interval 91 day) then conversion_contact_blended_key else null end) number_distinct_customers_91,
      sum(case when first_conversion_timestamp <= timestamp_sub(max_conversion_timestamp, interval 91 day) and timestamp_diff(min_retention_conversion_timestamp, first_conversion_timestamp, day) < 91 then 1 else 0 end) retained_distinct_customers_91,
      count(distinct case when first_conversion_timestamp <= timestamp_sub(max_conversion_timestamp, interval 182 day) then conversion_contact_blended_key else null end) number_distinct_customers_182,
      sum(case when first_conversion_timestamp <= timestamp_sub(max_conversion_timestamp, interval 182 day) and timestamp_diff(min_retention_conversion_timestamp, first_conversion_timestamp, day) < 182 then 1 else 0 end) retained_distinct_customers_182,
      count(distinct case when first_conversion_timestamp <= timestamp_sub(max_conversion_timestamp, interval 364 day) then conversion_contact_blended_key else null end) number_distinct_customers_364,
      sum(case when first_conversion_timestamp <= timestamp_sub(max_conversion_timestamp, interval 364 day) and timestamp_diff(min_retention_conversion_timestamp, first_conversion_timestamp, day) < 364 then 1 else 0 end) retained_distinct_customers_364,
    from enforce_filtering_that_removes_fan_out
    group by all

  ),

  summary as (

    select
        first_sku_attribute_group_name,
        first_attribute_value,
        first_conversion_timestamp,
        number_distinct_customers,

        number_distinct_customers_91,
        retained_distinct_customers_91,
        safe_divide(retained_distinct_customers_91, number_distinct_customers_91) retained_distinct_customers_rate_91,

        number_distinct_customers_182,
        retained_distinct_customers_182,
        safe_divide(retained_distinct_customers_182, number_distinct_customers_182) retained_distinct_customers_rate_182,

        number_distinct_customers_364,
        retained_distinct_customers_364,
        safe_divide(retained_distinct_customers_364, number_distinct_customers_364) retained_distinct_customers_rate_364,

    from agg

  )

  select * from summary where true
  
  `,
 
  dimensions: {
    first_attribute_value: { sql: `first_attribute_value`, type: `string` },
    first_sku_attribute_group_name: { sql: `first_sku_attribute_group_name`, type: `string` },
    first_conversion_timestamp: {sql: `cast(first_conversion_timestamp as timestamp)`, type: `time`},
  },

  measures: {
    number_distinct_customers: { type: `max`, sql: `${CUBE}.number_distinct_customers` },
    number_distinct_customers_91: { type: `max`, sql: `${CUBE}.number_distinct_customers_91` },
    retained_distinct_customers_91: { type: `max`, sql: `${CUBE}.retained_distinct_customers_91` },
    retained_distinct_customers_rate_91: { type: `max`, sql: `${CUBE}.retained_distinct_customers_rate_91` },
    number_distinct_customers_182: { type: `max`, sql: `${CUBE}.number_distinct_customers_182` },
    retained_distinct_customers_182: { type: `max`, sql: `${CUBE}.retained_distinct_customers_182` },
    retained_distinct_customers_rate_182: { type: `max`, sql: `${CUBE}.retained_distinct_customers_rate_182` },
    number_distinct_customers_364: { type: `max`, sql: `${CUBE}.number_distinct_customers_364` },
    retained_distinct_customers_364: { type: `max`, sql: `${CUBE}.retained_distinct_customers_364` },
    retained_distinct_customers_rate_364: { type: `max`, sql: `${CUBE}.retained_distinct_customers_rate_364` },
  },

});