cube(`cube_campaigns`, {

  extends: auto_generated_base_cube_campaigns,

  refresh_key: {
    sql: `select count(*) from ${COMPILE_CONTEXT.securityContext.datasetId}.dim_campaigns`,
  },

  sql: `select * from ${COMPILE_CONTEXT.securityContext.datasetId}.dim_campaigns`,

  joins: {

    cube_campaign_summary_daily: {
      sql: `${CUBE.campaign_pk} = ${cube_campaign_summary_daily.campaign_fk}`,
      relationship: `one_to_many`,
    },
    
  },
  
  dimensions: {

    campaign_pk: {
      shown: true, // reason for extend
      primary_key: true,
      sql: `campaign_pk`,
      type: `string`,
    },

  },
 
  measures: {

    count_campaigns: {
      type: `count`,
    },

    distinct_campaign_names: {
      sql: `string_agg(distinct ${CUBE.campaign_name}, ', ' order by ${CUBE.campaign_name})`,
      type: `string`,
      description: `(a comma-separated string instead of an array) the unique list of campaign names. sorted alphabetically. example: 'facebook, google ads', 'facebook'`,
    },

    distinct_connector_sources: {
      sql: `string_agg(distinct ${CUBE.campaign_connector_source}, ', ' order by ${CUBE.campaign_connector_source})`,
      type: `string`,
      description: `(a comma-separated string instead of an array) the unique list of connector sources, sorted alphabetically. example: 'black friday 2021, summer sale 2021', 'black friday 2021'`,
    },

  },

});


// the cube below is auto generated with Cube Code Generator spreadsheet https://drive.google.com/drive/folders/18eblS2J3nWqhHoL1fiBte154bDTg2rMG
// the cube above is manually maintained and extends the cube below
// ideally, the base and extending cubes would be in separate files (improvement opportunity)
// the top one would be named dim_campaigns.js and the bottom one dim_campaigns_base.js
const auto_generated_base_cube_campaigns = cube(`auto_generated_base_cube_campaigns`, {
  
  sql: `placeholder`,
  
  dimensions: {
    
    campaign_pk: {
      shown: false,
      primary_key: true,
      sql: `campaign_pk`,
      type: `string`,
    },

    is_directly_attributable: {
      shown: true,
      sql: `is_directly_attributable`,
      type: `boolean`,
    },

    campaign_natural_key: {
      sql: `campaign_natural_key`,
      type: `string`,
    },

    campaign_connector_source: {
      sql: `campaign_connector_source`,
      type: `string`,
    },

    campaign_medium_name: {
      sql: `campaign_medium_name`,
      type: `string`,
    },

    campaign_name: {
      sql: `campaign_name`,
      type: `string`,
    },

  },
  
  measures: {
    
    count_distinct_campaign_natural_key: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_natural_key}`,
    },

    count_distinct_approx_campaign_natural_key: {
      type: `count_distinct_approx`,
      sql: `${CUBE.campaign_natural_key}`,
    },

    count_distinct_campaign_connector_source: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_connector_source}`,
    },

    count_distinct_approx_campaign_connector_source: {
      type: `count_distinct_approx`,
      sql: `${CUBE.campaign_connector_source}`,
    },

    count_distinct_campaign_medium_name: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_medium_name}`,
    },

    count_distinct_approx_campaign_medium_name: {
      type: `count_distinct_approx`,
      sql: `${CUBE.campaign_medium_name}`,
    },

    count_distinct_campaign_name: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_name}`,
    },

    count_distinct_approx_campaign_name: {
      type: `count_distinct_approx`,
      sql: `${CUBE.campaign_name}`,
    },

  },

});