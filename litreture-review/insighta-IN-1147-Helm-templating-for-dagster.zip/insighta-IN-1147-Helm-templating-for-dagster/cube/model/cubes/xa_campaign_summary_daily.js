cube(`cube_campaign_summary_daily`, {

  extends: auto_generated_base_cube_campaign_summary_daily,

  refresh_key: {
    sql: `select max(campaign_summary_daily_date) || '-' || count(*) from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_campaign_summary_daily`,
  },

  sql: `select * from ${COMPILE_CONTEXT.securityContext.datasetId}.xa_campaign_summary_daily`,
  
  joins: {

    cube_campaigns: {
      sql: `${CUBE.campaign_fk} = ${cube_campaigns.campaign_pk}`,
      relationship: `many_to_one`,
    },
    
  },
  
  dimensions: {

  },
 
  measures: {

    count_campaign_summary_daily: {
      type: `count`,
    },

    number_click_through_rate: {
      description: `CTR. Clicks divided by impressions.`,
      type: `number`,
      sql: `safe_divide(
        ${CUBE.sum_campaign_summary_daily_clicks},
        ${CUBE.sum_campaign_summary_daily_impressions}
        )`,
    },

    number_cost_per_click: {
      description: `CPC. Cost incurred divided by clicks.`,
      type: `number`,
      sql: `safe_divide(
        ${CUBE.sum_campaign_summary_daily_cost_incurred},
        ${CUBE.sum_campaign_summary_daily_clicks}
        )`,
    },

    number_cost_per_mille: {
      description: `CPM. Cost incurred divided by thousands of impressions.`,
      type: `number`,
      sql: `safe_divide(
        ${CUBE.sum_campaign_summary_daily_cost_incurred},
        ${CUBE.sum_campaign_summary_daily_impressions} / 1000
        )`,
    },

    number_cost_per_order: {
      description: `CPO as reported by the platform. Generally not accurate. Cost incurred divided by conversions.`,
      type: `number`,
      sql: `safe_divide(
        ${CUBE.sum_campaign_summary_daily_cost_incurred},
        ${CUBE.sum_campaign_summary_daily_conversions}
        )`,
    },

    number_conversion_value_over_cost: {
      description: `ROAS as reported by the platform. Generally not accurate. Conversion value divided by cost incurred.`,
      type: `number`,
      sql: `safe_divide(
        ${CUBE.sum_campaign_summary_daily_conversions_value},
        ${CUBE.sum_campaign_summary_daily_cost_incurred}
        )`,
    },

  },


});


// the cube below is auto generated with Cube Code Generator spreadsheet https://drive.google.com/drive/folders/18eblS2J3nWqhHoL1fiBte154bDTg2rMG
// the cube above is manually maintained and extends the cube below
// ideally, the base and extending cubes would be in separate files (improvement opportunity)
// the top one would be named xa_campaign_summary_daily.js and the bottom one xa_campaign_summary_daily_base.js
const auto_generated_base_cube_campaign_summary_daily = cube(`auto_generated_base_cube_campaign_summary_daily`, {
  
  sql: `placeholder`,
  
  dimensions: {
    
    campaign_summary_daily_pk: {
      shown: false,
      primary_key: true,
      sql: `campaign_summary_daily_pk`,
      type: `string`,
    },

    campaign_fk: {
      shown: false,
      sql: `campaign_fk`,
      type: `string`,
    },

    campaign_summary_daily_connector_source: {
      sql: `campaign_summary_daily_connector_source`,
      type: `string`,
    },

    campaign_summary_daily_clicks: {
      sql: `campaign_summary_daily_clicks`,
      type: `number`,
    },

    campaign_summary_daily_conversions: {
      sql: `campaign_summary_daily_conversions`,
      type: `number`,
    },

    campaign_summary_daily_conversions_value: {
      sql: `campaign_summary_daily_conversions_value`,
      type: `number`,
    },

    campaign_summary_daily_cost_incurred: {
      sql: `campaign_summary_daily_cost_incurred`,
      type: `number`,
    },

    campaign_summary_daily_cost_allocatable: {
      sql: `campaign_summary_daily_cost_allocatable`,
      type: `number`,
    },

    campaign_summary_daily_impressions: {
      sql: `campaign_summary_daily_impressions`,
      type: `number`,
    },

    campaign_summary_daily_date: {
      sql: `cast( campaign_summary_daily_date as timestamp )`,
      type: `time`,
    },

  },
  
  measures: {
    
    count_distinct_campaign_summary_daily_connector_source: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_summary_daily_connector_source}`,
    },

    count_distinct_approx_campaign_summary_daily_connector_source: {
      type: `count_distinct_approx`,
      sql: `${CUBE.campaign_summary_daily_connector_source}`,
    },

    sum_campaign_summary_daily_clicks: {
      type: `sum`,
      sql: `${CUBE.campaign_summary_daily_clicks}`,
    },

    avg_campaign_summary_daily_clicks: {
      type: `avg`,
      sql: `${CUBE.campaign_summary_daily_clicks}`,
    },

    min_campaign_summary_daily_clicks: {
      type: `min`,
      sql: `${CUBE.campaign_summary_daily_clicks}`,
    },

    max_campaign_summary_daily_clicks: {
      type: `max`,
      sql: `${CUBE.campaign_summary_daily_clicks}`,
    },

    count_distinct_campaign_summary_daily_clicks: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_summary_daily_clicks}`,
    },

    count_distinct_approx_campaign_summary_daily_clicks: {
      type: `count_distinct_approx`,
      sql: `${CUBE.campaign_summary_daily_clicks}`,
    },

    sum_campaign_summary_daily_conversions: {
      type: `sum`,
      sql: `${CUBE.campaign_summary_daily_conversions}`,
    },

    avg_campaign_summary_daily_conversions: {
      type: `avg`,
      sql: `${CUBE.campaign_summary_daily_conversions}`,
    },

    min_campaign_summary_daily_conversions: {
      type: `min`,
      sql: `${CUBE.campaign_summary_daily_conversions}`,
    },

    max_campaign_summary_daily_conversions: {
      type: `max`,
      sql: `${CUBE.campaign_summary_daily_conversions}`,
    },

    count_distinct_campaign_summary_daily_conversions: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_summary_daily_conversions}`,
    },

    count_distinct_approx_campaign_summary_daily_conversions: {
      type: `count_distinct_approx`,
      sql: `${CUBE.campaign_summary_daily_conversions}`,
    },

    sum_campaign_summary_daily_conversions_value: {
      type: `sum`,
      sql: `${CUBE.campaign_summary_daily_conversions_value}`,
    },

    avg_campaign_summary_daily_conversions_value: {
      type: `avg`,
      sql: `${CUBE.campaign_summary_daily_conversions_value}`,
    },

    min_campaign_summary_daily_conversions_value: {
      type: `min`,
      sql: `${CUBE.campaign_summary_daily_conversions_value}`,
    },

    max_campaign_summary_daily_conversions_value: {
      type: `max`,
      sql: `${CUBE.campaign_summary_daily_conversions_value}`,
    },

    count_distinct_campaign_summary_daily_conversions_value: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_summary_daily_conversions_value}`,
    },

    count_distinct_approx_campaign_summary_daily_conversions_value: {
      type: `count_distinct_approx`,
      sql: `${CUBE.campaign_summary_daily_conversions_value}`,
    },

    sum_campaign_summary_daily_cost_incurred: {
      type: `sum`,
      sql: `${CUBE.campaign_summary_daily_cost_incurred}`,
    },

    avg_campaign_summary_daily_cost_incurred: {
      type: `avg`,
      sql: `${CUBE.campaign_summary_daily_cost_incurred}`,
    },

    min_campaign_summary_daily_cost_incurred: {
      type: `min`,
      sql: `${CUBE.campaign_summary_daily_cost_incurred}`,
    },

    max_campaign_summary_daily_cost_incurred: {
      type: `max`,
      sql: `${CUBE.campaign_summary_daily_cost_incurred}`,
    },

    count_distinct_campaign_summary_daily_cost_incurred: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_summary_daily_cost_incurred}`,
    },

    count_distinct_approx_campaign_summary_daily_cost_incurred: {
      type: `count_distinct_approx`,
      sql: `${CUBE.campaign_summary_daily_cost_incurred}`,
    },

    sum_campaign_summary_daily_cost_allocatable: {
      type: `sum`,
      sql: `${CUBE.campaign_summary_daily_cost_allocatable}`,
    },

    avg_campaign_summary_daily_cost_allocatable: {
      type: `avg`,
      sql: `${CUBE.campaign_summary_daily_cost_allocatable}`,
    },

    min_campaign_summary_daily_cost_allocatable: {
      type: `min`,
      sql: `${CUBE.campaign_summary_daily_cost_allocatable}`,
    },

    max_campaign_summary_daily_cost_allocatable: {
      type: `max`,
      sql: `${CUBE.campaign_summary_daily_cost_allocatable}`,
    },

    count_distinct_campaign_summary_daily_cost_allocatable: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_summary_daily_cost_allocatable}`,
    },

    count_distinct_approx_campaign_summary_daily_cost_allocatable: {
      type: `count_distinct_approx`,
      sql: `${CUBE.campaign_summary_daily_cost_allocatable}`,
    },

    sum_campaign_summary_daily_impressions: {
      type: `sum`,
      sql: `${CUBE.campaign_summary_daily_impressions}`,
    },

    avg_campaign_summary_daily_impressions: {
      type: `avg`,
      sql: `${CUBE.campaign_summary_daily_impressions}`,
    },

    min_campaign_summary_daily_impressions: {
      type: `min`,
      sql: `${CUBE.campaign_summary_daily_impressions}`,
    },

    max_campaign_summary_daily_impressions: {
      type: `max`,
      sql: `${CUBE.campaign_summary_daily_impressions}`,
    },

    count_distinct_campaign_summary_daily_impressions: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_summary_daily_impressions}`,
    },

    count_distinct_approx_campaign_summary_daily_impressions: {
      type: `count_distinct_approx`,
      sql: `${CUBE.campaign_summary_daily_impressions}`,
    },

    min_campaign_summary_daily_date: {
      type: `min`,
      sql: `${CUBE.campaign_summary_daily_date}`,
    },

    max_campaign_summary_daily_date: {
      type: `max`,
      sql: `${CUBE.campaign_summary_daily_date}`,
    },

    count_distinct_campaign_summary_daily_date: {
      type: `count_distinct`,
      sql: `${CUBE.campaign_summary_daily_date}`,
    },

    count_distinct_approx_campaign_summary_daily_date: {
      type: `count_distinct_approx`,
      sql: `${CUBE.campaign_summary_daily_date}`,
    },

  },

});