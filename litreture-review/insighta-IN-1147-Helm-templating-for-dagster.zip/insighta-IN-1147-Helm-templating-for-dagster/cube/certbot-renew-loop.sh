#!/bin/bash

VM_NAME="cube-core-prod"
ZONE="us-central1-c"
TAG="allow-http-cube"
NGINX_CONTAINER="runner-nginx-1"

while true; do
  echo "[$(date)] Starting certbot renewal process"

  gcloud compute instances add-tags "$VM_NAME" --zone="$ZONE" --tags="$TAG"

  sudo docker stop "$NGINX_CONTAINER"

  echo "Running certbot renew"
  sudo docker run --rm -p 80:80 \
    -v /home/runner/data/certbot/conf:/etc/letsencrypt \
    -v /home/runner/data/certbot/lib:/var/lib/letsencrypt \
    certbot/certbot renew

  sudo docker start "$NGINX_CONTAINER"

  gcloud compute instances remove-tags "$VM_NAME" --zone="$ZONE" --tags="$TAG"

  echo "[$(date)] Sleeping for 24 hours"
  sleep 86400
done
