import os
import jwt
from dotenv import load_dotenv
from typing import cast

# Load environment variables from .env file
load_dotenv(override=True,)


BIGQUERY_DATASET = os.getenv('BIGQUERY_DATASET')
BIGQUERY_PROJECT_ID = os.getenv('BIGQUERY_PROJECT_ID')
CUBEJS_API_SECRET = os.getenv('CUBEJS_API_SECRET')

if not all([BIGQUERY_DATASET, BIGQUERY_PROJECT_ID, CUBEJS_API_SECRET]):
    raise ValueError("One or more required environment variables are missing. Make sure all these are set: BIGQUERY_DATASET, BIGQUERY_PROJECT_ID, CUBEJS_API_SECRET")

payload_data = {
    "projectId": f"{BIGQUERY_PROJECT_ID}",
    "datasetId": BIGQUERY_DATASET
}

token = jwt.encode(payload_data, cast(str, CUBEJS_API_SECRET), algorithm="HS256")

print(token)
