`skills/` contains skills installed from https://skills.sh/

This differs from `../.github/skills/` which are manually created skills specific to this project.

# How to update
```sh
npx skills check
npx skills update
```