---
name: ssl-nginx-certbot
description: >
  Debug and fix SSL/TLS certificate issues for services using the nginx +
  certbot + Docker Compose pattern (n8n, lightdash, cube). Use when
  encountering self-signed certificate errors, Let's Encrypt issuance
  failures, or renewal problems.
---

# SSL / Nginx / Certbot Debugging

## Services using this pattern

| Service   | VM              | Zone          | Domain                  |
|-----------|-----------------|---------------|-------------------------|
| n8n       | n8n-prod        | us-central1-a | n8n.insighta.io         |
| lightdash | (see terraform) | us-central1-a | lightdash.insighta.io   |
| cube      | (see terraform) | us-central1-c | cube.insighta.io        |

Each service runs: `nginx` → `certbot` (Docker Compose) with cert data at
`/home/runner/data/certbot/`.

---

## Symptom: `SSL certificate problem: self signed certificate`

This means nginx is serving the **dummy fallback cert** (`CN=localhost`,
1-day validity) instead of the real Let's Encrypt cert.

### Root cause

`init-letsencrypt.sh` creates a self-signed dummy cert so nginx can start,
then deletes it and requests a real Let's Encrypt cert. If certbot fails
(e.g. DNS not yet propagated on a new VM), it **restores the dummy cert**
so nginx stays online. The dummy cert's `live/` directory then **blocks
subsequent `certbot certonly` runs** with "live directory exists".

---

## Diagnostic commands

SSH into the VM first:
```bash
gcloud compute ssh <vm-name> --zone=<zone> --project=insighta-021324
```

```bash
# 1. Check what cert is actually on disk
sudo openssl x509 -in /home/runner/data/certbot/conf/live/<domain>/fullchain.pem \
  -noout -subject -dates -issuer

# 2. Check what cert nginx is serving over TLS
echo | openssl s_client -connect localhost:443 -servername <domain> 2>/dev/null \
  | openssl x509 -noout -subject -dates -issuer

# 3. Check certbot state
sudo ls -la /home/runner/data/certbot/conf/live/
sudo ls -la /home/runner/data/certbot/conf/renewal/

# 4. Check containers are running
cd /home/runner && sudo docker compose ps

# 5. Test ACME challenge path works internally
curl -s -o /dev/null -w '%{http_code}' \
  http://localhost/.well-known/acme-challenge/testfile  # should be 200 or 404

# 6. Test ACME challenge path from external (DNS + firewall check)
curl -s -o /dev/null -w '%{http_code}' \
  http://<domain>/.well-known/acme-challenge/testfile   # should be 200 or 404

# 7. Dry-run certbot to verify issuance would succeed
cd /home/runner && sudo docker compose run --rm --entrypoint \
  'certbot certonly --webroot -w /var/www/certbot \
    --email engineering@insighta.io -d <domain> \
    --rsa-key-size 4096 --agree-tos --non-interactive --dry-run' certbot

# 8. Check nginx error logs
cd /home/runner && sudo docker compose logs nginx 2>&1 | grep -i 'error\|warn\|emerg'

# 9. Check if renewal loop is running
ps aux | grep certbot-renew
```

---

## Fix: manually recover from dummy cert state

Run these on the VM when there's a dummy cert blocking a real issuance:

```bash
cd /home/runner

# 1. Clean dummy cert state
domain="<domain>"  # e.g. n8n.insighta.io
sudo rm -rf data/certbot/conf/live/$domain
sudo rm -rf data/certbot/conf/archive/$domain
sudo rm -f  data/certbot/conf/renewal/$domain.conf

# 2. Request real cert
sudo docker compose run --rm --entrypoint \
  "certbot certonly --webroot -w /var/www/certbot \
    --email engineering@insighta.io -d $domain \
    --rsa-key-size 4096 --agree-tos --non-interactive --force-renewal" certbot

# 3. Reload nginx
sudo docker compose exec nginx nginx -s reload

# 4. Verify
echo | openssl s_client -connect localhost:443 -servername $domain 2>/dev/null \
  | openssl x509 -noout -subject -issuer -dates
```

---

## Automated recovery (built into scripts)

`certbot-renew-loop.sh` (runs as a background process on the VM) now
detects the dummy cert automatically:
- If `issuer=CN=localhost`: runs `certbot certonly` with cleanup, then reloads nginx
- If real cert: runs `certbot renew` as usual when ≤30 days remain

`init-letsencrypt.sh` now retries once after 90 seconds before falling
back to the dummy cert, handling DNS propagation delays on fresh VMs.

---

## Common failure modes

| Symptom | Likely cause | Fix |
|---------|-------------|-----|
| Dummy cert after fresh VM provision | DNS not propagated when script ran | Wait ~5 min, run manual fix above or let renewal loop auto-recover |
| `live directory exists` error from certbot | Previous dummy cert state not cleaned up | Run cleanup + certonly steps above |
| ACME challenge returns non-200 externally | GCP firewall rule missing port 80, or nginx not running | Check `sudo docker compose ps`, check GCP firewall rules for port 80 |
| `certbot renew` does nothing | No renewal config exists (dummy cert was never issued by LE) | Use `certbot certonly` instead, not `renew` |
| Nginx `proxy_temp` buffer warnings | Normal — large static assets; not an SSL issue | Increase `proxy_buffers` in nginx config if desired |

---

## Key file locations on VMs

```
/home/runner/
  .env                         # N8N_DOMAIN, POSTGRES_* etc.
  docker-compose.yml           # service definitions
  init-letsencrypt.sh          # one-time cert issuance on provision
  certbot-renew-loop.sh        # background renewal daemon
  data/certbot/
    conf/
      live/<domain>/           # active cert symlinks
      archive/<domain>/        # actual cert files
      renewal/<domain>.conf    # renewal config (only exists for LE certs)
      options-ssl-nginx.conf   # TLS hardening config
    www/.well-known/           # ACME challenge webroot
```
