# Local dagster development

## Prerequisites
1. Python 3.11+
1. uv installed

## First-time setup
1. Install and initialize the **google cloud cli** by following the instructions in the [Google Cloud CLI documentation](https://cloud.google.com/sdk/docs/install).
2. Generate Application Default Credentials (ADC). This allows applications and libraries running on your machine to access Google Cloud resources using your user identity. These generated creds are stored in a file (usually `~/.config/gcloud/application_default_credentials.json`).

```bash
gcloud auth application-default login
```

3. Set application default quota project
```bash
gcloud auth application-default set-quota-project insighta-021324
```

4. Authenticate to modal with
```bash
uvx modal token new
```

## Starting a local dagster instance
1. Ensure you have the environment variables configured as per [Environment variables](#environment-variables).
1. Start a local dagster instance with `make dagster`. It should after some time be available at `http://localhost:3000`.

## Environment variables

### Required
During development.
```bash
# for both dagster projects
export BIGQUERY_DATASET=dev_your_name_here

# for the reporting project
export GCP_PROJECT_REPORTING=insighta-reporting-staging
export GCP_PROJECT_REPLICATION=insighta-replication-staging
```

When creating data to be reviewed you may want to change the **dataset** to something specific for that purpose.
```bash
export BIGQUERY_DATASET=qa_in_123
```

### Optional
⚠️ **Warning**: These are only intended for local development. Do not use them in production or staging deployments.

#### Limit definitions loading
If you only want to load the dagster definitions for a subset of the clients, set this environment variable. It will make sure your dagster instance loads faster because it won't load definitions for clients you don't need.

> Note: it doesn't support trailing commas.

```bash
export LIST_ORGANIZATION_NAMES_TO_LOAD_DAGSTER_DEFINITIONS_FOR='["obagi","demoorganization"]'
```

#### Skip cache
If this is set, the custom caching in our dagster instance will be skipped. It is rarely used anymore.

```bash
# SKIP_CACHE=true
```

# Testing

## Unit Tests
To run the unit tests, use the following command:
```bash
uv run pytest -s insighta_platform_tests
```

To run a specific test file, use:
```bash
uv run pytest -s insighta_platform_tests/test_file.py::test_name
```

e.g.
```bash
uv run pytest -s insighta_platform_tests/test_conforming.py::test_conforming_sql_does_not_reference_other_org_projects
```

# Deployments

## additional env vars for dagster deployments

### gcp
When developing locally you authorize through oauth. This is not the case in deployments. There, a service account is used. CI/CD pipelines need to create the `GOOGLE_APPLICATION_CREDENTIALS_BASE64` environment variable with the service account's creds.

> Note: when dagster is launched it will
> 1. create `/tmp/gcp_creds.json` from the value of env var `GOOGLE_APPLICATION_CREDENTIALS_BASE64` value
> 2. set env var `GOOGLE_APPLICATION_CREDENTIALS`, which is what enables oauth

```bash
GOOGLE_APPLICATION_CREDENTIALS_BASE64={long list of characters, see below}
```

<details><summary>Click here to see how to create the GOOGLE_APPLICATION_CREDENTIALS_BASE64 value</summary>
Running this command will print the base64 encoded value of your GCP service account JSON key which can then be copied from the terminal.

```bash
cat {/path/to/your/gcp_service_account.json} | base64
```

</details>

### slack
This is the slack bot token for the app [dagster monitoring](https://api.slack.com/apps/A08RQCDBSR4/oauth). This app is used by our custom sensors that send messages to slack when e.g. a run fails.

```bash
SLACK_BOT_TOKEN={xoxb-1234567890-1234567890123-1234567890123-abc}
```

How the app was set up:
  1. it was added to our slack workspace.
  2. it was given the permission to send messages.
  3. it was added to the channel #monitoring using `/invite @dagster monitoring`

# dbt in dagster

## `dbt-run-cache` (fivetran package)
❗️dbt materializations defer to `prod` by default. If you materialize dbt through dagster you need to be aware of this. You can control this behavior with the dagster assets' dagster `config`.

```sql
create or replace view `organization_name-istag`.
...
as select * from `organization_name-iprod`.
```

For more info, see [dbt-run-cache in ../README.md](../README.md#dbt-run-cache).