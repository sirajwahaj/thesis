with

source_ads_sponsored_brand as (

  select * from allfreshseafood-iprod.amazon_ads.sb_ad_history

),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( id as string )  as ad_natural_key,

    -- strings
    'amazon' as ad_connector_source,
    cast( 'cpc' as string ) as ad_medium_name,
    cast( name as string ) as ad_name,
    cast( null as string ) as ad_text,
    cast( null as string ) as ad_url,

    -- dates
    cast( last_update_date as timestamp ) as ad_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as ad_timestamp_replicated,

  from source_ads_sponsored_brand

)

select * from rename_cast_and_order_columns