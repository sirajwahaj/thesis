--make null until they start spending again in microsoft ads
-- schema-only, 1 row where every field is NULL
select
  -- natural keys
  cast(null as string) as ad_summary_daily_natural_key,
  cast(null as string) as ad_summary_daily_ad_natural_key,

  -- strings
  cast(null as string) as ad_summary_daily_connector_source,

  -- numbers
  cast(null as numeric) as ad_summary_daily_clicks,
  cast(null as numeric) as ad_summary_daily_conversions,
  cast(null as numeric) as ad_summary_daily_conversions_value,
  cast(null as numeric) as ad_summary_daily_cost,
  cast(null as numeric) as ad_summary_daily_impressions,

  -- dates
  cast(null as date) as ad_summary_daily_date,
  cast(null as timestamp) as ad_summary_daily_timestamp_replicated



/*
with

source_ad_summary_daily as (

  select * from allfreshseafood-iprod.microsoft_ads.ad_performance_daily_report

),

create_compound_key as (

  select *,

    account_id
      || '-' || ad_id
      || '-' || date
      || '-' || currency_code
      || '-' || ad_distribution
      || '-' || device_type
      || '-' || network
      || '-' || delivered_match_type
      || '-' || device_os
      || '-' || top_vs_other
      || '-' || bid_match_type
      as compound_key

  from source_ad_summary_daily

),

add_optional_cost_allocation as (

  select *,

    array_agg(
      struct(
        cast(null as string) as non_event_tracker_event_natural_key,
        cast(null as numeric) as ratio_cost
      )
    ) as ad_summary_daily_allocation_cost

  from create_compound_key
  group by all

),

rename_and_order_columns as (

  select

    -- natural keys
    cast( compound_key as string ) as ad_summary_daily_natural_key,
    cast( ad_id as string ) as ad_summary_daily_ad_natural_key,

    -- strings
    cast( 'bing' as string ) as ad_summary_daily_connector_source,

    -- numbers
    cast( clicks as numeric ) as ad_summary_daily_clicks,
    cast( conversions as numeric ) as ad_summary_daily_conversions,
    cast( revenue as numeric ) as ad_summary_daily_conversions_value,
    cast( spend as numeric ) as ad_summary_daily_cost,
    cast( impressions as numeric ) as ad_summary_daily_impressions,

    -- json
    ad_summary_daily_allocation_cost,

    -- dates
    cast( date as date ) as ad_summary_daily_date,
    cast( _fivetran_synced as timestamp ) as ad_summary_daily_timestamp_replicated,
  
  from add_optional_cost_allocation

)

select * from rename_and_order_columns
*/


