with

source_campaigns_sponsored_paid as (

  select * from allfreshseafood-iprod.amazon_ads.campaign_history

),

source_campaigns_sponsored_brand as (

  select * from allfreshseafood-iprod.amazon_ads.sb_campaign_history

),

source_campaigns_sponsored_display as (

  select * from allfreshseafood-iprod.amazon_ads.sd_campaign_history

),

rename_cast_and_order_columns_sponsored_paid as (

  select

    -- natural keys
    cast( id as string )  as campaign_natural_key,

    -- strings
    'sponsored paid' as campaign_ad_type,
    cast( name as string ) as campaign_name,

    -- dates
    cast( last_updated_date as timestamp ) as campaign_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as campaign_timestamp_replicated,

  from source_campaigns_sponsored_paid

),

rename_cast_and_order_columns_sponsored_brand as (

  select

    -- natural keys
    cast( id as string )  as campaign_natural_key,

    -- strings
    'sponsored brand' as campaign_ad_type,
    cast( name as string ) as campaign_name,

    -- dates
    cast( last_update_date as timestamp ) as campaign_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as campaign_timestamp_replicated,

  from source_campaigns_sponsored_brand

),

rename_cast_and_order_columns_sponsored_display as (

  select

    -- natural keys
    cast( id as string )  as campaign_natural_key,

    -- strings
    'sponsored display' as campaign_ad_type,
    cast( name as string ) as campaign_name,

    -- dates
    cast( last_updated_date as timestamp ) as campaign_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as campaign_timestamp_replicated,

  from source_campaigns_sponsored_display

),

union_together_the_different_ad_type_sources as (

  select * from rename_cast_and_order_columns_sponsored_paid

  union all
  
  select * from rename_cast_and_order_columns_sponsored_brand
  
  union all
  
  select * from rename_cast_and_order_columns_sponsored_display

),

add_connector_source as (

  select *,

    'amazon' as campaign_connector_source

  from union_together_the_different_ad_type_sources

),

select_and_order_columns as (

  select

    -- natural keys
    campaign_natural_key,

    -- strings
    campaign_connector_source,
    cast( 'cpc' as string ) as campaign_medium_name,
    campaign_name,

    -- dates
    campaign_timestamp_updated,
    campaign_timestamp_replicated

  from add_connector_source

)

select * from select_and_order_columns