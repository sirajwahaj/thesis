with

source_orders as (

  select * from allfreshseafood-iprod.shopify.order

),

select_and_convert_json_to_stirng as (

  select 
    id, 
    cart_token,
    email, 
    total_price, 
    created_at, 
    _fivetran_synced, 
    note_attributes,
    case 
      when(
        lower( source_orders.billing_address_country_code )  = 'us'
      )
      then  regexp_extract( source_orders.billing_address_zip, r'^\d{5}' )
      else source_orders.billing_address_zip
      end as postal_code,
      browser_ip,
      billing_address_country_code
  from source_orders
    
),

extract_nested_note_attributes as (

    select
      id, 
      cart_token,
      email, 
      total_price, 
      created_at, 
      _fivetran_synced, 
      postal_code,
      browser_ip,
      billing_address_country_code,
        
      max(case when json_extract_scalar( unnested_note_attributes , '$.name') = 'network_userid' then json_extract_scalar( unnested_note_attributes , '$.value') end) as network_userid,
      max(case when json_extract_scalar( unnested_note_attributes , '$.name') = 'domain_userid' then json_extract_scalar( unnested_note_attributes , '$.value') end) as domain_userid,
    from select_and_convert_json_to_stirng

        left join

          unnest(json_extract_array(  select_and_convert_json_to_stirng.note_attributes  )) as  unnested_note_attributes
    
    group by all

),

rename_cast_and_order_columns as (

  select

    -- natural keys - regular
    cast( id as string ) as order_natural_key,

    -- natural keys - identity resolution
    cast( null as string ) as order_user_identifier_application,
    cast( cart_token as string ) as order_user_identifier_cart_token,
    cast( null as string ) as order_user_identifier_fingerprint,
    cast( network_userid as string ) as order_user_identifier_server_side_cookie,
    cast( domain_userid as string ) as order_user_identifier_client_side_cookie,

    -- strings
    'shopify' as order_connector_source,
    lower( cast( billing_address_country_code as string ) ) as order_country_code,
    cast( email as string ) as order_email_address,
    cast( browser_ip as string ) as order_ip_address,
    cast( postal_code as string ) order_postal_code,

    -- numbers
    cast( total_price as numeric ) as order_amount_total,

    -- timestamps
    cast( created_at as timestamp ) as order_timestamp,
    cast( _fivetran_synced as timestamp ) as order_timestamp_replicated,
  
  from extract_nested_note_attributes

)

select * from rename_cast_and_order_columns
