with source_order_line as (

  select * from `chefworks-429121.analytics_ftp.chefworks_ftp_destination_tables__merchandise_sales_order_item_1__23__file_replication`

),

source_distinct_orders as (

  select 
    distinct 
    increment_id,
    internal_order_id, 
  from chefworks-429121.analytics_ftp.chefworks_ftp_destination_tables__orders_1__15__file_replication

),

filter_source as (

  select
    source_order_line.*,
    source_distinct_orders.increment_id,
  from source_order_line
  inner join source_distinct_orders
    on source_order_line.order_id = source_distinct_orders.internal_order_id
  where true
    and ifnull(cast( base_row_total as numeric ),0) > 0
    and ifnull(cast( qty_ordered as numeric ),0) > 0

),

cast_and_rename as (
  
  select

    -- natural keys
    cast( item_id as string ) as order_line_item_natural_key,
    cast( increment_id as string ) as order_natural_key,
    cast( product_id as string ) as sku_natural_key,

    -- numbers
    cast( qty_ordered as numeric ) as order_line_quantity,
    cast( base_row_total as numeric ) as order_line_amount_total,

    -- timestamps
    cast( _INSIGHTA_REPLICATION_TIMESTAMP as timestamp ) as order_line_timestamp_replicated,

  from filter_source

)

select * from cast_and_rename