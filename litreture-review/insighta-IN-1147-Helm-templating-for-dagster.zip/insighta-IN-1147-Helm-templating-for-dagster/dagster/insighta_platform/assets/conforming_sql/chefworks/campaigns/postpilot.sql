with source_catalog_mailers as (

  select * 
  from `chefworks-429121.email.post_pilot_catalog_mailer`

),

cast_and_rename as (

  select 
    -- natural keys
    cast(campaign_id as string) as campaign_natural_key,

    -- strings
    cast('postpilot' as string) as campaign_connector_source,
    cast('direct mailer' as string) as campaign_medium_name,
    cast(campaign_name as string) as campaign_name,

    -- booleans
    cast(true as boolean) as is_directly_attributable,

    -- timestamps (apply override)
    max(
      case
        when cast(campaign_id as string) = "80718" then timestamp('2025-11-02')
        else safe.parse_timestamp('%B %d, %Y', postcard_date)
      end
    ) as campaign_timestamp_updated,

    max(
      case
        when cast(campaign_id as string) = "80718" then timestamp('2025-11-02')
        else safe.parse_timestamp('%B %d, %Y', postcard_date)
      end
    ) as campaign_timestamp_replicated

  from source_catalog_mailers
  group by
    campaign_id,
    campaign_name

)

select * from cast_and_rename