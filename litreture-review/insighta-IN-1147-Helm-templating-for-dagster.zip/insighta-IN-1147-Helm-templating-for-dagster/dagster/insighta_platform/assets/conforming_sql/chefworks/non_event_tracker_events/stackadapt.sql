--Conforming SQL for Stackadapt Non-Event Tracker Events
with

stackadapt_impression_source as (

  select * from chefworks-429121.stackadapt.stackadapt_chefworks_bigquery_conv

),

source_orders as (

  {{ ref('orders', 'stfp_order_transfer') }}

),

filter_to_conversion_orders as (

  select distinct * from stackadapt_impression_source
  where order_id is not null

),

create_non_event_tracker_event_natural_key as (

  select *,
    cast( REQ_UNIQ_ID as string)
      || '_' || cast(FIRST_IMP_TIME_FORMAT as string)
      || '_' || cast(LAST_IMP_TIME_FORMAT as string)
      || '_' || cast(CAMPAIGN_ID as string)
      || '_' || cast(NATIVEAD_ID as string)
      || '_' || cast(ORDER_ID as string)
      || '_' || cast(CONV_TIME_FORMAT as string)
      as non_event_tracker_event_natural_key
  from filter_to_conversion_orders

),

rename_cast_and_order_columns as (

  select 

    -- natural keys
    cast( create_non_event_tracker_event_natural_key.non_event_tracker_event_natural_key as string ) as non_event_tracker_event_natural_key,
    cast( cast(create_non_event_tracker_event_natural_key.campaign_id as numeric ) as string ) as non_event_tracker_event_campaign_natural_key,
    cast( order_country_code as string ) as non_event_tracker_event_country_code,

    --strings
    cast( 'stackadapt' as string ) as non_event_tracker_event_connector_source,
    cast( order_email_address as string ) as non_event_tracker_event_email_address,
    cast( 'display' as string ) as non_event_tracker_event_medium_name,
    case 
     when attr_type = 'imp' then 'display ad view' 
     when attr_type = 'click' then 'display ad click' 
     else 'undefined' 
    end as non_event_tracker_event_name,
    cast( order_ip_address as string ) as non_event_tracker_event_ip_address,
    cast( order_postal_code as string ) as non_event_tracker_event_postal_code,

    -- numbers
    cast( null as numeric ) as non_event_tracker_event_cost,

    --datetime
    cast( create_non_event_tracker_event_natural_key.first_imp_time_format as timestamp ) as non_event_tracker_event_timestamp,
    cast( create_non_event_tracker_event_natural_key.first_imp_time_format as timestamp ) as non_event_tracker_event_timestamp_replicated,

  from create_non_event_tracker_event_natural_key

    left join source_orders 
    
      on cast(create_non_event_tracker_event_natural_key.order_id as string) =  cast(source_orders.order_natural_key as string)

)

select * from rename_cast_and_order_columns
