with source_products as (

  select * from `chefworks-429121.analytics_ftp.chefworks_ftp_destination_tables__merchandise_products_1__22__file_replication`

),

cast_and_rename as (
  
  select

    distinct 
    -- natural keys
    cast( entity_id as string ) as sku_natural_key,

    -- timestamps
    cast( _INSIGHTA_REPLICATION_TIMESTAMP as timestamp ) as _timestamp_replicated,

  from source_products

)

select * from cast_and_rename