with 

source_catalog_mailers as (

   SELECT * FROM chefworks-429121.email.post_pilot_catalog_mailer

),

source_conversion_matchback as (

   SELECT * FROM chefworks-429121.email.post_pilot_matchback

),

  cleaned_catalog_mailers AS (

    select

      *,

      -- remove non-digits (commas etc.) and cast to NUMERIC
      cast(MAILED_QUANITTY as numeric) as mailed_qty_num,
      
      -- cast price to NUMERIC
      cast(price_per_mailed_piece as numeric) as total_catalog_cost_piece_num,

      -- override postcard date for campaign 80718
      case
        when cast(campaign_id as string) = "80718" then timestamp('2025-11-02')
        else safe.parse_timestamp('%B %d, %Y', postcard_date)
      end as postcard_date_format

    from source_catalog_mailers

  ),

cast_key_and_in_home_date as (

  select 
    -- natural keys
    cast( concat(campaign_id, postcard_date_format) as string ) as campaign_summary_daily_natural_key,
    cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,
    cast( postcard_date_format as date ) as campaign_summary_daily_date,
    cast( postcard_date_format as timestamp ) as campaign_summary_daily_timestamp_replicated,
    sum( mailed_qty_num ) as campaign_summary_daily_clicks,
    sum( mailed_qty_num ) as campaign_summary_daily_impressions,
    sum( mailed_qty_num * total_catalog_cost_piece_num ) as campaign_summary_daily_cost,
  from cleaned_catalog_mailers
  group by all

),

join_timestamp_on_conversion_matchback as (

  select 
    *,
    SAFE_CAST(REGEXP_REPLACE(total_price, r'[^\d.]', '') AS NUMERIC) as total_price_cleaned,
  from source_conversion_matchback
  left join cast_key_and_in_home_date
    on cast(source_conversion_matchback.campaign_id as string)= cast_key_and_in_home_date.campaign_summary_daily_campaign_natural_key

),

filter_out_null_in_home_date as (

  select
    *
  from join_timestamp_on_conversion_matchback
  where campaign_summary_daily_date is not null

),

create_distinct_event_key as (

  select 
    *,
    cast( concat(order_id, '-', cast(campaign_summary_daily_date as date)) as string ) as non_event_tracker_event_natural_key
  from filter_out_null_in_home_date
  

),

create_campaign_summary_daily_allocation_cost_json as (

  select 
    cast_key_and_in_home_date.campaign_summary_daily_natural_key,
    cast_key_and_in_home_date.campaign_summary_daily_campaign_natural_key,
    cast('postpilot' as string) as campaign_summary_daily_connector_source,
    cast_key_and_in_home_date.campaign_summary_daily_clicks,
    cast(count(distinct create_distinct_event_key.order_id) as numeric) as campaign_summary_daily_conversions,
    cast(sum(create_distinct_event_key.total_price_cleaned) as numeric) as campaign_summary_daily_conversions_value,
    cast_key_and_in_home_date.campaign_summary_daily_cost,
    cast_key_and_in_home_date.campaign_summary_daily_impressions,
    cast_key_and_in_home_date.campaign_summary_daily_date,
    cast_key_and_in_home_date.campaign_summary_daily_timestamp_replicated,
  from cast_key_and_in_home_date
  left outer join create_distinct_event_key
    using(campaign_summary_daily_natural_key)
  group by all

),

select_and_sort_columns as (

  select 

    -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,
    
    -- strings
    campaign_summary_daily_connector_source,

    -- numbers
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,

    -- timestamps 
    campaign_summary_daily_timestamp_replicated,

  from create_campaign_summary_daily_allocation_cost_json

)

select * from select_and_sort_columns