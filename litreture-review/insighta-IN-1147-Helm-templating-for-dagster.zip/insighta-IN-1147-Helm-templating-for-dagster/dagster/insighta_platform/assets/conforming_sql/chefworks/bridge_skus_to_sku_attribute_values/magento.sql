with source_products as (

  select * from `chefworks-429121.analytics_ftp.chefworks_ftp_destination_tables__merchandise_products_1__22__file_replication`

),

source_order_item as (

  select * from `chefworks-429121.analytics_ftp.chefworks_ftp_destination_tables__merchandise_sales_order_item_1__23__file_replication`

),

--sku
sku_filter_source as (

  select
    distinct
    cast(entity_id as string) as entity_id,
    cast(
      lower(
        regexp_replace(
          regexp_replace(
            trim(
              regexp_replace(SKU, r'[^a-zA-Z0-9\s\-]+', '')
            ),r'\s+',' '
          ),r' ','_'
        )
      ) as string
    ) SKU_key,
    cast(
      lower(
        regexp_replace(
          trim(
            regexp_replace(SKU, r'[^a-zA-Z0-9\s\-]+', '')
          ),
          r'\s+', ' '
        )
      ) as string 
    ) as SKU_clean
  from source_products
  where true
    and SKU is not null
    and SKU <> ""

),

--sku name
sku_name_filter_source as (

  select
    distinct
    cast(product_id as string) as entity_id,
    cast(
      lower(
        regexp_replace(
          regexp_replace(
            trim(
              regexp_replace(NAME, r'[^a-zA-Z0-9\s\-]+', '')
            ),r'\s+',' '
          ),r' ','_'
        )
      ) as string
    ) NAME_key,
    cast(
      initcap(
        regexp_replace(
          trim(
            regexp_replace(NAME, r'[^a-zA-Z0-9\s\-]+', '')
          ),
          r'\s+', ' '
        )
      ) as string 
    ) as NAME_clean
  from source_order_item
  where true
    and NAME is not null
    and NAME <> ""

),

--base sku
base_sku_filter_source as (

  select
    distinct
    cast(entity_id as string) as entity_id,
    cast(
      lower(
        regexp_replace(
          regexp_replace(
            trim(
              regexp_replace(counterpart_value, r'[^a-zA-Z0-9\s\-]+', '')
            ),r'\s+',' '
          ),r' ','_'
        )
      ) as string
    ) as base_sku_key,
    cast(
      lower(
        regexp_replace(
          trim(
            regexp_replace(counterpart_value, r'[^a-zA-Z0-9\s\-]+', '')
          ),
          r'\s+', ' '
        )
      ) as string 
    ) as base_sku_clean
  from source_products
  where true
    and counterpart_value is not null
    and counterpart_value <> ""

),

--base sku plus name
sku_name_by_entity_id as (

  select 
    distinct 
    cast(product_id as string) as entity_id,
    cast(NAME as string) as value 
  from source_order_item

),

base_sku_by_entity_id as (

  select 
    distinct 
    cast(entity_id as string) as entity_id,
    cast(counterpart_value as string) as value 
  from source_products

),

base_sku_plus_name_filter_source as (

  select 
    distinct
    coalesce(cast(base_sku.entity_id as string), cast(sku_name_list.entity_id as string)) entity_id,
    cast(
      lower(
        regexp_replace(
          regexp_replace(
            trim(
              regexp_replace(
                case 
                  when (base_sku.value is null or base_sku.value = "") then sku_name_list.value
                  when (sku_name_list.value is null or sku_name_list.value = "") then base_sku.value
                  else concat(base_sku.value,': ',sku_name_list.value) 
                end, r'[^a-zA-Z0-9\s\-]+', '')
            ),r'\s+',' '
          ),r' ','_'
        )
      ) as string
    ) as base_sku_plus_name_key,
    cast(
      lower(
        regexp_replace(
          trim(
            regexp_replace(
              case 
                when (base_sku.value is null or base_sku.value = "") then sku_name_list.value
                when (sku_name_list.value is null or sku_name_list.value = "") then base_sku.value
                else concat(base_sku.value,': ',sku_name_list.value) 
              end, r'[^a-zA-Z0-9\s\-]+', '')
          ),
          r'\s+', ' '
        )
      ) as string 
    ) as base_sku_plus_name_clean
  from base_sku_by_entity_id base_sku
  full outer join sku_name_by_entity_id sku_name_list
    on base_sku.entity_id = sku_name_list.entity_id

),

sku_cast_and_rename as (

  select 
    distinct
    cast( entity_id as string ) 
      || '_' || cast( 1 as string ) 
      || '_' || SKU_key 
      as bridge_natural_key,
    cast( entity_id as string ) as sku_natural_key,
    cast( 1 as string ) 
      || '_' || SKU_key
      as sku_attribute_value_natural_key,
  from sku_filter_source

),

sku_name_cast_and_rename as (

  select 
    distinct
    cast( entity_id as string ) 
      || '_' || cast( 2 as string ) 
      || '_' || name_key 
      as bridge_natural_key,
    cast( entity_id as string ) as sku_natural_key,
    cast( 2 as string ) 
      || '_' || name_key 
      as sku_attribute_value_natural_key,
  from sku_name_filter_source

),

base_sku_cast_and_rename as (

  select 
    distinct
    cast( entity_id as string ) 
      || '_' || cast( 3 as string ) 
      || '_' || base_sku_key 
      as bridge_natural_key,
    cast( entity_id as string ) as sku_natural_key,
    cast( 3 as string ) 
      || '_' || base_sku_key
      as sku_attribute_value_natural_key,
  from base_sku_filter_source

),


base_sku_plus_name_cast_and_rename as (

  select 
    distinct
    cast( entity_id as string ) 
      || '_' || cast( 3 as string ) 
      || '_' || base_sku_plus_name_key 
      as bridge_natural_key,
    cast( entity_id as string ) as sku_natural_key,
    cast( 4 as string ) 
      || '_' || base_sku_plus_name_key
      as sku_attribute_value_natural_key,
  from base_sku_plus_name_filter_source

),

union_cast_and_rename as (

  select * from sku_cast_and_rename

  union all

  select * from sku_name_cast_and_rename

  union all

  select * from base_sku_cast_and_rename

  union all

  select * from base_sku_plus_name_cast_and_rename

)

select * from union_cast_and_rename