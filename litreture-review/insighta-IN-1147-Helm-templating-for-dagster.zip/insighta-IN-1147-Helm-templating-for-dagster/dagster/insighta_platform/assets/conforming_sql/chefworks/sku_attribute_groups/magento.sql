select 
  cast( 1 as string ) as sku_attribute_group_natural_key,
  cast( 'Sku' as string ) as sku_attribute_group_name, 

union all

select 
  cast( 2 as string ) as sku_attribute_group_natural_key,
  cast( 'Sku Name' as string ) as sku_attribute_group_name, 

union all

select 
  cast( 3 as string ) as sku_attribute_group_natural_key,
  cast( 'Base Sku' as string ) as sku_attribute_group_name, 

union all

select 
  cast( 4 as string ) as sku_attribute_group_natural_key,
  cast( 'Base Sku Plus Name' as string ) as sku_attribute_group_name, 