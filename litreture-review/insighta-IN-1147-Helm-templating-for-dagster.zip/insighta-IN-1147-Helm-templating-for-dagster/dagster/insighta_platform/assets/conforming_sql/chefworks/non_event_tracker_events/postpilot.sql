--Conforming SQL for PostPilot Non-Event Tracker Events
with 

source_catalog_mailers as (

  SELECT * FROM chefworks-429121.email.post_pilot_catalog_mailer

),

source_conversion_matchback as (

  select * from chefworks-429121.email.post_pilot_matchback

),

source_orders as (

    {{ ref('orders', 'stfp_order_transfer') }}

),

deduplicate_orders as (

  select * from source_orders
    qualify row_number() over (
      partition by order_natural_key
      order by order_timestamp_replicated asc
         -- note: first order is filtered to because if page refreshes after order has completed,
         -- all the data will be the same except for the timestamp which would be misleading
         -- in subsequent duplicate records
      ) = 1

),

find_distinct_campaign_ids as (

  select 
    distinct cast(campaign_id as string) as campaign_id,
  from source_catalog_mailers

),

select_and_format_source_conversion_matchback as (

  select 
    cast(lower(email) as string) as email_clean, 
    cast(replace(postcard_id, ',', '') as string) as postcard_id_clean,
    case
      when cast(campaign_id as string) = "80718" then timestamp('2025-11-02')
      else parse_timestamp('%B %d, %Y', postcard_date)
    end as postcard_date_formatted,
    cast(campaign_id as string) as campaign_id_cleaned,
    cast(order_id as string) as order_id_clean,
    safe_cast(regexp_replace(total_price, r'[^\d.]', '') as numeric) as total_price_cleaned

  from source_conversion_matchback

),

join_timestamp_on_conversion_matchback as (

  select 
    select_and_format_source_conversion_matchback.*,
  from select_and_format_source_conversion_matchback
  inner join find_distinct_campaign_ids
    on select_and_format_source_conversion_matchback.campaign_id_cleaned = find_distinct_campaign_ids.campaign_id

),

filter_out_null_in_home_date as (

  select
    *
  from join_timestamp_on_conversion_matchback
  where lower(split(email_clean, '@')[safe_offset(1)]) not in (
    'chefworks.com',
    'ebay.com',
    'walmart.com'
  )

),

create_distinct_event_key as (

  select 
    *,
    cast( concat(REGEXP_REPLACE(order_id_clean, r'#', ''), '-', cast(postcard_date_formatted as date)) as string ) as concat_order_id_and_in_home_date
  from filter_out_null_in_home_date

),

join_conversion_email as (

  select
    create_distinct_event_key.*,
    ifnull(deduplicate_orders.order_email_address, create_distinct_event_key.email_clean) as order_email_address,
    deduplicate_orders.order_ip_address,
    deduplicate_orders.order_postal_code,
    deduplicate_orders.order_country_code,
  from create_distinct_event_key
  left outer join deduplicate_orders
    on create_distinct_event_key.order_id_clean = deduplicate_orders.order_natural_key_customer_facing

),

cast_and_rename as (

  select 
    -- distinct --need this to deduplicate which means I am fanning out somewhere
    cast(concat_order_id_and_in_home_date as string) as non_event_tracker_event_natural_key,
    cast(campaign_id_cleaned as string) as non_event_tracker_event_campaign_natural_key,
    cast(order_country_code as string) as non_event_tracker_event_country_code,
    cast('postpilot' as string) as non_event_tracker_event_connector_source,
    cast(lower(order_email_address) as string) as non_event_tracker_event_email_address,
    cast('direct mailer' as string) as non_event_tracker_event_medium_name,
    cast('direct mailer sent' as string) as non_event_tracker_event_name,
    cast( order_ip_address as string ) as non_event_tracker_event_ip_address,
    cast( order_postal_code as string ) as non_event_tracker_event_postal_code,
    cast( 1 as numeric ) as non_event_tracker_event_cost, -- set to 1 because before IN-844 it was calculated in the campaign_summary_daily model like this: cast( 1/(count(*) over (partition by campaign_summary_daily_natural_key)) as numeric) as ratio_cost
    timestamp(postcard_date_formatted) as non_event_tracker_event_timestamp,
    timestamp(postcard_date_formatted) as non_event_tracker_event_timestamp_replicated,

  from join_conversion_email

)

select * from cast_and_rename