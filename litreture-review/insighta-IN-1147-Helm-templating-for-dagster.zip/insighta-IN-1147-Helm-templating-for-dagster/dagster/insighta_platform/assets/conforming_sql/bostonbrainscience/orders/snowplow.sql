with 

source_web_events as (

  select * from {{ gcp_project_id }}.{{ bigquery_dataset }}_pre_conforming.pc_dispatch__snowcatcloud_events

),


filter_to_orders as (

  select * from source_web_events
  where event_name = 'transaction'

),


extract_location_from_nested_columns as (

  select filter_to_orders.*,
    lower( location.country.iso_code ) country_code,
    case 
      when(
        lower( location.country.iso_code ) = 'us'
      )
      then regexp_extract(location.postal.code, r'^\d{5}')
      else location.postal.code
      end as post_code_stg
  from filter_to_orders,
  UNNEST (contexts_com_dbip_location_1_0_0) AS location

),

standardize_location as (

  select *,
    last_value(post_code_stg ignore nulls) over (
      partition by event_id
      order by load_tstamp
      rows between unbounded preceding and unbounded following
    ) as postal_code
  from extract_location_from_nested_columns

),

extract_email_address_from_nested_ecommerce_user as (

  select distinct

    event_id,

    unnested_ecommerce_user.email as web_event_email_address_ecommerce_user,

  from standardize_location

    cross join unnest(
      standardize_location.contexts_com_snowplowanalytics_snowplow_ecommerce_user_1_0_0
      ) AS unnested_ecommerce_user

  where true

    -- filter out nulls to avoid fan-out
    and unnested_ecommerce_user.email is not null

),

join_unnested_to_non_nested as (

  select

    standardize_location.*,

    extract_email_address_from_nested_ecommerce_user.web_event_email_address_ecommerce_user,

  from standardize_location

    left join extract_email_address_from_nested_ecommerce_user

      using (event_id)


),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( tr_orderid as string ) as order_natural_key,

    -- keys - identity resolution
    cast( user_id as string ) as order_user_identifier_application,
    cast( null as string ) as order_user_identifier_cart_token,
    cast( null as string ) as order_user_identifier_fingerprint,
    cast( network_userid as string ) as order_user_identifier_server_side_cookie,
    cast( domain_userid as string ) as order_user_identifier_client_side_cookie,

    -- strings - other
    'snowplow' as order_connector_source,
    cast( country_code as string ) as order_country_code,
    cast( web_event_email_address_ecommerce_user as string ) as order_email_address,
    cast( user_ipaddress as string ) as order_ip_address,
    cast( postal_code as string ) as order_postal_code,


    -- numbers
    cast( tr_total as numeric ) as order_amount_total,

    -- timestamps
    cast( derived_tstamp as timestamp ) as order_timestamp,
    cast( load_tstamp as timestamp ) as order_timestamp_replicated,

  from join_unnested_to_non_nested

),

filter_out_nulls as (

  select * from rename_cast_and_order_columns
  where order_natural_key is not null

)

select * from filter_out_nulls where true
