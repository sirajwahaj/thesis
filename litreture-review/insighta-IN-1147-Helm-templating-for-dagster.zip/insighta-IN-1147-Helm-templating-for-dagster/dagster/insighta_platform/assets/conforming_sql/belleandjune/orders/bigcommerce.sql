with

bigcommerce_orders as (

  select * from `bellaandjune.bigcommerce.orders`

),

bigcommerce_emails as (

  select * from `bellaandjune.bigcommerce.customer`

),

snowplow_events as (
  
  select * from {{ gcp_project_id }}.{{ bigquery_dataset }}_pre_conforming.pc_dispatch__snowcatcloud_events

),

cast_and_rename_bigcommerce_orders as (

  select

    -- natural keys - regular
    cast( id as string ) as order_natural_key,
    cast( customer_id as string) as contact_pk,
    status_id as order_status_fk,

    -- strings
    'bigcommerce' as order_connector_source,
    lower( cast(country_iso_2 as string) ) as country_code,
    lower(cast(ip_address as string)) ip_address,
    lower(cast(case 
      when( lower( country_iso_2 ) = 'us' )
        then regexp_extract(zip, r'^\d{5}')
        else zip
      end as string) ) as postal_code,

    -- numbers
    cast( total_ex_tax as numeric ) as order_amount_total,

    -- timestamps bigcommerce accounts for timezone but not daylight savings 
    cast( format_timestamp('%Y-%m-%d %H:%M:%S', parse_timestamp('%a, %d %b %Y %H:%M:%S %z', date_created)) as timestamp ) utc_timestamp,

    cast( _fivetran_synced as timestamp ) as order_timestamp_replicated,


  from bigcommerce_orders

),

change_to_est_non_daylight_savings_time as (

  select 
    *,

    cast( utc_timestamp - interval 5 hour as timestamp) as order_timestamp

  from cast_and_rename_bigcommerce_orders

),

filter_to_only_relevant_orders as (

  /*
  Filter on the following codes
  Awaiting fulfillment = 11
  Awaiting shipment = 9
  Awaiting pickup = 8
  Completed = 10
  Shipped = 2
  Partially shipped = 3
  Partially refunded = 14
  */
  
  select 
    * 
  from change_to_est_non_daylight_savings_time
  where order_status_fk in (2, 3, 8, 9, 10, 11, 14)
),

cast_and_rename_bigcommerce_emails as (

  select

    -- natural keys - regular
    cast(id as string) as contact_pk,
    --strings
    cast(email as string) as order_email_address

  from bigcommerce_emails

),

cast_and_rename_snowplow_events as (

  select 
  
    cast(app_id as string) as organization_identifier,
    cast(derived_tstamp as timestamp) as event_timestamp,
    cast(tr_orderid as string) as event_join_order_natural_key,
    cast(null as string) as event_user_identifier_application,
    cast(null as string) as event_user_identifier_fingerprint,
    cast(network_userid as string) as event_user_identifier_server_side_cookie,
    cast(domain_userid as string) as event_user_identifier_client_side_cookie,
    
  from snowplow_events

),

deduplicate_to_snowplow_first_order_event as (

  select 
    *
  from cast_and_rename_snowplow_events
  qualify row_number() over(partition by event_join_order_natural_key order by event_timestamp asc) = 1 

),

join_emails_to_orders as (

  select 

    filter_to_only_relevant_orders.*,
    cast_and_rename_bigcommerce_emails.order_email_address
    
  from filter_to_only_relevant_orders
  left join cast_and_rename_bigcommerce_emails
    on filter_to_only_relevant_orders.contact_pk = cast_and_rename_bigcommerce_emails.contact_pk

),

join_orders_and_identifiers_and_select_relevant_fields as (

  select 
  
    join_emails_to_orders.order_natural_key,
    deduplicate_to_snowplow_first_order_event.event_user_identifier_application as order_user_identifier_application,
    cast( null as string ) as order_user_identifier_cart_token,
    deduplicate_to_snowplow_first_order_event.event_user_identifier_fingerprint as order_user_identifier_fingerprint,
    deduplicate_to_snowplow_first_order_event.event_user_identifier_server_side_cookie as order_user_identifier_server_side_cookie,
    deduplicate_to_snowplow_first_order_event.event_user_identifier_client_side_cookie as order_user_identifier_client_side_cookie,
    join_emails_to_orders.order_connector_source,
    join_emails_to_orders.country_code as order_country_code,
    join_emails_to_orders.order_email_address,
    join_emails_to_orders.ip_address as order_ip_address,
    join_emails_to_orders.postal_code as order_postal_code,
    join_emails_to_orders.order_amount_total,
    join_emails_to_orders.order_timestamp,
    join_emails_to_orders.order_timestamp_replicated,

  from join_emails_to_orders
  left join deduplicate_to_snowplow_first_order_event
    on deduplicate_to_snowplow_first_order_event.event_join_order_natural_key = join_emails_to_orders.order_natural_key

)

select * from join_orders_and_identifiers_and_select_relevant_fields
