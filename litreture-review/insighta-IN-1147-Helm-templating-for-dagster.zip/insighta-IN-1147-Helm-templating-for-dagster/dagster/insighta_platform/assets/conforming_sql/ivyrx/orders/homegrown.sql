with 

----------------------------------
-- bask orders < Oct 11, 2025
----------------------------------
bask_source_orders as (

 --select user_id, count(*) from ivyrx-iprod.ivyrx_prod_mart.sales_details where order_timestamp is null group by user_id
  select * from ivyrx-iprod.ivyrx_prod_mart.sales_details 

),

bask_snowplow_events as (

  select * from {{ gcp_project_id }}.{{ bigquery_dataset }}_pre_conforming.pc_dispatch__snowcatcloud_events 

),

concat_order_id as (

  select *,
    CAST(
      CASE 
        WHEN transaction_id IS NULL THEN order_number 
        ELSE transaction_id 
      END AS STRING
    ) AS order_natural_key

     from bask_source_orders

),

bask_filter_source_orders as (

  select * from concat_order_id
  where status != 'Abandoned'
  and status != 'Error'
  and order_timestamp is not null
  and order_timestamp < '2025-10-11'
  and order_natural_key is not null

),

bask_cast_and_rename_orders as (

  select

    -- natural keys - regular
    order_natural_key,

    -- natural keys - identity resolution
    cast( null as string ) as order_user_identifier_application,
    cast( null as string ) as order_user_identifier_cart_token,
    cast( null as string ) as order_user_identifier_fingerprint,
    cast( null as string ) as order_user_identifier_server_side_cookie,
    cast( null as string ) as order_user_identifier_client_side_cookie,

    -- strings
    cast('web' as string) as order_channel,
    'home_grown' as order_connector_source,
    cast( 'us' as string ) as order_country_code,
    cast( lower(email) as string ) as order_email_address,
    cast( null as string ) as order_ip_address,
    cast( 'regional' as string ) as order_mmm_geo_grain,
    order_natural_key as order_natural_key_customer_facing,
    cast( to_zip as string ) as order_postal_code,
    cast(null as string) order_sub_channel,
    cast('D2C' as string) as order_type,

    --booleans
    cast( true as boolean ) as is_directly_attributable,

    -- numbers
    cast( order_total as numeric ) as order_amount_total,

    -- timestamps
    timestamp( order_timestamp ) AS order_timestamp,

    cast( loaded_at as timestamp ) as order_timestamp_replicated
  
  from bask_filter_source_orders

),

----------------------------------
-- snowplow orders >= Oct 11, 2025
----------------------------------
source_orders as (

  select * from bask_snowplow_events

),

source_bask_data as (

  select 
    distinct transaction_id, 
    email 
  from bask_source_orders
  where email is not null 
    and transaction_id is not null

),

/************ BEGIN: Location Info by Event_ID ************/
extract_location_from_nested_columns as (

  select source_orders.*,
    lower( location.country.iso_code ) country_code,
    case 
      when(
        lower( location.country.iso_code ) = 'us'
      )
      then regexp_extract(location.postal.code, r'^\d{5}')
      else location.postal.code
      end as post_code_stg
  from source_orders,
  UNNEST (contexts_com_dbip_location_1_0_0) AS location

),

standardize_location as (

  select *,
    last_value(post_code_stg ignore nulls) over (
      partition by event_id
      order by load_tstamp
      rows between unbounded preceding and unbounded following
    ) as postal_code
  from extract_location_from_nested_columns

),
/************ END: Location Info by Event_ID ************/

/************ BEGIN: Find snowplow cart token and anonymous IDs ************/
extract_cart_token_from_nested_columns as (

  SELECT 
    distinct
    event_id,
    cast( derived_tstamp as timestamp ) event_timestamp,
    domain_sessionid,
    network_userid,
    domain_userid,
    country_code,
    postal_code,
    user_ipaddress,
    `contexts_com_snowplowanalytics_snowplow_ecommerce_transaction_1_0_0`[SAFE_OFFSET(0)].transaction_id as transaction_id,
    `contexts_com_snowplowanalytics_snowplow_ecommerce_transaction_1_0_0`[SAFE_OFFSET(0)].revenue as revenue,
    `contexts_com_snowplowanalytics_snowplow_ecommerce_transaction_1_0_0`[SAFE_OFFSET(0)].total_quantity as total_quantity,
  FROM standardize_location
  WHERE event_name = 'snowplow_ecommerce_action'
  group by all

),

deduplicate_extract_cart_token_from_nested_columns as (

  select *
  from extract_cart_token_from_nested_columns
    qualify row_number() over (
        partition by transaction_id
        order by event_timestamp desc
      ) = 1

),
/************ END: Find snowplow cart token and anonymous IDs ************/

/************ BEGIN: Find Emails Addresses by form fill events **************/
extract_email_from_non_nested_columns as (

  select *,
    
    case
      when regexp_contains(
        unstruct_event_com_snowplowanalytics_snowplow_focus_form_1_0_0.value,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unstruct_event_com_snowplowanalytics_snowplow_focus_form_1_0_0.value
      end as web_event_email_address_focus_form,
    
    case
      when regexp_contains(
        unstruct_event_com_snowplowanalytics_snowplow_change_form_1_0_0.value,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unstruct_event_com_snowplowanalytics_snowplow_change_form_1_0_0.value
      end as web_event_email_address_change_form,

  from standardize_location

),

extract_email_address_from_nested_submit_form as (

  select distinct

    event_id,

    case
      when regexp_contains(
        unnested_elements.value,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_elements.value
      end as web_event_email_address_submit_form,

  from extract_email_from_non_nested_columns

    cross join unnest(
      extract_email_from_non_nested_columns.unstruct_event_com_snowplowanalytics_snowplow_submit_form_1_0_0.elements
      ) AS unnested_elements

  where true

    -- filter out nulls to avoid fan-out
    and case
      when regexp_contains(
        unnested_elements.value,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_elements.value
      end is not null

),

extract_email_address_from_nested_ecommerce_user as (

  select distinct

    event_id,

    case
      when regexp_contains(
        unnested_ecommerce_user.email,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_ecommerce_user.email
      end as web_event_email_address_ecommerce_user,

  from extract_email_from_non_nested_columns

    cross join unnest(
      extract_email_from_non_nested_columns.contexts_com_snowplowanalytics_snowplow_ecommerce_user_1_0_0
      ) AS unnested_ecommerce_user

  where true

    -- filter out nulls to avoid fan-out
    and case
      when regexp_contains(
        unnested_ecommerce_user.email,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_ecommerce_user.email
      end is not null

),

join_unnested_to_non_nested as (

  select

    extract_email_from_non_nested_columns.event_id,
    cast( extract_email_from_non_nested_columns.derived_tstamp as timestamp ) event_timestamp,
    -- Anonymous IDs
    extract_email_from_non_nested_columns.domain_sessionid,
    extract_email_from_non_nested_columns.network_userid,
    extract_email_from_non_nested_columns.domain_userid,
    -- Email addresses
    extract_email_from_non_nested_columns.web_event_email_address_focus_form,
    extract_email_from_non_nested_columns.web_event_email_address_change_form,
    extract_email_address_from_nested_submit_form.web_event_email_address_submit_form,
    extract_email_address_from_nested_ecommerce_user.web_event_email_address_ecommerce_user,

  from extract_email_from_non_nested_columns

    left join extract_email_address_from_nested_submit_form

      using (event_id)

    left join extract_email_address_from_nested_ecommerce_user

      using (event_id)
    
    left join deduplicate_extract_cart_token_from_nested_columns

      using (event_id)

),

email_address_by_anonymous_ids as (

  select
    event_timestamp,
    domain_sessionid,
    network_userid,
    domain_userid,
    coalesce(
        web_event_email_address_focus_form,
        web_event_email_address_change_form,
        web_event_email_address_submit_form,
        web_event_email_address_ecommerce_user
      ) as web_event_email_address
  from join_unnested_to_non_nested

),

deduplicate_domain_sessionid as (

  select 
    domain_sessionid,
    web_event_email_address
  from email_address_by_anonymous_ids
  where web_event_email_address is not null
  qualify row_number() over (
      partition by domain_sessionid
      order by event_timestamp desc
    ) = 1

),

deduplicate_network_userid as (

  select 
    network_userid,
    web_event_email_address
  from email_address_by_anonymous_ids
  where web_event_email_address is not null
  qualify row_number() over (
      partition by network_userid
      order by event_timestamp desc
    ) = 1

),

deduplicate_domain_userid as (

  select 
    domain_userid,
    web_event_email_address
  from email_address_by_anonymous_ids
  where web_event_email_address is not null
  qualify row_number() over (
      partition by domain_userid
      order by event_timestamp desc
    ) = 1

),
/************ END: Find Emails Addresses by form fill events **************/

/************ BEGIN: Join Emails Addresses to orders by anonymous IDs **************/
join_email_addresses_to_conversions as (

  select 
    deduplicate_extract_cart_token_from_nested_columns.*,
    coalesce(deduplicate_domain_sessionid.web_event_email_address, deduplicate_network_userid.web_event_email_address, deduplicate_domain_userid.web_event_email_address, source_bask_data.email) web_event_email_address,
  from deduplicate_extract_cart_token_from_nested_columns
  left join deduplicate_domain_sessionid on deduplicate_extract_cart_token_from_nested_columns.domain_sessionid = deduplicate_domain_sessionid.domain_sessionid
  left join deduplicate_network_userid on deduplicate_extract_cart_token_from_nested_columns.network_userid = deduplicate_network_userid.network_userid
  left join deduplicate_domain_userid on deduplicate_extract_cart_token_from_nested_columns.domain_userid = deduplicate_domain_userid.domain_userid
  left join source_bask_data on cast( deduplicate_extract_cart_token_from_nested_columns.transaction_id as string ) = cast( source_bask_data.transaction_id as string )

),
/************ END: Join Emails Addresses to orders by anonymous IDs **************/

cast_and_rename_orders as (

  select

    -- natural keys - regular
    cast(transaction_id as string) as order_natural_key,

    -- natural keys - identity resolution
    cast(null as string) as order_user_identifier_application,
    cast(transaction_id as string) as order_user_identifier_cart_token,
    cast(null as string) as order_user_identifier_fingerprint,
    cast(network_userid as string) as order_user_identifier_server_side_cookie,
    cast(domain_userid as string) as order_user_identifier_client_side_cookie,

    -- strings
    cast('web' as string) as order_channel,
    'home_grown' as order_connector_source,
    lower( cast( country_code as string ) ) as order_country_code,
    cast(web_event_email_address as string ) as order_email_address,
    cast(user_ipaddress as string) as order_ip_address,
    cast( 'regional' as string ) as order_mmm_geo_grain,
    cast(transaction_id as string) as order_natural_key_customer_facing,
    cast(postal_code as string) as order_postal_code,
    cast(null as string) order_sub_channel,
    cast('D2C' as string) as order_type,

    --booleans
    cast( true as boolean ) as is_directly_attributable,

    -- numbers
    cast(revenue as numeric) as order_amount_total,

    -- timestamps
    timestamp( event_timestamp ) AS order_timestamp,

    cast( event_timestamp as timestamp ) as order_timestamp_replicated,
  
  from join_email_addresses_to_conversions

),

filter_snowplow_orders_date as (

  select * from cast_and_rename_orders
  where order_timestamp >= '2025-10-11'

),

----------------------------------
-- Unioned View
----------------------------------
union_bask_and_snowplow_orders as (

  select * from bask_cast_and_rename_orders

  union all 

  select * from filter_snowplow_orders_date

)

select * from union_bask_and_snowplow_orders