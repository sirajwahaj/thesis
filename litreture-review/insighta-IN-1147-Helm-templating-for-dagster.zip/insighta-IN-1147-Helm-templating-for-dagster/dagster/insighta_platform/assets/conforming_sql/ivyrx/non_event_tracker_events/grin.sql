with 

grin_base_distinct_id as (

  select * from ivyrx-iprod.grin.conversion

),

coalesce_order_number_and_order_id as (

  select 
    *,
    cast( coalesce(order_number,order_id) as string ) as coalesce_order_id,
  from grin_base_distinct_id
),

source_orders as (

  {{ ref('orders', 'homegrown') }}

),

rename_cast_and_order_columns as (

  select 

    -- natural keys
    cast (coalesce_order_number_and_order_id.id as string ) as non_event_tracker_event_natural_key,
    cast (coalesce_order_number_and_order_id.affiliate_link_id as string ) as non_event_tracker_event_campaign_natural_key,
    lower( cast( 'us' as string ) ) as non_event_tracker_event_country_code,

    --strings
    cast( 'grin' as string ) as non_event_tracker_event_connector_source,
    cast( source_orders.order_email_address as string ) as non_event_tracker_event_email_address,
    cast( 'affiliate' as string ) as non_event_tracker_event_medium_name,
    cast( 'affiliate link click' as string ) as non_event_tracker_event_name,
    cast( order_ip_address as string ) as non_event_tracker_event_ip_address,
    cast( order_postal_code as string ) as non_event_tracker_event_postal_code,

    -- numbers
    cast( coalesce_order_number_and_order_id.commission_amount as numeric ) as non_event_tracker_event_cost,

    --datetime
    cast( coalesce_order_number_and_order_id.created_at as timestamp ) as non_event_tracker_event_timestamp,
    cast( coalesce_order_number_and_order_id._fivetran_synced as timestamp ) as non_event_tracker_event_timestamp_replicated,

  from coalesce_order_number_and_order_id

    left join source_orders 
    
      on cast(coalesce_order_number_and_order_id.coalesce_order_id as string) =  cast(source_orders.order_natural_key as string)

)

select * from rename_cast_and_order_columns
