with

--stackadapt view data

stackadapt_impression_source as (

  select * from ivyrx-iprod.stackadapt.stackadapt_ivyrx_bigquery_conv

),

source_orders as (

  {{ ref('orders', 'homegrown') }}

),

filter_to_conversion_orders as (

  select distinct * from stackadapt_impression_source
  where order_id like ('%pi_%')

),

create_non_event_tracker_event_natural_key as (

  select *,
      cast(req_uniq_id as string)
      || '_' || cast(FIRST_TIME_IMP_FORMAT as string)
      || '_' || cast(LAST_IMP_TIME_FORMAT as string)
      || '_' || cast(CAMPAIGN_ID as string)
      || '_' || cast(NATIVEAD_ID as string)
      || '_' || cast(ORDER_ID as string)
      || '_' || cast(CONV_TIME_FORMAT as string)
      as non_event_tracker_event_natural_key
  from filter_to_conversion_orders

),

conform_and_rename_and_order_columns as (

  select
  
    -- natural keys
    cast( create_non_event_tracker_event_natural_key.non_event_tracker_event_natural_key as string ) as non_event_tracker_event_natural_key,
    cast( cast( create_non_event_tracker_event_natural_key.campaign_id as numeric ) as string ) as non_event_tracker_event_campaign_natural_key,
    lower( cast( source_orders.order_country_code as string ) ) as non_event_tracker_event_country_code,

    --strings
    cast( 'stackadapt' as string ) as non_event_tracker_event_connector_source,
    source_orders.order_email_address as non_event_tracker_event_email_address,
    cast( 'display' as string ) as non_event_tracker_event_medium_name,
    cast( 'display ad view' as string ) as non_event_tracker_event_name,
    cast( source_orders.order_ip_address as string ) as non_event_tracker_event_ip_address,
    cast( source_orders.order_postal_code as string ) non_event_tracker_event_postal_code,

    -- numbers
    cast( null as numeric ) as non_event_tracker_event_cost,

    --datetime
    cast( create_non_event_tracker_event_natural_key.first_time_imp_format as timestamp ) as non_event_tracker_event_timestamp,
    cast( create_non_event_tracker_event_natural_key.last_imp_time_format as timestamp ) as non_event_tracker_event_timestamp_replicated,

  from create_non_event_tracker_event_natural_key

    left join source_orders 
    
      on cast(create_non_event_tracker_event_natural_key.order_id as string) =  cast(source_orders.order_natural_key as string)

)

select * from conform_and_rename_and_order_columns