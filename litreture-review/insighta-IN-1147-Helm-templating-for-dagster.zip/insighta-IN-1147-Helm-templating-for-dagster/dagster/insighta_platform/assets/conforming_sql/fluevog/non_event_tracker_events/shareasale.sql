--nonevents conforming shareasale

with 

source_shareasale_conversions as (

  select * from fluevog-insighta.shareasale.transaction

),


source_web_events as (

  select * from {{ gcp_project_id }}.{{ bigquery_dataset }}_pre_conforming.pc_dispatch__snowcatcloud_events

),

filter_out_no_clicks as (

  select * from source_shareasale_conversions
  where date_of_click is not null 

),

filter_out_reversed as (

  select * from filter_out_no_clicks
  where date_of_reversal is null
  
),

web_events_filter_to_org as (

  select * from source_web_events
  where app_id = 'fluevog'

),

extract_location_from_nested_columns as (

  select web_events_filter_to_org.*,
    lower( location.country.iso_code ) country_code,
    case 
      when(
        lower( location.country.iso_code ) = 'us'
      )
      then regexp_extract(location.postal.code, r'^\d{5}')
      else location.postal.code
      end as post_code_stg
  from web_events_filter_to_org,
  UNNEST (contexts_com_dbip_location_1_0_0) AS location

),

standardize_location as (

  select *,
    last_value(post_code_stg ignore nulls) over (
      partition by event_id
      order by load_tstamp
      rows between unbounded preceding and unbounded following
    ) as postal_code
  from extract_location_from_nested_columns

),

select_web_events as (

  select 
    contexts_com_snowplowanalytics_snowplow_ecommerce_transaction_1_0_0[SAFE_OFFSET(0)].transaction_id ,
    contexts_com_snowplowanalytics_snowplow_ecommerce_user_1_0_0[SAFE_OFFSET(0)].email,
    * 
  from standardize_location
  where contexts_com_snowplowanalytics_snowplow_ecommerce_transaction_1_0_0[SAFE_OFFSET(0)].transaction_id is not null

),

join_web_events_and_select as (

  select 
    cast(filter_out_reversed.id as string) as non_event_tracker_event_natural_key,
    'campaign shareasale' as non_event_tracker_event_campaign_natural_key,
    lower( cast( country_code as string ) ) as non_event_tracker_event_country_code,
    'shareasale' as non_event_tracker_event_connector_source,
    lower(cast(select_web_events.email as string) ) as non_event_tracker_event_email_address,
    'affiliate' as non_event_tracker_event_medium_name,
    'affilite link clicked' as non_event_tracker_event_name,
    cast( user_ipaddress as string ) as non_event_tracker_event_ip_address,
    cast( postal_code as string ) as non_event_tracker_event_postal_code,
    cast( filter_out_reversed.commission as numeric ) as non_event_tracker_event_cost,
    timestamp(date_of_click) as non_event_tracker_event_timestamp,
    timestamp(_fivetran_synced) as non_event_tracker_event_timestamp_replicated

  from filter_out_reversed
  left join select_web_events
  on filter_out_reversed.order_number = select_web_events.transaction_id

)


select * 
from join_web_events_and_select
