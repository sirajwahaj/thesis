
with 

raw_cad_orders_table as (

  select * from fluevog-insighta.analytics_ftp.fluevog_ftp_destination_tables__amberpos_transactions_canada_1__11__file_replication
   
),

raw_usd_orders_table as (

  select * from fluevog-insighta.analytics_ftp.fluevog_ftp_destination_tables__amberpos_transactions_united_states_1__10__file_replication
   
), 

source_currency_exchange as (

  select * from insighta-021324.currency_exchange.rate

),

cast_and_filter_currency_exchange as (

  select
    cast(data_timestamps as date) as join_day,
    safe_cast(rate as float64) as canadian_exchange_rate
  from source_currency_exchange
  where currency_code = 'CAD'
  qualify row_number() over (partition by data_timestamps order by _fivetran_synced desc) = 1

),

raw_usd_to_cad_orders_table as (

  select
    TRANSID,
    CUSTOMERNAME,
    EMAIL,
    TransNumber,
    TRANSACTIONTYPE,
    SHIPPINGPOSTALZIP,
    'United States' as COUNTRY,
    SALESCLERKUSERNAME,
    Time,
    _INSIGHTA_REPLICATION_TIMESTAMP,
    Description,
    SKU,
    qty,
    safe_cast(subtotal as float64)*ifnull(b.canadian_exchange_rate,1) as subtotal,
  from raw_usd_orders_table a
  left outer join cast_and_filter_currency_exchange b on date_trunc(a.time, day) = b.join_day

),

raw_orders_table as (

  select
    TRANSID,
    CUSTOMERNAME,
    EMAIL,
    TransNumber,
    TRANSACTIONTYPE,
    SHIPPINGPOSTALZIP,
    'Canada' as COUNTRY,
    SALESCLERKUSERNAME,
    Time,
    _INSIGHTA_REPLICATION_TIMESTAMP,    
    Description,
    SKU,
    qty,
    safe_cast(subtotal as float64) as subtotal,
  from raw_cad_orders_table a

  union all

  select 
    * 
  from raw_usd_to_cad_orders_table

),

add_order_pk as (

  SELECT
    -- concat(cast(TRANSID as string),'-',cast(TransNumber as string),'-',cast(SKU as string),'-',CAST(Description AS STRING)) order_pk, -- change made 7/9/2025
    concat(cast(TRANSID as string),'-',cast(TransNumber as string)) order_pk,
    *
  from raw_orders_table

)
, 

orders_mapped as (

  SELECT
    order_pk,
    CAST(CUSTOMERNAME AS STRING)     AS CustomerName,
    lower(CAST(EMAIL as STRING)) email,
    CAST(TransNumber AS STRING)     AS TransNumber,
    CAST(Time AS TIMESTAMP)  AS DateOfTransaction,
    cast(_INSIGHTA_REPLICATION_TIMESTAMP as timestamp) as replication_datetime,
    CAST(Description AS STRING)     AS Description,
    CAST(SKU AS STRING)     AS SKU,
    cast(SHIPPINGPOSTALZIP AS STRING) AS SHIPPINGPOSTALZIP,
    cast(COUNTRY AS STRING) AS COUNTRY,
    cast(SALESCLERKUSERNAME as STRING) AS SALESCLERKUSERNAME,
    sum(CAST(qty AS NUMERIC))    AS qty,
    sum(safe_cast(subtotal as float64)) subtotal,
  from add_order_pk
  where 1=1
    and lower(ifnull(TRANSACTIONTYPE,'none')) in ('void','invoice')
  group by all

),

orders_returned as (

  select
    order_pk,
    CustomerName,
    TransNumber,
    DateOfTransaction,
    replication_datetime,
    email,
    TRIM(REGEXP_EXTRACT(LOWER(Description), r'(\d{1,7}-\d{1,7})\s*invoice')) AS invoice_number,
    SKU,
    qty,
    subtotal,
    SHIPPINGPOSTALZIP,
    COUNTRY,
    SALESCLERKUSERNAME,
  from orders_mapped
  where qty < 0

),

orders_minus_returns as (

  select 
    orders_mapped.order_pk,
    orders_mapped.CustomerName,
    orders_mapped.TransNumber,
    orders_mapped.DateOfTransaction,
    orders_mapped.replication_datetime,
    orders_mapped.email,
    orders_mapped.TransNumber as invoice_number,
    -- orders_mapped.SKU, -- change made 7/9/2025
    sum(orders_mapped.qty + ifnull(orders_returned.qty,0)) qty,
    sum(orders_mapped.subtotal + ifnull(orders_returned.subtotal,0)) subtotal,
    orders_mapped.SHIPPINGPOSTALZIP,
    orders_mapped.COUNTRY,
    orders_mapped.SALESCLERKUSERNAME,
  from orders_mapped
  left outer join orders_returned on orders_mapped.TransNumber = orders_returned.invoice_number and orders_mapped.SKU = orders_returned.SKU
  where orders_mapped.qty > 0
  group by all

  union all 

  select
    order_pk,
    CustomerName,
    TransNumber,
    DateOfTransaction,
    replication_datetime,
    email,
    invoice_number,
    -- SKU, -- change made 7/9/2025
    qty,
    subtotal,
    SHIPPINGPOSTALZIP,
    COUNTRY,
    SALESCLERKUSERNAME,
  from orders_returned
  where orders_returned.invoice_number is null
  
),

select_rename_and_order as (

  select distinct

  --keys
  cast(order_pk as string) as order_natural_key,
  cast(null as string) as order_user_identifier_application,
  cast(null as string) as order_user_identifier_cart_token,
  cast(null as string) as order_user_identifier_fingerprint,
  cast(null as string) as order_user_identifier_server_side_cookie,
  cast(null as string) as order_user_identifier_client_side_cookie,

  --strings
  cast(case when lower(SALESCLERKUSERNAME) in ('webby webby','web sales') then 'web' else 'in-store' end as string) order_channel,
  cast('amberPOS' as string) as order_connector_source,
  cast(COUNTRY as string) as order_country_code,
  cast(email as string) as order_email_address,
  cast(null as string) as order_ip_address,
  cast( 'regional' as string ) as order_mmm_geo_grain,
  cast(order_pk as string) as order_natural_key_customer_facing,
  cast(SHIPPINGPOSTALZIP as string) as order_postal_code,
  cast(null as string) order_sub_channel,
  cast(case when lower(SALESCLERKUSERNAME) in ('webby webby','web sales') then 'd2c web' else 'd2c in-store' end as string) order_type,
  
  --booleans
  cast( true as boolean ) as is_directly_attributable,

  --numbers
  cast(subtotal as numeric) as order_amount_total,

  --timestamp
  cast(DateOfTransaction as timestamp) as order_timestamp,
  cast(replication_datetime as timestamp) as order_timestamp_replicated,

  from orders_minus_returns

),

filter_null_timestamps as (

  select 
    * 
  from select_rename_and_order
  where order_timestamp is not null

)

select * from filter_null_timestamps where true
