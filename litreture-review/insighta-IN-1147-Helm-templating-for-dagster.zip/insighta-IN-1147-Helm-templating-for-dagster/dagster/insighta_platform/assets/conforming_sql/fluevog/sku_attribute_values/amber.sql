with 

raw_cad_orders_table as (

  select * from fluevog-insighta.analytics_ftp.fluevog_ftp_destination_tables__amberpos_transactions_canada_1__11__file_replication
   
),

raw_usd_orders_table as (

  select * from fluevog-insighta.analytics_ftp.fluevog_ftp_destination_tables__amberpos_transactions_united_states_1__10__file_replication
   
),

union_tables as (

  select
    Description,
    Departmentfullname,
    Productnumber,
    SKU,
  from raw_cad_orders_table a

  union all

  select
    Description,
    Departmentfullname,
    Productnumber,
    SKU,
  from raw_usd_orders_table a

),

rename_description_and_sku as (

  select
    
    distinct 
    TRIM(
      REGEXP_REPLACE(
        LOWER(Description),
        r'\s+((\d+-\d+|\d+)(\s+invoice)?|invoice)$',
        ''
      )
    ) sku_description,
    Productnumber,
    Departmentfullname,
    REGEXP_REPLACE(CAST(sku AS STRING), r'\.0$', '') as sku_id,

  from union_tables

),

select_distinct_sku_id_and_name as (

  select 
    distinct sku_id, -- Individual SKU
    Productnumber as sku_name,  -- Sku Name
    Departmentfullname as department,
    sku_description,
    LOWER(REGEXP_REPLACE(sku_id, r'[^a-zA-Z0-9]', '')) sku_id_key,
    LOWER(REGEXP_REPLACE(sku_description, r'[^a-zA-Z0-9]', '')) sku_name_key,
    LOWER(REGEXP_REPLACE(Departmentfullname, r'[^a-zA-Z0-9]', '')) departmentfullname_key,
  from rename_description_and_sku

),

filter_out_postage_skus as (
  
  select 
    *
  from select_distinct_sku_id_and_name
  where true
    and sku_id is not null
    and sku_id <> ""
    and lower(sku_id) not in ('783','784','798','800','misc')
    and sku_name_key is not null
    and sku_name_key <> ""
    and sku_name_key not like ('%postage%')
    and sku_name_key not like ('%shoppingbag%')

),

add_families as (

  select 
    *,
    case
      when lower(sku_description) like '%240 wagons%' then '240 wagons'
      when lower(sku_description) like '%40th anniversary reissues%' then '40th anniversary reissues'
      when lower(sku_description) like '%760 turbo%' then '760 turbo'
      when lower(sku_description) like '%adriana%' then 'adriana'
      when lower(sku_description) like '%adrians%' then 'adrians'
      when lower(sku_description) like '%ajs%' then 'ajs'
      when lower(sku_description) like '%amblesides%' then 'amblesides'
      when lower(sku_description) like '%angels%' then 'angels'
      when lower(sku_description) like '%another day%' then 'another day'
      when lower(sku_description) like '%arc%' then 'arc'
      when lower(sku_description) like '%arch angel%' then 'arch angel'
      when lower(sku_description) like '%aristotle%' then 'aristotle'
      when lower(sku_description) like '%ask%' then 'ask'
      when lower(sku_description) like '%attentions%' then 'attentions'
      when lower(sku_description) like '%atv%' then 'atv'
      when lower(sku_description) like '%autry%' then 'autry'
      when lower(sku_description) like '%awake%' then 'awake'
      when lower(sku_description) like '%babies%' then 'babies'
      when lower(sku_description) like '%balthazar%' then 'balthazar'
      when lower(sku_description) like '%banker%' then 'banker'
      when lower(sku_description) like '%basement%' then 'basement'
      when lower(sku_description) like '%bass minstrels%' then 'bass minstrels'
      when lower(sku_description) like '%beat boots%' then 'beat boots'
      when lower(sku_description) like '%beats%' then 'beats'
      when lower(sku_description) like '%begin%' then 'begin'
      when lower(sku_description) like '%bellevue%' then 'bellevue'
      when lower(sku_description) like '%berlin%' then 'berlin'
      when lower(sku_description) like '%big city%' then 'big city'
      when lower(sku_description) like '%bike shoe%' then 'bike shoe'
      when lower(sku_description) like '%blind faiths hi%' then 'blind faiths hi'
      when lower(sku_description) like '%blind faiths low%' then 'blind faiths low'
      when lower(sku_description) like '%blind faiths mid%' then 'blind faiths mid'
      when lower(sku_description) like '%body parts%' then 'body parts'
      when lower(sku_description) like '%brook%' then 'brook'
      when lower(sku_description) like '%calgary%' then 'calgary'
      when lower(sku_description) like '%capitalists%' then 'capitalists'
      when lower(sku_description) like '%celestial communication%' then 'celestial communication'
      when lower(sku_description) like '%chill out%' then 'chill out'
      when lower(sku_description) like '%choice%' then 'choice'
      when lower(sku_description) like '%choice hi%' then 'choice hi'
      when lower(sku_description) like '%city angels%' then 'city angels'
      when lower(sku_description) like '%coffee%' then 'coffee'
      when lower(sku_description) like '%colour%' then 'colour'
      when lower(sku_description) like '%commune%' then 'commune'
      when lower(sku_description) like '%connoisseurs%' then 'connoisseurs'
      when lower(sku_description) like '%conquer%' then 'conquer'
      when lower(sku_description) like '%cooler%' then 'cooler'
      when lower(sku_description) like '%coolest%' then 'coolest'
      when lower(sku_description) like '%cosmos%' then 'cosmos'
      when lower(sku_description) like '%cougars%' then 'cougars'
      when lower(sku_description) like '%couture vogs%' then 'couture vogs'
      when lower(sku_description) like '%craftsman%' then 'craftsman'
      when lower(sku_description) like '%creepers%' then 'creepers'
      when lower(sku_description) like '%creepers old%' then 'creepers old'
      when lower(sku_description) like '%d.o.g.s%' then 'd.o.g.s'
      when lower(sku_description) like '%daily miracles%' then 'daily miracles'
      when lower(sku_description) like '%dandy%' then 'dandy'
      when lower(sku_description) like '%dashers%' then 'dashers'
      when lower(sku_description) like '%deliverance%' then 'deliverance'
      when lower(sku_description) like '%desires%' then 'desires'
      when lower(sku_description) like '%down to earth%' then 'down to earth'
      when lower(sku_description) like '%driven%' then 'driven'
      when lower(sku_description) like '%drivers%' then 'drivers'
      when lower(sku_description) like '%earl of warwicks%' then 'earl of warwicks'
      when lower(sku_description) like '%earls%' then 'earls'
      when lower(sku_description) like '%earth angel%' then 'earth angel'
      when lower(sku_description) like '%earth angels%' then 'earth angels'
      when lower(sku_description) like '%effortless%' then 'effortless'
      when lower(sku_description) like '%elegant conversations%' then 'elegant conversations'
      when lower(sku_description) like '%encourage%' then 'encourage'
      when lower(sku_description) like '%entity%' then 'entity'
      when lower(sku_description) like '%entrance%' then 'entrance'
      when lower(sku_description) like '%envision%' then 'envision'
      when lower(sku_description) like '%esoteric temptations%' then 'esoteric temptations'
      when lower(sku_description) like '%espadrilles%' then 'espadrilles'
      when lower(sku_description) like '%expectations%' then 'expectations'
      when lower(sku_description) like '%exsequi%' then 'exsequi'
      when lower(sku_description) like '%f-shoe%' then 'f-shoe'
      when lower(sku_description) like '%fairway%' then 'fairway'
      when lower(sku_description) like '%faith hi%' then 'faith hi'
      when lower(sku_description) like '%faiths%' then 'faiths'
      when lower(sku_description) like '%faiths low%' then 'faiths low'
      when lower(sku_description) like '%feature%' then 'feature'
      when lower(sku_description) like '%fellowship flats%' then 'fellowship flats'
      when lower(sku_description) like '%fellowship hi%' then 'fellowship hi'
      when lower(sku_description) like '%fishermen%' then 'fishermen'
      when lower(sku_description) like '%flat 6%' then 'flat 6'
      when lower(sku_description) like '%flattops%' then 'flattops'
      when lower(sku_description) like '%flight%' then 'flight'
      when lower(sku_description) like '%flupipes%' then 'flupipes'
      when lower(sku_description) like '%flyvogs%' then 'flyvogs'
      when lower(sku_description) like '%flyvogs old%' then 'flyvogs old'
      when lower(sku_description) like '%fortitude%' then 'fortitude'
      when lower(sku_description) like '%free%' then 'free'
      when lower(sku_description) like '%freedom%' then 'freedom'
      when lower(sku_description) like '%friends%' then 'friends'
      when lower(sku_description) like '%frontier hi%' then 'frontier hi'
      when lower(sku_description) like '%frontiers%' then 'frontiers'
      when lower(sku_description) like '%frugals%' then 'frugals'
      when lower(sku_description) like '%futures%' then 'futures'
      when lower(sku_description) like '%gallant%' then 'gallant'
      when lower(sku_description) like '%garden of enjoyment%' then 'garden of enjoyment'
      when lower(sku_description) like '%garden of fluevog%' then 'garden of fluevog'
      when lower(sku_description) like '%gateway angels%' then 'gateway angels'
      when lower(sku_description) like '%getups%' then 'getups'
      when lower(sku_description) like '%global freedoms%' then 'global freedoms'
      when lower(sku_description) like '%go groovy%' then 'go groovy'
      when lower(sku_description) like '%good boys%' then 'good boys'
      when lower(sku_description) like '%good manners%' then 'good manners'
      when lower(sku_description) like '%grand nationals%' then 'grand nationals'
      when lower(sku_description) like '%granvilles%' then 'granvilles'
      when lower(sku_description) like '%greater expectations%' then 'greater expectations'
      when lower(sku_description) like '%guardian angels platform%' then 'guardian angels platform'
      when lower(sku_description) like '%half truths%' then 'half truths'
      when lower(sku_description) like '%halos%' then 'halos'
      when lower(sku_description) like '%headliners%' then 'headliners'
      when lower(sku_description) like '%hi angel%' then 'hi angel'
      when lower(sku_description) like '%hi living%' then 'hi living'
      when lower(sku_description) like '%hi wedge%' then 'hi wedge'
      when lower(sku_description) like '%hifs%' then 'hifs'
      when lower(sku_description) like '%history%' then 'history'
      when lower(sku_description) like '%hoodlum%' then 'hoodlum'
      when lower(sku_description) like '%hopes%' then 'hopes'
      when lower(sku_description) like '%hopscotch%' then 'hopscotch'
      when lower(sku_description) like '%i believe%' then 'i believe'
      when lower(sku_description) like '%i believe high%' then 'i believe high'
      when lower(sku_description) like '%immortal perfection%' then 'immortal perfection'
      when lower(sku_description) like '%imperial swordfish%' then 'imperial swordfish'
      when lower(sku_description) like '%imperials%' then 'imperials'
      when lower(sku_description) like '%integrity%' then 'integrity'
      when lower(sku_description) like '%ishshoes%' then 'ishshoes'
      when lower(sku_description) like '%jet streams%' then 'jet streams'
      when lower(sku_description) like '%kickback%' then 'kickback'
      when lower(sku_description) like '%killa%' then 'killa'
      when lower(sku_description) like '%kings%' then 'kings'
      when lower(sku_description) like '%laureates%' then 'laureates'
      when lower(sku_description) like '%le tube%' then 'le tube'
      when lower(sku_description) like '%light%' then 'light'
      when lower(sku_description) like '%listen ups%' then 'listen ups'
      when lower(sku_description) like '%listens%' then 'listens'
      when lower(sku_description) like '%living%' then 'living'
      when lower(sku_description) like '%living 2.0%' then 'living 2.0'
      when lower(sku_description) like '%lofs%' then 'lofs'
      when lower(sku_description) like '%look%' then 'look'
      when lower(sku_description) like '%look out%' then 'look out'
      when lower(sku_description) like '%lopro 2%' then 'lopro 2'
      when lower(sku_description) like '%love%' then 'love'
      when lower(sku_description) like '%luxury freeze%' then 'luxury freeze'
      when lower(sku_description) like '%marquess swordfish%' then 'marquess swordfish'
      when lower(sku_description) like '%memories%' then 'memories'
      when lower(sku_description) like '%memories hi%' then 'memories hi'
      when lower(sku_description) like '%mezzo%' then 'mezzo'
      when lower(sku_description) like '%minstrels%' then 'minstrels'
      when lower(sku_description) like '%miracle platform%' then 'miracle platform'
      when lower(sku_description) like '%mission%' then 'mission'
      when lower(sku_description) like '%modern living%' then 'modern living'
      when lower(sku_description) like '%money walkers%' then 'money walkers'
      when lower(sku_description) like '%mountains%' then 'mountains'
      when lower(sku_description) like '%moxie magoo%' then 'moxie magoo'
      when lower(sku_description) like '%munsters%' then 'munsters'
      when lower(sku_description) like '%mystics%' then 'mystics'
      when lower(sku_description) like '%nature angels%' then 'nature angels'
      when lower(sku_description) like '%new romantics%' then 'new romantics'
      when lower(sku_description) like '%nyc%' then 'nyc'
      when lower(sku_description) like '%old romantics%' then 'old romantics'
      when lower(sku_description) like '%on course%' then 'on course'
      when lower(sku_description) like '%oriente%' then 'oriente'
      when lower(sku_description) like '%paperboys%' then 'paperboys'
      when lower(sku_description) like '%passage%' then 'passage'
      when lower(sku_description) like '%perfect%' then 'perfect'
      when lower(sku_description) like '%perus%' then 'perus'
      when lower(sku_description) like '%petit talons%' then 'petit talons'
      when lower(sku_description) like '%pfd%' then 'pfd'
      when lower(sku_description) like '%picnics%' then 'picnics'
      when lower(sku_description) like '%piglets%' then 'piglets'
      when lower(sku_description) like '%pin-ups%' then 'pin-ups'
      when lower(sku_description) like '%pin ups%' then 'pin-ups'
      when lower(sku_description) like '%pindowns%' then 'pindowns'
      when lower(sku_description) like '%pointy begins%' then 'pointy begins'
      when lower(sku_description) like '%power%' then 'power'
      when lower(sku_description) like '%powerhouse%' then 'powerhouse'
      when lower(sku_description) like '%prepare 2.0%' then 'prepare 2.0'
      when lower(sku_description) like '%prepare hi%' then 'prepare hi'
      when lower(sku_description) like '%prepare wedge%' then 'prepare wedge'
      when lower(sku_description) like '%presence%' then 'presence'
      when lower(sku_description) like '%provog%' then 'provog'
      when lower(sku_description) like '%purpose%' then 'purpose'
      when lower(sku_description) like '%queen of prussia%' then 'queen of prussia'
      when lower(sku_description) like '%queen of the skies%' then 'queen of the skies'
      when lower(sku_description) like '%race%' then 'race'
      when lower(sku_description) like '%ramblers%' then 'ramblers'
      when lower(sku_description) like '%regal swordfish%' then 'regal swordfish'
      when lower(sku_description) like '%resist%' then 'resist'
      when lower(sku_description) like '%restraint%' then 'restraint'
      when lower(sku_description) like '%river%' then 'river'
      when lower(sku_description) like '%rockstar%' then 'rockstar'
      when lower(sku_description) like '%rococo%' then 'rococo'
      when lower(sku_description) like '%romance%' then 'romance'
      when lower(sku_description) like '%ronnie%' then 'ronnie'
      when lower(sku_description) like '%rufus magoo%' then 'rufus magoo'
      when lower(sku_description) like '%rufus magoo high%' then 'rufus magoo high'
      when lower(sku_description) like '%rules%' then 'rules'
      when lower(sku_description) like '%ruth%' then 'ruth'
      when lower(sku_description) like '%sandals%' then 'sandals'
      when lower(sku_description) like '%saturday nights%' then 'saturday nights'
      when lower(sku_description) like '%sea angel%' then 'sea angel'
      when lower(sku_description) like '%seattle%' then 'seattle'
      when lower(sku_description) like '%second miracles%' then 'second miracles'
      when lower(sku_description) like '%shaguar%' then 'shaguar'
      when lower(sku_description) like '%shirts%' then 'shirts'
      when lower(sku_description) like '%simple living%' then 'simple living'
      when lower(sku_description) like '%slick%' then 'slick'
      when lower(sku_description) like '%sopranos%' then 'sopranos'
      when lower(sku_description) like '%stand out%' then 'stand out'
      when lower(sku_description) like '%straight 6%' then 'straight 6'
      when lower(sku_description) like '%style and grace%' then 'style and grace'
      when lower(sku_description) like '%summer of love%' then 'summer of love'
      when lower(sku_description) like '%summertimes%' then 'summertimes'
      when lower(sku_description) like '%swordfish%' then 'swordfish'
      when lower(sku_description) like '%tank%' then 'tank'
      when lower(sku_description) like '%tasty vogs%' then 'tasty vogs'
      when lower(sku_description) like '%teapots%' then 'teapots'
      when lower(sku_description) like '%televisions%' then 'televisions'
      when lower(sku_description) like '%terras%' then 'terras'
      when lower(sku_description) like '%thanks%' then 'thanks'
      when lower(sku_description) like '%the 11th hours%' then 'the 11th hours'
      when lower(sku_description) like '%the la%' then 'the la'
      when lower(sku_description) like '%the money shoes%' then 'the money shoes'
      when lower(sku_description) like '%the u family%' then 'the u family'
      when lower(sku_description) like '%thunder road%' then 'thunder road'
      when lower(sku_description) like '%time%' then 'time'
      when lower(sku_description) like '%together%' then 'together'
      when lower(sku_description) like '%together hi%' then 'together hi'
      when lower(sku_description) like '%tokyo%' then 'tokyo'
      when lower(sku_description) like '%tolerance%' then 'tolerance'
      when lower(sku_description) like '%tough loves%' then 'tough loves'
      when lower(sku_description) like '%training paths%' then 'training paths'
      when lower(sku_description) like '%travel vogs%' then 'travel vogs'
      when lower(sku_description) like '%travel-lites%' then 'travel-lites'
      when lower(sku_description) like '%travellers%' then 'travellers'
      when lower(sku_description) like '%trumpet call%' then 'trumpet call'
      when lower(sku_description) like '%turbo angel%' then 'turbo angel'
      when lower(sku_description) like '%twin turbines hi%' then 'twin turbines hi'
      when lower(sku_description) like '%twist%' then 'twist'
      when lower(sku_description) like '%unite%' then 'unite'
      when lower(sku_description) like '%urban angels%' then 'urban angels'
      when lower(sku_description) like '%values%' then 'values'
      when lower(sku_description) like '%veggie vogs%' then 'veggie vogs'
      when lower(sku_description) like '%virtue%' then 'virtue'
      when lower(sku_description) like '%walk%' then 'walk'
      when lower(sku_description) like '%waterfront%' then 'waterfront'
      when lower(sku_description) like '%wifi%' then 'wifi'
      when lower(sku_description) like '%wonder%' then 'wonder'
      when lower(sku_description) like '%world%' then 'world'
      when lower(sku_description) like '%wrappings%' then 'wrappings'
      when lower(sku_description) like '%writes%' then 'writes'
      when lower(sku_description) like '%you can%' then 'you can'
      when lower(sku_description) like '%zion%' then 'zion'
      when lower(sku_description) like '%zoomies%' then 'zoomies'
      when lower(sku_description) like '%f-angel%' then 'f-angel'
      when lower(sku_description) like '%grand master%' then 'grand master'
      when lower(sku_description) like '%judi%' then 'judi'
      when lower(sku_description) like '%lip service%' then 'lip service'
      when lower(sku_description) like '%pin up platform%' then 'pin up platform'
      when lower(sku_description) like '%pocket square%' then 'pocket square'
      when lower(sku_description) like '%carlton mk1%' then 'carlton mk1'
      when lower(sku_description) like '%signature%' then 'signature'
      when lower(sku_description) like '%ultra vog%' then 'ultra vog'
      when lower(sku_description) like '%accessories%' then 'accessories'
      when lower(sku_description) like '%book%' then 'book'
      when lower(sku_description) like '%chillville%' then 'chillville'
      when lower(sku_description) like '%executor%' then 'executor'
      when lower(sku_description) like '%fast cars%' then 'fast cars'
      when lower(sku_description) like '%fellowship%' then 'fellowship'
      when lower(sku_description) like '%graceville%' then 'graceville'
      when lower(sku_description) like '%kitschy kitschy boom boom%' then 'kitschy kitschy boom boom'
      when lower(sku_description) like '%operetta%' then 'operetta'
      when lower(sku_description) like '%radio 2%' then 'radio 2'
      when lower(sku_description) like '%replacement parts%' then 'replacement parts'
      when lower(sku_description) like '%socks%' then 'socks'
      when lower(sku_description) like '%thrillvogs%' then 'thrillvogs'
      when lower(sku_description) like '%tudor%' then 'tudor'
      when lower(sku_description) like '%views%' then 'views'
      when lower(sku_description) like '%7th heaven%' then '7th heaven'
      when lower(sku_description) like '%angelica%' then 'angelica'
      when lower(sku_description) like '%apparel%' then 'apparel'
      when lower(sku_description) like '%artisans%' then 'artisans'
      when lower(sku_description) like '%attic%' then 'attic'
      when lower(sku_description) like '%bags%' then 'bags'
      when lower(sku_description) like '%baroque%' then 'baroque'
      when lower(sku_description) like '%beaches%' then 'beaches'
      when lower(sku_description) like '%belts%' then 'belts'
      when lower(sku_description) like '%biblio%' then 'biblio'
      when lower(sku_description) like '%big presence%' then 'big presence'
      when lower(sku_description) like '%charms%' then 'charms'
      when lower(sku_description) like '%classy%' then 'classy'
      when lower(sku_description) like '%clouds of joy%' then 'clouds of joy'
      when lower(sku_description) like '%damsel%' then 'damsel'
      when lower(sku_description) like '%ddft%' then 'ddft'
      when lower(sku_description) like '%dollyvogs%' then 'dollyvogs'
      when lower(sku_description) like '%dragonet%' then 'dragonet'
      when lower(sku_description) like '%east end%' then 'east end'
      when lower(sku_description) like '%enneagram%' then 'enneagram'
      when lower(sku_description) like '%f-ing light%' then 'f-ing light'
      when lower(sku_description) like '%f-shoe hi%' then 'f-shoe hi'
      when lower(sku_description) like '%f-trip%' then 'f-trip'
      when lower(sku_description) like '%fae%' then 'fae'
      when lower(sku_description) like '%fearless%' then 'fearless'
      when lower(sku_description) like '%firefly%' then 'firefly'
      when lower(sku_description) like '%fjords%' then 'fjords'
      when lower(sku_description) like '%fox & fluevog%' then 'fox & fluevog'
      when lower(sku_description) like '%freshvogs%' then 'freshvogs'
      when lower(sku_description) like '%fresh vog%' then 'freshvogs'
      when lower(sku_description) like '%fruitful%' then 'fruitful'
      when lower(sku_description) like '%future angel%' then 'future angel'
      when lower(sku_description) like '%future round toe%' then 'future round toe'
      when lower(sku_description) like '%round toe%' then 'round toe'
      when lower(sku_description) like '%gateway%' then 'gateway'
      when lower(sku_description) like '%guardian angel%' then 'guardian angel'
      when lower(sku_description) like '%harmony%' then 'harmony'
      when lower(sku_description) like '%heartbreakers%' then 'heartbreakers'
      when lower(sku_description) like '%hopefuls%' then 'hopefuls'
      when lower(sku_description) like '%idol%' then 'idol'
      when lower(sku_description) like '%kickstarter%' then 'kickstarter'
      when lower(sku_description) like '%lasting impressions%' then 'lasting impressions'
      when lower(sku_description) like '%lopro%' then 'lopro'
      when lower(sku_description) like '%low rule%' then 'low rule'
      when lower(sku_description) like '%low swordfish%' then 'low swordfish'
      when lower(sku_description) like '%manifold%' then 'manifold'
      when lower(sku_description) like '%mega munster%' then 'mega munster'
      when lower(sku_description) like '%mellow%' then 'mellow'
      when lower(sku_description) like '%memento%' then 'memento'
      when lower(sku_description) like '%mini%' then 'mini'
      when lower(sku_description) like '%miracles%' then 'miracles'
      when lower(sku_description) like '%modvog%' then 'modvog'
      when lower(sku_description) like '%munster max%' then 'munster max'
      when lower(sku_description) like '%northampton%' then 'northampton'
      when lower(sku_description) like '%official%' then 'official'
      when lower(sku_description) like '%peacemaker%' then 'peacemaker'
      when lower(sku_description) like '%picnic%' then 'picnic'
      when lower(sku_description) like '%play grounders%' then 'play grounders'
      when lower(sku_description) like '%poser%' then 'poser'
      when lower(sku_description) like '%power up%' then 'power up'
      when lower(sku_description) like '%prepare%' then 'prepare'
      when lower(sku_description) like '%professionals%' then 'professionals'
      when lower(sku_description) like '%prophesy%' then 'prophesy'
      when lower(sku_description) like '%prowess%' then 'prowess'
      when lower(sku_description) like '%queen transcendent%' then 'queen transcendent'
      when lower(sku_description) like '%radio%' then 'radio'
      when lower(sku_description) like '%sea maidens%' then 'sea maidens'
      when lower(sku_description) like '%shoe care%' then 'shoe care'
      when lower(sku_description) like '%shoe laces%' then 'shoe laces'
      when lower(sku_description) like '%skyhigh f%' then 'skyhigh f'
      when lower(sku_description) like '%slacker%' then 'slacker'
      when lower(sku_description) like '%snappy%' then 'snappy'
      when lower(sku_description) like '%softly%' then 'softly'
      when lower(sku_description) like '%sole talk%' then 'sole talk'
      when lower(sku_description) like '%soul speed%' then 'soul speed'
      when lower(sku_description) like '%space edition%' then 'space edition'
      when lower(sku_description) like '%stand up%' then 'stand up'
      when lower(sku_description) like '%starlight%' then 'starlight'
      when lower(sku_description) like '%stop it%' then 'stop it'
      when lower(sku_description) like '%sturdy f%' then 'sturdy f'
      when lower(sku_description) like '%super classy%' then 'super classy'
      when lower(sku_description) like '%super fine%' then 'super fine'
      when lower(sku_description) like '%superfine%' then 'super fine'
      when lower(sku_description) like '%super provog%' then 'super provog'
      when lower(sku_description) like '%superclog%' then 'superclog'
      when lower(sku_description) like '%superfly%' then 'superfly'
      when lower(sku_description) like '%sword%' then 'sword'
      when lower(sku_description) like '%swordfish hi%' then 'swordfish hi'
      when lower(sku_description) like '%truth%' then 'truth'
      when lower(sku_description) like '%twin turbine%' then 'twin turbine'
      when lower(sku_description) like '%unity%' then 'unity'
      when lower(sku_description) like '%urban angel%' then 'urban angel'
      when lower(sku_description) like '%vogclog%' then 'vogclog'
      when lower(sku_description) like '%voggettes%' then 'voggettes'
      when lower(sku_description) like '%vogtalk%' then 'vogtalk'
      when lower(sku_description) like '%wallets%' then 'wallets'
      when lower(sku_description) like '%wearever%' then 'wearever'
      when lower(sku_description) like '%western punk%' then 'western punk'
      when lower(sku_description) like '%wizard%' then 'wizard'
      else null
    end as family
  from filter_out_postage_skus


),

sku_id_cast_and_rename as (

  select 
    distinct
    cast( 1 as string ) 
      || '_' || sku_id_key 
      as sku_attribute_value_natural_key,
    cast( 1 as string ) as sku_attribute_group_natural_key,
    sku_id as attribute_value
  from add_families

),

sku_name_cast_and_rename as (

  select 
    distinct
    cast( 2 as string ) 
      || '_' || sku_name_key 
      as sku_attribute_value_natural_key,
    cast( 2 as string ) as sku_attribute_group_natural_key,
    sku_name as attribute_value
  from add_families

),

department_name_cast_and_rename as (

  select 
    distinct
    cast( 3 as string ) 
      || '_' || departmentfullname_key 
      as sku_attribute_value_natural_key,
    cast( 3 as string ) as sku_attribute_group_natural_key,
    department as attribute_value
  from add_families

),

family_name_cast_and_rename as (

  select 
    distinct
    cast( 4 as string ) 
      || '_' || sku_name_key 
      as sku_attribute_value_natural_key,
    cast( 4 as string ) as sku_attribute_group_natural_key,
    family as attribute_value
  from add_families

),

union_cast_and_rename as (

  select * from sku_id_cast_and_rename

  union all

  select * from sku_name_cast_and_rename

  union all
  
  select * from department_name_cast_and_rename

  union all

  select * from family_name_cast_and_rename

)

select * from union_cast_and_rename
