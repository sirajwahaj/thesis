--shareasale campaign summary daily

with

source_shareasale_transactions as (

  select * from fluevog-insighta.shareasale.transaction
  
),

source_shareasale_daily_ad_platform_metrics as (

  select * from fluevog-insighta.shareasale.weekly_progress

),

source_currency_exchange as (

  select * from insighta-021324.currency_exchange.rate

),

cast_source_shareasale_daily_ad_platform_metrics as (

  select 
    DATE_TRUNC(PARSE_DATE('%m/%d/%Y', date), day) AS date,
    cast(_fivetran_synced as timestamp) _fivetran_synced,
    safe_cast(REGEXP_REPLACE(cast(gross_sale as string), r'[$,]', '') as numeric) gross_sale, 
    safe_cast(REGEXP_REPLACE(cast(sale_commission as string), r'[$,]', '') as numeric) sale_commission, 
    safe_cast(REGEXP_REPLACE(cast(lead_commission as string), r'[$,]', '') as numeric) lead_comission, 
    safe_cast(REGEXP_REPLACE(cast(number_sale as string), r'[$,]', '') as numeric) number_sale, 
    safe_cast(REGEXP_REPLACE(cast(number_of_sale as string), r'[$,]', '') as numeric) number_of_sale,
    safe_cast(REGEXP_REPLACE(cast(click as string), r'[$,]', '') as numeric) click,
    safe_cast(REGEXP_REPLACE(cast(bonus_commission as string), r'[$,]', '') as numeric) bonus_commission
  from source_shareasale_daily_ad_platform_metrics

),


cast_and_filter_currency_exchange as (

  select

    cast(data_timestamps as date) as join_day,
    cast(currency_code as string) as currency_code,
    cast(rate as numeric) as cad_exchange

  from source_currency_exchange
  where currency_code = "CAD"
),

join_conversion_rate as (

  select 
    source_shareasale_transactions.*,
    ifnull(cast_and_filter_currency_exchange.cad_exchange,1) cad_exchange,
  from source_shareasale_transactions
  left join cast_and_filter_currency_exchange
  on cast(source_shareasale_transactions.date_of_transaction as date) = cast_and_filter_currency_exchange.join_day
),

convert_transactions_to_CAD as (

  SELECT
    *,
    cast(transaction_amount as numeric) * ifnull(cad_exchange,1) as cad_transaction_amount,
    cast(commission as numeric) * ifnull(cad_exchange,1) as cad_commission
  FROM
    join_conversion_rate

),

dedup_source_shareasale_transactions as (

  select * from convert_transactions_to_CAD
  qualify row_number() over (partition by id order by _fivetran_synced desc) = 1

),

dedup_source_shareasale_daily_ad_platform_metrics as (

  select * from cast_source_shareasale_daily_ad_platform_metrics
  qualify row_number() over (partition by date order by _fivetran_synced desc) = 1

),

shareasale_transactions_filter_out_no_clicks as (

  select * from dedup_source_shareasale_transactions 
  where date_of_click is not null

),

shareasale_transactions_filter_out_reversed as (

  select * from shareasale_transactions_filter_out_no_clicks
  where date_of_reversal is null
  
),

shareasale_transactions_filter_out_null_order_number as (

  select * from shareasale_transactions_filter_out_reversed
  where order_number is not null
  
),

shareasale_base_campaign_summary_daily as (

  select 

    cast( id as string ) as non_event_tracker_event_natural_key,
    concat(cast('campaign shareasale' as string), '-', cast(cast( date_of_click as date ) as string )) as campaign_summary_daily_natural_key,
    cast( 'campaign shareasale' as string ) as campaign_summary_daily_campaign_natural_key,
    cast( 'shareasale' as string ) as campaign_summary_daily_connector_source,
    cast( cad_commission as numeric ) as id_cost,
    cast( cad_transaction_amount as numeric ) as conversion_value,
    order_number as order_number,
    cast( date_of_click as date ) as campaign_summary_daily_date,
    cast( _fivetran_synced as timestamp ) as _fivetran_synced,

  from shareasale_transactions_filter_out_null_order_number

),

shareasale_ad_platform_daily_clicks_impressions_by_campaign_day as (

  select
    date as campaign_summary_daily_date,
    concat(cast('campaign shareasale' as string), '-', cast(date as string )) as campaign_summary_daily_natural_key,
    cast( 'campaign shareasale' as string ) as campaign_summary_daily_campaign_natural_key,
    cast( 'shareasale' as string ) as campaign_summary_daily_connector_source,
    cast(sum(click) as numeric) as campaign_summary_daily_clicks,
    cast( null as numeric ) as campaign_summary_daily_impressions,
    _fivetran_synced as campaign_summary_daily_timestamp_replicated,
  from dedup_source_shareasale_daily_ad_platform_metrics
  group by all

),

total_transaction_metrics_by_campaign_day as (

  select 

     -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,

    -- strings
    campaign_summary_daily_connector_source,

    -- numbers
    cast(count(distinct order_number ) as numeric) as campaign_summary_daily_conversions,
    cast(sum( conversion_value ) as numeric) as campaign_summary_daily_conversions_value,
    cast(sum( id_cost ) as numeric) as campaign_summary_daily_cost,
    
    -- dates
    campaign_summary_daily_date,

    -- timestamps
    max( _fivetran_synced ) as campaign_summary_daily_timestamp_replicated

  from shareasale_base_campaign_summary_daily
  group by all

),

total_metrics_by_campaign_day as (

  select

    coalesce(shareasale_ad_platform_daily_clicks_impressions_by_campaign_day.campaign_summary_daily_natural_key, total_transaction_metrics_by_campaign_day.campaign_summary_daily_natural_key) as campaign_summary_daily_natural_key,
    coalesce(shareasale_ad_platform_daily_clicks_impressions_by_campaign_day.campaign_summary_daily_campaign_natural_key, total_transaction_metrics_by_campaign_day.campaign_summary_daily_campaign_natural_key) as campaign_summary_daily_campaign_natural_key,
    coalesce(shareasale_ad_platform_daily_clicks_impressions_by_campaign_day.campaign_summary_daily_connector_source, total_transaction_metrics_by_campaign_day.campaign_summary_daily_connector_source) as campaign_summary_daily_connector_source,
    shareasale_ad_platform_daily_clicks_impressions_by_campaign_day.campaign_summary_daily_clicks,
    shareasale_ad_platform_daily_clicks_impressions_by_campaign_day.campaign_summary_daily_impressions,
    total_transaction_metrics_by_campaign_day.campaign_summary_daily_conversions,
    total_transaction_metrics_by_campaign_day.campaign_summary_daily_conversions_value,
    total_transaction_metrics_by_campaign_day.campaign_summary_daily_cost,
    coalesce(shareasale_ad_platform_daily_clicks_impressions_by_campaign_day.campaign_summary_daily_date, total_transaction_metrics_by_campaign_day.campaign_summary_daily_date) as campaign_summary_daily_date,
    coalesce(shareasale_ad_platform_daily_clicks_impressions_by_campaign_day.campaign_summary_daily_timestamp_replicated, total_transaction_metrics_by_campaign_day.campaign_summary_daily_timestamp_replicated) as campaign_summary_daily_timestamp_replicated,

  from shareasale_ad_platform_daily_clicks_impressions_by_campaign_day
  full outer join total_transaction_metrics_by_campaign_day
    on total_transaction_metrics_by_campaign_day.campaign_summary_daily_natural_key = shareasale_ad_platform_daily_clicks_impressions_by_campaign_day.campaign_summary_daily_natural_key

),

select_and_sort_columns as (

  select 

    -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,
    
    -- strings
    campaign_summary_daily_connector_source,

    -- numbers
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,

    -- timestamps 
    campaign_summary_daily_timestamp_replicated,

  from total_metrics_by_campaign_day

)

select * from select_and_sort_columns