--------------------------------------------------------------
------- non_event_tracker_events__criteo__conforming_view
--------------------------------------------------------------

with 

source_web_events as (

  select * from {{ gcp_project_id }}.{{ bigquery_dataset }}_pre_conforming.pc_dispatch__snowcatcloud_events

),

source_criteo as (

  select * from `fluevog-insighta.analytics_ftp.fluevog_criteo__event_logs_1__12__file_replication`

),

source_criteo_ad_set as (
  
  select * from `fluevog-insighta.criteo_ads.adset`

),

distinct_criteo_ad_groups as (

  select
    distinct 
    cast(SAFE_CAST(SAFE_CAST(id AS FLOAT64) AS INT64) as string) ad_group_natural_key,
    cast(SAFE_CAST(SAFE_CAST(campaign_id AS FLOAT64) AS INT64) as string) campaign_natural_key
  from source_criteo_ad_set

),

extract_location_from_nested_columns as (

  select source_web_events.*,
    lower( location.country.iso_code ) country_code,
    case 
      when(
        lower( location.country.iso_code ) = 'us'
      )
      then regexp_extract(location.postal.code, r'^\d{5}')
      else location.postal.code
      end as post_code_stg
  from source_web_events,
  UNNEST (contexts_com_dbip_location_1_0_0) AS location

),

standardize_location as (

  select *,
    last_value(post_code_stg ignore nulls) over (
      partition by event_id
      order by load_tstamp
      rows between unbounded preceding and unbounded following
    ) as postal_code
  from extract_location_from_nested_columns

),

extract_email_from_non_nested_columns as (

  select *,
    
    case
      when regexp_contains(
        unstruct_event_com_snowplowanalytics_snowplow_focus_form_1_0_0.value,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unstruct_event_com_snowplowanalytics_snowplow_focus_form_1_0_0.value
      end as web_event_email_address_focus_form,
    
    case
      when regexp_contains(
        unstruct_event_com_snowplowanalytics_snowplow_change_form_1_0_0.value,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unstruct_event_com_snowplowanalytics_snowplow_change_form_1_0_0.value
      end as web_event_email_address_change_form,

  from standardize_location

),

extract_email_address_from_nested_submit_form as (

  select distinct

    event_id,

    case
      when regexp_contains(
        unnested_elements.value,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_elements.value
      end as web_event_email_address_submit_form,

  from extract_email_from_non_nested_columns

    cross join unnest(
      extract_email_from_non_nested_columns.unstruct_event_com_snowplowanalytics_snowplow_submit_form_1_0_0.elements
      ) AS unnested_elements

  where true

    -- filter out nulls to avoid fan-out
    and case
      when regexp_contains(
        unnested_elements.value,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_elements.value
      end is not null

),

extract_cart_token_from_nested_columns as (

  SELECT distinct
    event_id,
    SPLIT(cart.token, '?key=')[OFFSET(0)] AS web_event_user_identifier_cart_token
  FROM 
    source_web_events,
    UNNEST(contexts_com_shopify_cart_1_0_0) AS cart

),

extract_email_address_from_nested_ecommerce_user as (

  select distinct

    event_id,

    case
      when regexp_contains(
        unnested_ecommerce_user.email,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_ecommerce_user.email
      end as web_event_email_address_ecommerce_user,

  from extract_email_from_non_nested_columns

    cross join unnest(
      extract_email_from_non_nested_columns.contexts_com_snowplowanalytics_snowplow_ecommerce_user_1_0_0
      ) AS unnested_ecommerce_user

  where true

    -- filter out nulls to avoid fan-out
    and case
      when regexp_contains(
        unnested_ecommerce_user.email,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_ecommerce_user.email
      end is not null

),

join_unnested_to_non_nested as (

  select

    extract_email_from_non_nested_columns.*,

    extract_email_address_from_nested_submit_form.web_event_email_address_submit_form,
    extract_email_address_from_nested_ecommerce_user.web_event_email_address_ecommerce_user,
    extract_cart_token_from_nested_columns.web_event_user_identifier_cart_token,

  from extract_email_from_non_nested_columns

    left join extract_email_address_from_nested_submit_form

      using (event_id)

    left join extract_email_address_from_nested_ecommerce_user

      using (event_id)
    
    left join extract_cart_token_from_nested_columns

      using (event_id)


),

conform_and_rename_and_order_columns as (

  select
    distinct
    `contexts_com_snowplowanalytics_snowplow_ecommerce_transaction_1_0_0`[SAFE_OFFSET(0)].transaction_id as transaction_id,

    lower(
      coalesce(
        web_event_email_address_focus_form,
        web_event_email_address_change_form,
        web_event_email_address_submit_form,
        web_event_email_address_ecommerce_user
      )
    ) as web_event_email_address,

    lower( cast( country_code as string ) ) as non_event_tracker_event_country_code,
    cast( user_ipaddress as string ) as non_event_tracker_event_ip_address,
    cast( postal_code as string ) as non_event_tracker_event_postal_code,

    -- timestamps
    cast( derived_tstamp as timestamp ) as web_event_timestamp,
    cast( load_tstamp as timestamp ) as web_event_timestamp_replicated,

  from join_unnested_to_non_nested
  group by all

),

deduplicate as (

  select * from conform_and_rename_and_order_columns
  qualify row_number() over (
          partition by transaction_id
          order by web_event_timestamp asc
          ) = 1

),

recast_criteo_source as (

  select
    cast(partnerid as string) partnerid,
    cast(transactionid as string) transactionid,
    TIMESTAMP_SECONDS(SAFE_CAST(SAFE_CAST(TRANSTS AS FLOAT64) AS INT64)) criteo_transaction_timestamp,
    SAFE_CAST(SAFE_CAST(clickts AS FLOAT64) AS INT64) as clickts,
    SAFE_CAST(SAFE_CAST(DISPLAYTS AS FLOAT64) AS INT64) as DISPLAYTS,
    SAFE_CAST(SAFE_CAST(CLICKCAMPAIGN AS FLOAT64) AS INT64) CLICKCAMPAIGN,
    SAFE_CAST(SAFE_CAST(DISPLAYCAMPAIGN AS FLOAT64) AS INT64) DISPLAYCAMPAIGN,
    cast(EVENTTYPE as string) EVENTTYPE,
  from source_criteo

),

join_email_to_criteo as (

  select
    recast_criteo_source.*,
    deduplicate.web_event_email_address,
    deduplicate.non_event_tracker_event_country_code,
    deduplicate.non_event_tracker_event_ip_address,
    deduplicate.non_event_tracker_event_postal_code
  from recast_criteo_source
  left join deduplicate
    on recast_criteo_source.transactionid = deduplicate.transaction_id

),

collapse_criteo_columns as (

  select
    partnerid,
    transactionid,
    criteo_transaction_timestamp,
    case 
      when eventtype = 'click' then TIMESTAMP_SECONDS(clickts)
      when eventtype = 'impression' then TIMESTAMP_SECONDS(displayts)
      else null 
    end as criteo_impression_timestamp,
    case 
      when eventtype = 'click' then clickcampaign
      when eventtype = 'impression' then displaycampaign
      else null 
    end as criteo_ad_group_id,
    eventtype as criteo_event_type,
    web_event_email_address,
    non_event_tracker_event_country_code,
    non_event_tracker_event_ip_address,
    non_event_tracker_event_postal_code

  from join_email_to_criteo

),

filter_nulls as (

  select
    distinct *
  from collapse_criteo_columns
  where criteo_impression_timestamp is not null
    and criteo_ad_group_id is not null
    and web_event_email_address is not null
    and criteo_impression_timestamp <= criteo_transaction_timestamp

), 

create_non_event_tracker_event_natural_key as (

  select *,
    cast(partnerid as string)
      || '_' || cast(transactionid as string)
      || '_' || cast(criteo_transaction_timestamp as string)
      || '_' || cast(criteo_impression_timestamp as string)
      || '_' || cast(criteo_ad_group_id as string)
      || '_' || cast(criteo_event_type as string)
      as non_event_tracker_event_natural_key
  from filter_nulls

),

transiton_to_campaign_id as (

  select
    create_non_event_tracker_event_natural_key.*,
    distinct_criteo_ad_groups.campaign_natural_key
  from create_non_event_tracker_event_natural_key
  inner join distinct_criteo_ad_groups 
    on cast(create_non_event_tracker_event_natural_key.criteo_ad_group_id as string) = cast(distinct_criteo_ad_groups.ad_group_natural_key as string)

),

rename_cast_and_order_columns as (

  select 

    -- natural keys
    cast( non_event_tracker_event_natural_key as string ) as non_event_tracker_event_natural_key,
    cast( cast(campaign_natural_key as numeric ) as string ) as non_event_tracker_event_campaign_natural_key,
    non_event_tracker_event_country_code,

    --strings
    cast( 'criteo' as string ) as non_event_tracker_event_connector_source,
    cast( web_event_email_address as string ) as non_event_tracker_event_email_address,
    cast( 'display' as string ) as non_event_tracker_event_medium_name,
    case 
      when criteo_event_type = 'impression' then 'display ad view' 
      when criteo_event_type = 'click' then 'display ad click' 
      else 'undefined' 
    end as non_event_tracker_event_name,

    non_event_tracker_event_ip_address,
    non_event_tracker_event_postal_code,

    -- numeric
    cast( null as numeric ) as non_event_tracker_event_cost,

    --datetime
    cast( criteo_impression_timestamp as timestamp ) as non_event_tracker_event_timestamp,
    cast( criteo_impression_timestamp as timestamp ) as non_event_tracker_event_timestamp_replicated,

  from transiton_to_campaign_id

)

select * from rename_cast_and_order_columns where true
