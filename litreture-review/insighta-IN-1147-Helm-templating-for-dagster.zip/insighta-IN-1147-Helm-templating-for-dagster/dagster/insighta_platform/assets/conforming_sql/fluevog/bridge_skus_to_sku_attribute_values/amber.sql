with 

raw_cad_orders_table as (

  select * from fluevog-insighta.analytics_ftp.fluevog_ftp_destination_tables__amberpos_transactions_canada_1__11__file_replication
   
),

raw_usd_orders_table as (

  select * from fluevog-insighta.analytics_ftp.fluevog_ftp_destination_tables__amberpos_transactions_united_states_1__10__file_replication
   
),

union_tables as (

  select
    Description,
    Departmentfullname,
    Productnumber,
    SKU,
  from raw_cad_orders_table a

  union all

  select
    Description,
    Departmentfullname,
    Productnumber,
    SKU,
  from raw_usd_orders_table a

),

rename_description_and_sku as (

  select
    
    distinct 
    TRIM(
      REGEXP_REPLACE(
        LOWER(Description),
        r'\s+((\d+-\d+|\d+)(\s+invoice)?|invoice)$',
        ''
      )
    ) sku_description,
    Productnumber,
    Departmentfullname,
    REGEXP_REPLACE(CAST(sku AS STRING), r'\.0$', '') as sku_id,

  from union_tables

),

select_distinct_sku_id_and_name as (

  select 
    distinct sku_id, -- Individual SKU
    Productnumber as sku_name,  -- Sku Name
    Departmentfullname as department,
    LOWER(REGEXP_REPLACE(sku_id, r'[^a-zA-Z0-9]', '')) sku_id_key,
    LOWER(REGEXP_REPLACE(sku_description, r'[^a-zA-Z0-9]', '')) sku_name_key,
    LOWER(REGEXP_REPLACE(Departmentfullname, r'[^a-zA-Z0-9]', '')) departmentfullname_key,
  from rename_description_and_sku

),

filter_out_postage_skus as (
  
  select 
    *
  from select_distinct_sku_id_and_name
  where true
    and sku_id is not null
    and sku_id <> ""
    and lower(sku_id) not in ('783','784','798','800','misc')
    and sku_name_key is not null
    and sku_name_key <> ""
    and sku_name_key not like ('%postage%')
    and sku_name_key not like ('%shoppingbag%')

),

sku_id_cast_and_rename as (

  select 
    distinct
    cast( sku_id as string ) 
      || '_' || cast( 1 as string ) 
      || '_' || sku_id_key 
      as bridge_natural_key,
    cast( sku_id as string ) as sku_natural_key,
    cast( 1 as string ) 
      || '_' || sku_id_key
      as sku_attribute_value_natural_key,
  from filter_out_postage_skus

),

sku_name_cast_and_rename as (

  select 
    distinct
    cast( sku_id as string ) 
      || '_' || cast( 2 as string ) 
      || '_' || sku_name_key 
      as bridge_natural_key,
    cast( sku_id as string ) as sku_natural_key,
    cast( 2 as string ) 
      || '_' || sku_name_key 
      as sku_attribute_value_natural_key,
  from filter_out_postage_skus

),

department_name_cast_and_rename as (

  select 
    distinct
    cast( sku_id as string ) 
      || '_' || cast( 2 as string ) 
      || '_' || departmentfullname_key 
      as bridge_natural_key,
    cast( sku_id as string ) as sku_natural_key,
    cast( 3 as string ) 
      || '_' || departmentfullname_key 
      as sku_attribute_value_natural_key,
  from filter_out_postage_skus

),

family_name_cast_and_rename as (

  select 
    distinct
    cast( sku_id as string ) 
      || '_' || cast( 4 as string ) 
      || '_' || sku_name_key 
      as bridge_natural_key,
    cast( sku_id as string ) as sku_natural_key,
    cast( 4 as string ) 
      || '_' || sku_name_key 
      as sku_attribute_value_natural_key,
  from filter_out_postage_skus

),

union_cast_and_rename as (

  select * from sku_id_cast_and_rename

  union all

  select * from sku_name_cast_and_rename

  union all

  select * from department_name_cast_and_rename

  union all
  
  select * from family_name_cast_and_rename

)

select * from union_cast_and_rename