select 
  cast( 1 as string ) as sku_attribute_group_natural_key,
  cast( 'SKU Number' as string ) as sku_attribute_group_name, 

union all

select 
  cast( 2 as string ) as sku_attribute_group_natural_key,
  cast( 'SKU Name' as string ) as sku_attribute_group_name, 

union all

select 
  cast( 3 as string ) as sku_attribute_group_natural_key,
  cast( 'Department' as string ) as sku_attribute_group_name, 

union all

select 
  cast( 4 as string ) as sku_attribute_group_natural_key,
  cast( 'Family' as string ) as sku_attribute_group_name, 
