with

source_adset as (

  select * from fluevog-insighta.criteo_ads.adset

),

source_campaign_summary_daily as (

  select * from fluevog-insighta.criteo_ads.adset_statistics_report

),

source_currency_exchange as (

  select * from insighta-021324.currency_exchange.rate

),

cast_and_filter_currency_exchange as (

  select

    cast(data_timestamps as date) as join_day,
    rate as canadian_exchange_rate

  from source_currency_exchange
  where currency_code = 'CAD'

),

join_campaign_id_onto_adset_statistics as (

  select
    source_campaign_summary_daily.*,
    source_adset.campaign_id
  from source_campaign_summary_daily
  left outer join source_adset on source_campaign_summary_daily.adset_id = source_adset.id

),

join_currency as (

  select * from join_campaign_id_onto_adset_statistics
  left join cast_and_filter_currency_exchange
  on join_campaign_id_onto_adset_statistics.day = cast_and_filter_currency_exchange.join_day

),

convert_currency_from_USD_to_CAD as (

  select 

    revenue_generated_all_client_attribution * canadian_exchange_rate as revenue_generated_all_client_attribution_cad,
    advertiser_cost * canadian_exchange_rate as advertiser_cost_cad,
    *,
   
  from join_currency

),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( _fivetran_id as string ) as campaign_summary_daily_natural_key,
    cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,

    -- strings
    cast ('criteo' as string) as campaign_summary_daily_connector_source,

    -- metrics
    cast( clicks  as numeric ) as campaign_summary_daily_clicks,
    cast( sales_all_client_attribution  as numeric ) as campaign_summary_daily_conversions,
    cast( revenue_generated_all_client_attribution  as numeric ) as campaign_summary_daily_conversions_value,
    cast( advertiser_cost  as numeric ) as campaign_summary_daily_cost,
    cast( displays  as numeric ) as campaign_summary_daily_impressions,

    -- dates
    cast( day  as date ) as campaign_summary_daily_date,
    cast( _fivetran_synced  as timestamp ) as campaign_summary_daily_timestamp_replicated,

  from convert_currency_from_USD_to_CAD

)
select * from rename_cast_and_order_columns