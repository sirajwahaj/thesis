--Conforming SQL for Awin Non-Event Tracker Events
with

awin_info as (

  select * from fluevog-insighta.awin.transaction 
  qualify row_number() over (partition by id order by _fivetran_synced desc) = 1

),

source_web_events as (

  select * from {{ gcp_project_id }}.{{ bigquery_dataset }}_pre_conforming.pc_dispatch__snowcatcloud_events

),

extract_location_from_nested_columns as (

  select source_web_events.*,
    lower( location.country.iso_code ) country_code,
    case 
      when(
        lower( location.country.iso_code ) = 'us'
      )
      then regexp_extract(location.postal.code, r'^\d{5}')
      else location.postal.code
      end as post_code_stg
  from source_web_events,
  UNNEST (contexts_com_dbip_location_1_0_0) AS location

),

standardize_location as (

  select *,
    last_value(post_code_stg ignore nulls) over (
      partition by event_id
      order by load_tstamp
      rows between unbounded preceding and unbounded following
    ) as postal_code
  from extract_location_from_nested_columns

),

extract_email_address_from_nested_ecommerce_user as (

  select distinct

    event_id,

    case
      when regexp_contains(
        unnested_ecommerce_user.email,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_ecommerce_user.email
      end as web_event_email_address_ecommerce_user,

    country_code,
    user_ipaddress,
    postal_code
  from standardize_location

    cross join unnest(
      standardize_location.contexts_com_snowplowanalytics_snowplow_ecommerce_user_1_0_0
      ) AS unnested_ecommerce_user

  where true

    -- filter out nulls to avoid fan-out
    and case
      when regexp_contains(
        unnested_ecommerce_user.email,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_ecommerce_user.email
      end is not null

),

get_trans_id as (

  select 
    transactions.transaction_id as trans_id,
    event_id,
    network_userid,
    domain_userid,
  from source_web_events,
  UNNEST(contexts_com_snowplowanalytics_snowplow_ecommerce_transaction_1_0_0) AS transactions
  where event_name = 'snowplow_ecommerce_action'

),

join_email_to_trans_id as (

  select
    *
  from get_trans_id
  left join extract_email_address_from_nested_ecommerce_user
    on get_trans_id.event_id = extract_email_address_from_nested_ecommerce_user.event_id


),

distinct_lower_email as (

  select 
    distinct 
    trans_id,
    network_userid,
    domain_userid,
    lower(web_event_email_address_ecommerce_user) as web_event_email_address_ecommerce_user,
    country_code,
    user_ipaddress,
    postal_code
  from join_email_to_trans_id

),

rename_cast_and_order_columns as (

  select 

    -- natural keys
    cast (awin_info.id as string ) as non_event_tracker_event_natural_key,
    cast (awin_info.publisher_id as string ) as non_event_tracker_event_campaign_natural_key,
    lower( cast( country_code as string ) ) as non_event_tracker_event_country_code,

    --strings
    cast( 'awin' as string ) as non_event_tracker_event_connector_source,
    cast( distinct_lower_email.web_event_email_address_ecommerce_user as string ) as non_event_tracker_event_email_address,
    cast( 'affiliate' as string ) as non_event_tracker_event_medium_name,
    cast( 'affiliate link click' as string ) as non_event_tracker_event_name,
    cast( user_ipaddress as string ) as non_event_tracker_event_ip_address,
    cast( postal_code as string ) as non_event_tracker_event_postal_code,

    -- numbers
    cast( awin_info.commission_amount as numeric ) as non_event_tracker_event_cost,

    --datetime
    cast( awin_info.click_date as timestamp ) as non_event_tracker_event_timestamp,
    cast( awin_info._fivetran_synced as timestamp ) as non_event_tracker_event_timestamp_replicated,

  from awin_info

    left join distinct_lower_email 

      on cast(awin_info.order_ref as string) =  cast(distinct_lower_email.trans_id as string)

)

select * from rename_cast_and_order_columns
