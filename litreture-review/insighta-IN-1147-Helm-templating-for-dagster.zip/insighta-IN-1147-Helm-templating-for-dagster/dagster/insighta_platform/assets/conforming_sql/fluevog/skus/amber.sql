with 

raw_cad_orders_table as (

  select * from fluevog-insighta.analytics_ftp.fluevog_ftp_destination_tables__amberpos_transactions_canada_1__11__file_replication
   
),

raw_usd_orders_table as (

  select * from fluevog-insighta.analytics_ftp.fluevog_ftp_destination_tables__amberpos_transactions_united_states_1__10__file_replication
   
),

union_tables as (

  select
    Description,
    Productnumber,
    SKU,
    _INSIGHTA_REPLICATION_TIMESTAMP,
  from raw_cad_orders_table a

  union all

  select
    Description,
    Productnumber,
    SKU,
    _INSIGHTA_REPLICATION_TIMESTAMP,
  from raw_usd_orders_table a

),

rename_description_and_sku as (

  select
    
    distinct 
    TRIM(
      REGEXP_REPLACE(
        LOWER(Description),
        r'\s+((\d+-\d+|\d+)(\s+invoice)?|invoice)$',
        ''
      )
    ) sku_description,
    Productnumber,
    REGEXP_REPLACE(CAST(sku AS STRING), r'\.0$', '') as sku_id,
    _INSIGHTA_REPLICATION_TIMESTAMP,
  from union_tables

),

select_distinct_sku_id_and_name as (

  select 
    distinct sku_id, -- Individual SKU
    Productnumber as sku_name, -- Sku Name
    LOWER(REGEXP_REPLACE(sku_id, r'[^a-zA-Z0-9]', '')) sku_id_key,
    LOWER(REGEXP_REPLACE(sku_description, r'[^a-zA-Z0-9]', '')) sku_name_key,
    _INSIGHTA_REPLICATION_TIMESTAMP,
  from rename_description_and_sku

),

filter_out_postage_skus as (
  
  select 
    *
  from select_distinct_sku_id_and_name
  where true
    and sku_id is not null
    and sku_id <> ""
    and lower(sku_id) not in ('783','784','798','800','misc')
    and sku_name_key is not null
    and sku_name_key <> ""
    and sku_name_key not like ('%postage%')
    and sku_name_key not like ('%shoppingbag%')

),

select_distinct as (

  select 
    sku_id,
    max( _INSIGHTA_REPLICATION_TIMESTAMP ) as _INSIGHTA_REPLICATION_TIMESTAMP
  from filter_out_postage_skus
  group by all

),

cast_and_rename as (
  
  select

    -- natural keys
    cast( sku_id as string ) as sku_natural_key,

    -- timestamps
    cast( _INSIGHTA_REPLICATION_TIMESTAMP as timestamp ) as _timestamp_replicated,

  from select_distinct

)

select * from cast_and_rename