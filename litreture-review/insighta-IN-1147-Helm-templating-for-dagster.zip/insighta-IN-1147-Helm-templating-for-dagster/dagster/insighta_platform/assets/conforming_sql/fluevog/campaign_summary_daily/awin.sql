with

source_campaign_summary_daily as (
  select * 
  from fluevog-insighta.awin.transaction
),

source_currency_exchange as (
  select *
  from insighta-021324.currency_exchange.rate
),

filter_out_null_transaction_dates as (
  select *
  from source_campaign_summary_daily
  where sale_amount is not null
),

cast_and_filter_currency_exchange as (
  select
    cast(data_timestamps as date) as join_day,
    safe_cast(rate as float64) as cad_exchange_rate,
    _fivetran_synced
  from source_currency_exchange
  where currency_code = 'CAD'
  qualify row_number() over (
    partition by cast(data_timestamps as date)
    order by _fivetran_synced desc
  ) = 1
),

convert_currencies_and_dates as (
  select
    f.*,
    c.cad_exchange_rate,
    commission_amount * cad_exchange_rate as commission_amount_cad,
    sale_amount * cad_exchange_rate as sale_amount_cad,
    date(f.click_date) as click_date_utc
  from filter_out_null_transaction_dates f
  left join cast_and_filter_currency_exchange c
    on date(f.click_date) = c.join_day

),

awin_base_campaign_summary_daily as (

   select 
      cast(id as string) as non_event_tracker_event_natural_key,
      cast(
         concat(
               cast(publisher_id as string), 
               '-', 
               cast(click_date_utc as string)
         ) as string
      ) as campaign_summary_daily_natural_key,
   from convert_currencies_and_dates

),

total_metrics_by_campaign_day as (

  select 

    -- natural keys
    cast( CONCAT(CAST(publisher_id as string), '-', date(click_date_utc)) as string) as campaign_summary_daily_natural_key,
    cast( publisher_id as string ) as campaign_summary_daily_campaign_natural_key,

    -- strings
    cast( 'awin' as string ) as campaign_summary_daily_connector_source,


    -- numbers
    cast( count(distinct id) as numeric ) as campaign_summary_daily_clicks,
    cast( count(distinct order_ref) as numeric ) as campaign_summary_daily_conversions,
    cast( sum( sale_amount_cad ) as numeric ) as campaign_summary_daily_conversions_value,
    cast( sum( commission_amount_cad ) as numeric ) as campaign_summary_daily_cost,
    cast( null as numeric ) as campaign_summary_daily_impressions,

    -- dates
    click_date_utc as campaign_summary_daily_date,

    -- timestamps
    max(cast( _fivetran_synced as timestamp )) as campaign_summary_daily_timestamp_replicated
  from convert_currencies_and_dates
  group by all

),

select_and_sort_columns as (

  select 

    -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,

    -- strings
    campaign_summary_daily_connector_source,

    -- numbers
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,

    -- timestamps 
    campaign_summary_daily_timestamp_replicated,

  from total_metrics_by_campaign_day

)

select * from select_and_sort_columns