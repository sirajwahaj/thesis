with

source_campaigns as (

  select * from fluevog-insighta.awin.transaction

),

convert_iso_date_to_utc as (

   select *,

      timestamp(click_date) as click_date_utc

   from source_campaigns

),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( publisher_id as string ) as campaign_natural_key,

    -- strings
    cast( 'awin' as string ) as campaign_connector_source,
    cast( 'affiliate' as string ) as campaign_medium_name,
    cast( site_name as string ) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- dates
    cast( click_date_utc as timestamp ) as campaign_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as campaign_timestamp_replicated,

  from convert_iso_date_to_utc

)

select * from rename_cast_and_order_columns