with 

source_web_events as (

  select * from {{ gcp_project_id }}.{{ bigquery_dataset }}_pre_conforming.pc_dispatch__snowcatcloud_events

),

extract_location_from_nested_columns as (

  select source_web_events.*,
    lower( location.country.iso_code ) country_code,
    case 
      when(
        lower( location.country.iso_code ) = 'us'
      )
      then regexp_extract(location.postal.code, r'^\d{5}')
      else location.postal.code
      end as post_code_stg
  from source_web_events,
  UNNEST (contexts_com_dbip_location_1_0_0) AS location

),

standardize_location as (

  select *,
    last_value(post_code_stg ignore nulls) over (
      partition by event_id
      order by load_tstamp
      rows between unbounded preceding and unbounded following
    ) as postal_code
  from extract_location_from_nested_columns

),

extract_email_from_non_nested_columns as (

  select *,
    
    case
      when regexp_contains(
        unstruct_event_com_snowplowanalytics_snowplow_focus_form_1_0_0.value,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unstruct_event_com_snowplowanalytics_snowplow_focus_form_1_0_0.value
      end as web_event_email_address_focus_form,
    
    case
      when regexp_contains(
        unstruct_event_com_snowplowanalytics_snowplow_change_form_1_0_0.value,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unstruct_event_com_snowplowanalytics_snowplow_change_form_1_0_0.value
      end as web_event_email_address_change_form,

  from standardize_location

),

extract_email_address_from_nested_submit_form as (

  select distinct

    event_id,

    case
      when regexp_contains(
        unnested_elements.value,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_elements.value
      end as web_event_email_address_submit_form,

  from extract_email_from_non_nested_columns

    cross join unnest(
      extract_email_from_non_nested_columns.unstruct_event_com_snowplowanalytics_snowplow_submit_form_1_0_0.elements
      ) AS unnested_elements

  where true

    -- filter out nulls to avoid fan-out
    and case
      when regexp_contains(
        unnested_elements.value,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_elements.value
      end is not null

),

extract_cart_token_from_nested_columns as (

  SELECT distinct
    event_id,

     SPLIT(cart.token, '?key=')[OFFSET(0)] AS web_event_user_identifier_cart_token

  FROM 
    source_web_events,
    UNNEST(contexts_com_shopify_cart_1_0_0) AS cart

),

extract_email_address_from_nested_ecommerce_user as (

  select distinct

    event_id,

    case
      when regexp_contains(
        unnested_ecommerce_user.email,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_ecommerce_user.email
      end as web_event_email_address_ecommerce_user,

  from extract_email_from_non_nested_columns

    cross join unnest(
      extract_email_from_non_nested_columns.contexts_com_snowplowanalytics_snowplow_ecommerce_user_1_0_0
      ) AS unnested_ecommerce_user

  where true

    -- filter out nulls to avoid fan-out
    and case
      when regexp_contains(
        unnested_ecommerce_user.email,
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        )
      then unnested_ecommerce_user.email
      end is not null

),

join_unnested_to_non_nested as (

  select

    extract_email_from_non_nested_columns.*,

    extract_email_address_from_nested_submit_form.web_event_email_address_submit_form,
    extract_email_address_from_nested_ecommerce_user.web_event_email_address_ecommerce_user,
    extract_cart_token_from_nested_columns.web_event_user_identifier_cart_token,

  from extract_email_from_non_nested_columns

    left join extract_email_address_from_nested_submit_form

      using (event_id)

    left join extract_email_address_from_nested_ecommerce_user

      using (event_id)
    
    left join extract_cart_token_from_nested_columns

      using (event_id)


),

conform_and_rename_and_order_columns as (

  select

    -- natural keys
    cast( event_id as string ) as web_event_natural_key,
    cast( null as string ) web_event_tracker_instance_natural_key,

    -- strings - identity resolution
    cast( user_id as string ) as web_event_user_identifier_application,
    cast( web_event_user_identifier_cart_token as string ) as web_event_user_identifier_cart_token,
    cast( null as string ) as web_event_user_identifier_fingerprint,
    cast( network_userid as string ) as web_event_user_identifier_server_side_cookie,
    cast( domain_userid as string ) as web_event_user_identifier_client_side_cookie,
    coalesce(
      web_event_email_address_focus_form,
      web_event_email_address_change_form,
      web_event_email_address_submit_form,
      web_event_email_address_ecommerce_user
    ) as web_event_email_address,

    -- strings - marketing attribution
    cast( mkt_campaign as string ) as web_event_marketing_utm_campaign_natural_key,
    cast( mkt_content as string ) as web_event_marketing_utm_ad_group_natural_key,
    cast( mkt_medium as string ) as web_event_marketing_utm_medium_name,
    cast( mkt_source as string ) as web_event_marketing_utm_source_name,
    cast( mkt_term as string ) as web_event_marketing_utm_ad_natural_key,
    cast( 'regional' as string ) as web_event_mmm_geo_grain,
    cast( page_url as string ) as web_event_page_url,
    cast( country_code as string ) as web_event_country_code,
    cast( user_ipaddress as string ) as web_event_ip_address,
    cast( postal_code as string ) as web_event_postal_code,


    -- strings - other
    cast( 'snowplow' as string ) as web_event_connector_source,
    cast( event_name as string ) as web_event_name,
    cast( null as string ) as web_event_natural_key_customer_facing,
    cast( null as string ) as web_event_tracker_type,

    -- timestamps
    cast( derived_tstamp as timestamp ) as web_event_timestamp,
    cast( load_tstamp as timestamp ) as web_event_timestamp_replicated,

  from join_unnested_to_non_nested

)

select * from conform_and_rename_and_order_columns where true
