with

source_campaign_summary_daily as (

  select * from americanflags-416504.microsoft_ads.campaign_performance_daily_report
  where account_id = 1730198

),

create_compound_key as (

  select *,

    account_id
      || '-' || campaign_id
      || '-' || date
      || '-' || currency_code
      || '-' || ad_distribution
      || '-' || device_type
      || '-' || network
      || '-' || delivered_match_type
      || '-' || device_os
      || '-' || top_vs_other
      || '-' || bid_match_type
      as compound_key

  from source_campaign_summary_daily

),

rename_and_order_columns as (

  select

    -- natural keys
    cast( compound_key as string ) as campaign_summary_daily_natural_key,
    cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,

    -- strings
    cast( 'bing' as string ) as campaign_summary_daily_connector_source,

    -- numbers
    cast( clicks as numeric ) as campaign_summary_daily_clicks,
    cast( conversions as numeric ) as campaign_summary_daily_conversions,
    cast( revenue as numeric ) as campaign_summary_daily_conversions_value,
    cast( spend as numeric ) as campaign_summary_daily_cost,
    cast( impressions as numeric ) as campaign_summary_daily_impressions,

    -- dates
    cast( date as date ) as campaign_summary_daily_date,
    cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated,
  
  from create_compound_key

)

select * from rename_and_order_columns