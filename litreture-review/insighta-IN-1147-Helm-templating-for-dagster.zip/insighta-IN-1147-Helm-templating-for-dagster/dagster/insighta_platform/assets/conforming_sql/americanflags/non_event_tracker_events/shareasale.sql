with 

source_shareasale_conversions as (

  select * from americanflags-416504.shareasale.transaction

),

source_web_events as (

  select * from {{ gcp_project_id }}.{{ bigquery_dataset }}_pre_conforming.pc_dispatch__snowcatcloud_events

),

filter_out_no_clicks as (

  select * from source_shareasale_conversions
  where date_of_click is not null 

),

web_events_filter_to_org as (

  select * from source_web_events
  where app_id = 'americanflags'

),

extract_location_from_nested_columns as (

  select web_events_filter_to_org.*,
    lower( location.country.iso_code ) country_code,
    case 
      when(
        lower( location.country.iso_code ) = 'us'
      )
      then regexp_extract(location.postal.code, r'^\d{5}')
      else location.postal.code
      end as post_code_stg
  from web_events_filter_to_org,
  UNNEST (contexts_com_dbip_location_1_0_0) AS location

),

standardize_location as (

  select *,
    last_value(post_code_stg ignore nulls) over (
      partition by event_id
      order by load_tstamp
      rows between unbounded preceding and unbounded following
    ) as postal_code
  from extract_location_from_nested_columns

),

select_web_events as (

  select 
    contexts_com_snowplowanalytics_snowplow_ecommerce_user_1_0_0[SAFE_OFFSET(0)].email,
    * 
  from standardize_location
  where tr_orderid is not null

),

join_web_events_and_select as (

  select 
    cast(filter_out_no_clicks.id as string) as non_event_tracker_event_natural_key,
    'campaign shareasale' as non_event_tracker_event_campaign_natural_key,
    cast( country_code as string ) as non_event_tracker_event_country_code,
    'shareasale' as non_event_tracker_event_connector_source,
    lower(cast(select_web_events.email as string) ) as non_event_tracker_event_email_address,
    'affiliate' as non_event_tracker_event_medium_name,
    'affilite link clicked' as non_event_tracker_event_name, 
    cast( user_ipaddress as string ) as non_event_tracker_event_ip_address,
    cast( postal_code as string ) as non_event_tracker_event_postal_code,
    cast( filter_out_no_clicks.commission as numeric ) as non_event_tracker_event_cost,
    timestamp(date_of_click) as non_event_tracker_event_timestamp,
    timestamp(_fivetran_synced) as non_event_tracker_event_timestamp_replicated

  from filter_out_no_clicks
  left join select_web_events
  on filter_out_no_clicks.order_number = select_web_events.tr_orderid

)

select *
from join_web_events_and_select


/*
--current
--nonevents conforming shareasale -data is null need to keep workoing

with 

source_shareasale_conversions as (

  select * from americanflags-416504.shareasale.transaction

),

netsuite_transactions AS (

  select * from carrottop-416504.netsuite.transaction

),

filter_out_no_clicks as (

  select * from source_shareasale_conversions
  where date_of_click is not null 

),

cast_and_rename_netsuite_transactions as (

  select 
    distinct 
    -- cast(id as numeric) as transaction_natural_key,
    -- cast(tranid as string) as order_natural_key,
    cast(custbody_m2_order_number as string) as join_order_natural_key,
    cast(email as string) as order_email_address,
    cast(cseg_brand as numeric) as organization_natural_key,
    cast(createddate as timestamp) as order_timestamp,
    -- cast(_fivetran_synced as timestamp) as order_timestamp_replicated,
  from netsuite_transactions
  where cast(email as string) is not null

),

filter_to_americanflags_orders as (

  select 
    *,
  from cast_and_rename_netsuite_transactions
  where 1 = 1
    and organization_natural_key = 1

),

deduplicate_to_first_transaction as (

  select 
    *,
  from filter_to_americanflags_orders
  -- where order_email_address is not null
  qualify row_number() over(partition by join_order_natural_key order by order_timestamp asc) = 1 

),


join_transaction_events_and_select as (

  select 
    cast(filter_out_no_clicks.id as string) as non_event_tracker_event_natural_key,
    'campaign shareasale' as non_event_tracker_event_campaign_natural_key,
    'shareasale' as non_event_tracker_event_connector_source,
    lower(cast(deduplicate_to_first_transaction.order_email_address as string) ) as non_event_tracker_event_email_address,
    'affiliate' as non_event_tracker_event_medium_name,
    'affilite link clicked' as non_event_tracker_event_name,
    timestamp(date_of_click) as non_event_tracker_event_timestamp,
    timestamp(_fivetran_synced) as non_event_tracker_event_timestamp_replicated

  from filter_out_no_clicks
  left outer join deduplicate_to_first_transaction
  on filter_out_no_clicks.order_number = deduplicate_to_first_transaction.join_order_natural_key

)

select * from join_transaction_events_and_select

-- */
-- select sum(order_amount_total) from join_orders_and_identifiers_and_select_relevant_fields
-- WHERE DATE(order_timestamp) BETWEEN DATE_TRUNC(DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH), MONTH)
--                                 AND DATE_SUB(DATE_TRUNC(CURRENT_DATE(), MONTH), INTERVAL 1 DAY);
