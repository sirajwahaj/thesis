with 

ad_group_source as (

  select * from americanflags-416504.microsoft_ads.ad_group_history

),

source_cti_campaigns as (

  select distinct id from americanflags-416504.microsoft_ads.campaign_history
  where account_id = 1730198

),

filter_to_cti_ads_groups as (

  select ags.*
  from ad_group_source ags
  inner join source_cti_campaigns scti
    on ags.campaign_id = scti.id

),

create_history_key as (

  select

    *,
    concat(id, campaign_id) as history_key

  from filter_to_cti_ads_groups

),

cast_rename_and_order as (

  select 
  
    cast( history_key as string ) as history_key,
    cast( id as string ) as ad_group_natural_key,
    cast( campaign_id as string ) as campaign_natural_key,
    cast( null as timestamp ) as validity_timestamp_start,
    cast( null as timestamp ) as validity_timestamp_end,

  from create_history_key 

)

select * from cast_rename_and_order