with 

source_campaigns as (

  select * from americanflags-416504.shareasale.weekly_progress
  
),

rename_cast_and_order_columns as (

  select distinct
    
    -- natural keys
    cast('campaign shareasale' as string) as campaign_natural_key,

    -- strings
    cast( 'shareasale' as string ) as campaign_connector_source,
    cast( 'affiliate' as string ) as campaign_medium_name,
    cast( 'campaign shareasale' as string ) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    --timestamps
    max(parse_timestamp('%m/%d/%Y', date)) as campaign_timestamp_updated,
    max(cast(_fivetran_synced as timestamp)) as campaign_timestamp_replicated,
    
  from source_campaigns
  group by all

)

select * from rename_cast_and_order_columns