with

create_static_optiversal_campaigns as (

  select

    -- natural keys
    cast( 'optiversal' as string ) as campaign_natural_key,

    -- strings
    cast( 'optiversal' as string ) as campaign_connector_source,
    cast( 'seo' as string ) as campaign_medium_name,
    cast( 'campaign_optiversal' as string ) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,
    
    -- dates
    cast( null as timestamp ) as campaign_timestamp_updated,
    cast( null as timestamp ) as campaign_timestamp_replicated,

)

select * from create_static_optiversal_campaigns