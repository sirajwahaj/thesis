with 

campaign_summary_base AS (
  -- Generate one row per day from June 1, 2024 to yesterday
  SELECT
    campaign_summary_daily_date
  FROM UNNEST(GENERATE_DATE_ARRAY(DATE '2024-06-01', DATE_SUB(CURRENT_DATE(), INTERVAL 1 DAY))) AS campaign_summary_daily_date
),

source_web_events as (

  select * from {{ gcp_project_id }}.{{ bigquery_dataset }}_pre_conforming.pc_dispatch__snowcatcloud_events

),

filter_to_optiversal_clicks as (

  select * from source_web_events
  where app_id = 'americanflags'
  and page_url like '%/buy/%'

),

aggregate_web_events_clicks_by_day as (

  select
    cast( derived_tstamp as date ) as campaign_summary_daily_date,
    count( * ) campaign_summary_daily_clicks 
  from filter_to_optiversal_clicks
  group by cast( derived_tstamp as date ) 

),

daily_spend AS (
  -- Add the number of days in each month
  SELECT
    campaign_summary_daily_date,
    EXTRACT(YEAR FROM campaign_summary_daily_date) AS year,
    EXTRACT(MONTH FROM campaign_summary_daily_date) AS month,
    DATE_DIFF(
      DATE_TRUNC(campaign_summary_daily_date, MONTH) + INTERVAL 1 MONTH,
      DATE_TRUNC(campaign_summary_daily_date, MONTH),
      DAY
    ) AS days_in_month
  FROM campaign_summary_base

),

distribute_spend_across_days as (

  SELECT
    campaign_summary_daily_date,
    CASE
      WHEN campaign_summary_daily_date < DATE '2025-05-01' THEN 1750.0 / days_in_month
      ELSE 1000.0 / days_in_month
    END AS campaign_summary_daily_cost
  FROM daily_spend

),

join_clicks_onto_spend as (

  select 
    distribute_spend_across_days.campaign_summary_daily_date,
    campaign_summary_daily_cost,
    campaign_summary_daily_clicks,
  from distribute_spend_across_days
  left join aggregate_web_events_clicks_by_day
  on distribute_spend_across_days.campaign_summary_daily_date = aggregate_web_events_clicks_by_day.campaign_summary_daily_date

),

order_rename_cast as (

  select

    --natural keys
    cast( campaign_summary_daily_date as string ) as campaign_summary_daily_natural_key,
    cast( 'campaign_optiversal' as string ) as campaign_summary_daily_campaign_natural_key,

    --strings
    cast( 'optiversal' as string ) as campaign_summary_daily_connector_source,

    --numbers
    cast( campaign_summary_daily_clicks as numeric ) as campaign_summary_daily_clicks,
    cast( null as numeric ) as campaign_summary_daily_conversions,
    cast( null as numeric ) as campaign_summary_daily_conversions_value,
    cast( campaign_summary_daily_cost as numeric ) as campaign_summary_daily_cost,
    cast( null as numeric ) as campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,
    cast( null as timestamp ) as campaign_summary_daily_timestamp_replicated,

  from join_clicks_onto_spend

)

select * from order_rename_cast