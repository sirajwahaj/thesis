with netsuite_transactions AS (

  select *,
  from `carrottop-416504.netsuite.transaction`

),

netsuite_transactionaccountingline as (

  select * 
  from `carrottop-416504.netsuite.transactionaccountingline` 

),

snowplow_events as (
  
  select *
  from `{{ gcp_project_id }}.{{ bigquery_dataset }}_pre_conforming.pc_dispatch__snowcatcloud_events`

),
order_transactions as (

  select id, 
    custbody_m2_order_number,
    billingaddress,
    tranid,
    email,
    cseg_brand,
    createddate,
    _fivetran_synced,
  from netsuite_transactions
  where true

),

billinginfo as (
  
  select nkey,
  lower( country ) country,
  case 
    when( lower( country ) = 'us' )
      then regexp_extract(zip, r'^\d{5}')
      else zip
    end as zip,
  cast( null as string ) as ip_address
  from `carrottop-416504.netsuite.transactionbillingaddress`

),

standardize_location as (

  select nkey,
  country,
  case when (country = 'us') 
    then regexp_extract(zip, r'^\d{5}')
    else zip 
    end as postal_code,
  ip_address
  from billinginfo

),

join_billing_info_and_order_id as (

  select order_transactions.*,
    country country_stg,
    postal_code postal_code_stg,
    cast( null as string ) as ip_address
  from order_transactions
  left join standardize_location
  on order_transactions.billingaddress = standardize_location.nkey

),

replicating_geo_data as (

  select join_billing_info_and_order_id.*,
    last_value(country_stg ignore nulls) over (
      partition by id
      order by createddate
      rows between unbounded preceding and unbounded following
    ) as country_code,
    last_value(postal_code_stg ignore nulls) over (
      partition by id
      order by createddate
      rows between unbounded preceding and unbounded following
    ) as postal_code
  from join_billing_info_and_order_id

),

cast_and_rename_netsuite_transactions as (

  select 

    cast(id as numeric) as transaction_natural_key,
    cast(tranid as string) as order_natural_key,
    cast(custbody_m2_order_number as string) as join_order_natural_key,
    cast(email as string) as order_email_address,
    cast(cseg_brand as numeric) as organization_natural_key,
    cast(createddate as timestamp) as order_timestamp,
    cast(_fivetran_synced as timestamp) as order_timestamp_replicated,
    cast( country_code as string ) as country_code,
    cast( ip_address as string ) as ip_address,
    cast( postal_code as string ) as postal_code,

  from replicating_geo_data

),

cast_and_rename_netsuite_transactionaccountingline as (

  select 
    cast(transaction as numeric) as transaction_natural_key,
    cast(account as numeric) as general_ledger_account_number,
    cast(amount as numeric) as order_amount_total,

  from netsuite_transactionaccountingline

),

cast_and_rename_snowplow_events as (

  select 
    cast(app_id as string) as organization_identifier,
    cast(derived_tstamp as timestamp) as event_timestamp,
    cast(tr_orderid as string) as event_join_order_natural_key,
    cast(null as string) as event_user_identifier_application,
    cast(null as string) as event_user_identifier_fingerprint,
    cast(network_userid as string) as event_user_identifier_server_side_cookie,
    cast(domain_userid as string) as event_user_identifier_client_side_cookie,
    
  from snowplow_events

),

join_transactionaccountingline as (

  select 
    cast_and_rename_netsuite_transactions.*,
    cast_and_rename_netsuite_transactionaccountingline.general_ledger_account_number,
    cast_and_rename_netsuite_transactionaccountingline.order_amount_total,

  from cast_and_rename_netsuite_transactions
  left join cast_and_rename_netsuite_transactionaccountingline
    using (transaction_natural_key)

),

filter_to_gross_sales_accounting_line as (

  select 
    *,
  from join_transactionaccountingline
  where 1 = 1
    and general_ledger_account_number = 116
),

filter_to_americanflags_orders as (

  select 
    *,
  from filter_to_gross_sales_accounting_line
  where 1 = 1
    and organization_natural_key = 1
),

deduplicate_to_first_transaction as (

  select 
    *,
  from filter_to_americanflags_orders
  qualify row_number() over(partition by order_natural_key order by order_timestamp asc) = 1 

),

deduplicate_to_first_order_event as (

  select *
  from cast_and_rename_snowplow_events
  qualify row_number() over(partition by event_join_order_natural_key order by event_timestamp asc) = 1 

),

snowplow_events_filter as (
  
  select *
  from deduplicate_to_first_order_event
  where organization_identifier = 'americanflags'

),

join_orders_and_identifiers_and_select_relevant_fields as (

select 
  
  deduplicate_to_first_transaction.order_natural_key,
  snowplow_events_filter.event_user_identifier_application as order_user_identifier_application,
  cast( null as string ) as order_user_identifier_cart_token,
  snowplow_events_filter.event_user_identifier_fingerprint as order_user_identifier_fingerprint,  
  snowplow_events_filter.event_user_identifier_server_side_cookie as order_user_identifier_server_side_cookie,
  snowplow_events_filter.event_user_identifier_client_side_cookie as order_user_identifier_client_side_cookie,
  cast('web' as string) as order_channel,
  'netsuite' as order_connector_source,
  deduplicate_to_first_transaction.country_code as order_country_code,
  deduplicate_to_first_transaction.order_email_address,
  deduplicate_to_first_transaction.ip_address as order_ip_address,
  cast( 'regional' as string ) as order_mmm_geo_grain,
  deduplicate_to_first_transaction.order_natural_key as order_natural_key_customer_facing,
  deduplicate_to_first_transaction.postal_code as order_postal_code,
  cast('netsuite' as string) as order_sub_channel,
  cast('D2C' as string) as order_type,
  cast( true as boolean ) as is_directly_attributable,
  deduplicate_to_first_transaction.order_amount_total,
  deduplicate_to_first_transaction.order_timestamp,
  deduplicate_to_first_transaction.order_timestamp_replicated
from deduplicate_to_first_transaction
left join snowplow_events_filter  
  on snowplow_events_filter.event_join_order_natural_key = deduplicate_to_first_transaction.join_order_natural_key

)

select * from join_orders_and_identifiers_and_select_relevant_fields
