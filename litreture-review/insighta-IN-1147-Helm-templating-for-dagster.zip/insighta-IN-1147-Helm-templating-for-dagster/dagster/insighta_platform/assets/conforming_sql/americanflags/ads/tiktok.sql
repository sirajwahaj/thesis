with

source_ads as (

  select * from americanflags-416504.tiktok_ads.ad_history

),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( ad_id as string ) as ad_natural_key,

    -- strings
    cast( 'tiktok' as string ) as ad_connector_source,
    cast( 'social' as string ) as ad_medium_name,
    cast( ad_name as string ) as ad_name,
    cast( null as string ) as ad_text,
    cast( null as string ) as ad_url,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- dates
    cast( updated_at as timestamp ) as ad_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as ad_timestamp_replicated,
  
  from source_ads

)

select * from rename_cast_and_order_columns