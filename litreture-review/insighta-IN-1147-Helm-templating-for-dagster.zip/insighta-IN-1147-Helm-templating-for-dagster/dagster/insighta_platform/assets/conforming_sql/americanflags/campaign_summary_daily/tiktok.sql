with

source_campaign_summary_daily as (

   select * from americanflags-416504.tiktok_ads.campaign_report_daily

),

create_compound_key as (

   select *,

      campaign_id
         || '-' || stat_time_day
         as compound_key

   from source_campaign_summary_daily

),

rename_cast_and_order_columns as (

   select 

      --natural keys
      cast( compound_key as string ) as campaign_summary_daily_natural_key,
      cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,

      --strings
      cast( 'tiktok' as string ) as campaign_summary_daily_connector_source,

      --numbers
      cast( clicks as numeric ) as campaign_summary_daily_clicks,
      cast( complete_payment as numeric ) as campaign_summary_daily_conversions,
      cast( total_complete_payment_rate as numeric ) as campaign_summary_daily_conversions_value,
      cast( spend as numeric ) as campaign_summary_daily_cost,
      cast( impressions as numeric ) as campaign_summary_daily_impressions,
   
      --timestamps
      cast( stat_time_day as date ) as campaign_summary_daily_date,
      cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated

   from create_compound_key

)

select * from rename_cast_and_order_columns