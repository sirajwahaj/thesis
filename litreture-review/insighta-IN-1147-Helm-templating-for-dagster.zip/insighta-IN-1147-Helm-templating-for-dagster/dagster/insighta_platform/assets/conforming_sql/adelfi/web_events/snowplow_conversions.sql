with 

source_web_events as (

  select * from {{ gcp_project_id }}.{{ bigquery_dataset }}_pre_conforming.pc_dispatch__snowcatcloud_events

),

extract_location_from_nested_columns as (

  select source_web_events.*,
    lower( location.country.iso_code ) country_code,
    case 
      when(
        lower( location.country.iso_code ) = 'us'
      )
      then regexp_extract(location.postal.code, r'^\d{5}')
      else location.postal.code
      end as post_code_stg
  from source_web_events,
  UNNEST (contexts_com_dbip_location_1_0_0) AS location

),

standardize_location as (

  select *,
    last_value(post_code_stg ignore nulls) over (
      partition by event_id
      order by load_tstamp
      rows between unbounded preceding and unbounded following
    ) as postal_code
  from extract_location_from_nested_columns

),


focus_form_events as (

  select 
    distinct
    event_id,
    user_id,
    page_url,
    domain_sessionid,
    network_userid,
    domain_userid,
    unstruct_event_com_snowplowanalytics_snowplow_focus_form_1_0_0.form_id AS form_id,
    derived_tstamp,
    load_tstamp,
    country_code,
    user_ipaddress,
    postal_code,
    unstruct_event_com_snowplowanalytics_snowplow_focus_form_1_0_0.element_id AS element_id,
    unstruct_event_com_snowplowanalytics_snowplow_focus_form_1_0_0.element_type AS element_type,
    unstruct_event_com_snowplowanalytics_snowplow_focus_form_1_0_0.value AS value,
    CASE
      WHEN
        unstruct_event_com_snowplowanalytics_snowplow_focus_form_1_0_0.form_id IN (
          'mktoForm_1673',
          'popupForm',
          'Search',
          'link_ OpenanAccount JoinNow'
        )
        OR (
          page_url LIKE 'https://apply.adelfibanking.com/account-opening%'
          AND unstruct_event_com_snowplowanalytics_snowplow_focus_form_1_0_0.element_type = 'email'
          )
        THEN TRUE
      ELSE FALSE
    END AS is_target_conversion_event
  from standardize_location

),

change_form_events AS (

  select 
    distinct
    event_id,
    user_id,
    page_url,
    domain_sessionid,
    network_userid,
    domain_userid,
    derived_tstamp,
    load_tstamp,
    country_code,
    user_ipaddress,
    postal_code,
    unstruct_event_com_snowplowanalytics_snowplow_change_form_1_0_0.form_id as form_id,
    unstruct_event_com_snowplowanalytics_snowplow_change_form_1_0_0.type as type,
    unstruct_event_com_snowplowanalytics_snowplow_change_form_1_0_0.value as value,
    CASE
      WHEN
        unstruct_event_com_snowplowanalytics_snowplow_change_form_1_0_0.form_id IN (
          'mktoForm_1673',
          'popupForm',
          'Search',
          'link_ OpenanAccount JoinNow'
        )
        OR (
          page_url LIKE 'https://apply.adelfibanking.com/account-opening%'
          AND unstruct_event_com_snowplowanalytics_snowplow_change_form_1_0_0.type = 'email'
        )
      THEN TRUE
      ELSE FALSE
    END AS is_target_conversion_event
  from standardize_location
    
),

submit_cte AS (

  select distinct
    s.event_id,
    s.user_id,
    s.page_url,
    s.domain_sessionid,
    s.network_userid,
    s.domain_userid,
    s.derived_tstamp,
    s.load_tstamp,
    s.country_code,
    s.user_ipaddress,
    s.postal_code,
    u.form_id,
    e.type,
    e.value,
    case
      when 
        u.form_id IN (
          'mktoForm_1673',
          'popupForm',
          'Search',
          'link_ OpenanAccount JoinNow'
        )         
        OR (
          page_url LIKE 'https://apply.adelfibanking.com/account-opening%'
          AND e.type = 'email'
        )
      then true
      else false
    end as is_target_conversion_event
  from standardize_location s
  left join unnest([s.unstruct_event_com_snowplowanalytics_snowplow_submit_form_1_0_0]) u
  left join unnest(u.elements) e

),

email_cte_from_focus_form_events as (

  select
    distinct
    event_id,
    user_id,
    domain_sessionid,
    derived_tstamp,
    load_tstamp,
    country_code,
    user_ipaddress,
    postal_code,
    network_userid,
    domain_userid,
    lower(value) as email_value
  from focus_form_events
  where (lower(element_id) in ('email')
    or lower(element_type) in ('email'))
    AND value IS NOT NULL
    AND value != ''
    AND value LIKE '%@%'
    AND is_target_conversion_event is true

),

email_cte_from_change_form_events AS (

  SELECT 
    distinct
    event_id,
    user_id,
    domain_sessionid,
    derived_tstamp,
    load_tstamp,
    country_code,
    user_ipaddress,
    postal_code,
    network_userid,
    domain_userid,
    lower(value) AS email_value,
  FROM change_form_events
  WHERE lower(type) = 'email'
    AND value IS NOT NULL
    AND value != ''
    AND value LIKE '%@%'
    AND is_target_conversion_event is true

),

email_cte_from_submit_form_events as (

    SELECT 
    distinct
    event_id,
    user_id,
    domain_sessionid,
    derived_tstamp,
    load_tstamp,
    country_code,
    user_ipaddress,
    postal_code,
    network_userid,
    domain_userid,
    lower(value) AS email_value,
  FROM submit_cte
  WHERE lower(type) = 'email'
    AND value IS NOT NULL
    AND value != ''
    AND value LIKE '%@%'
    AND is_target_conversion_event is true

),

union_email_ctes as (

  select * from email_cte_from_focus_form_events
  union all
  select * from email_cte_from_change_form_events
  union all
  select * from email_cte_from_submit_form_events

),

find_latest_email_record as (

  select 
    *
  from union_email_ctes
  qualify ROW_NUMBER() OVER (PARTITION BY email_value, domain_sessionid ORDER BY derived_tstamp DESC) = 1

),

conform_and_rename_and_order_columns as (

  select

    -- natural keys
    cast( event_id as string ) as web_event_natural_key,
    cast( null as string ) web_event_tracker_instance_natural_key,

    -- strings - identity resolution
    cast( user_id as string ) as web_event_user_identifier_application,
    cast( null as string ) as web_event_user_identifier_cart_token,
    cast( null as string ) as web_event_user_identifier_fingerprint,
    cast( network_userid as string ) as web_event_user_identifier_server_side_cookie,
    cast( domain_userid as string ) as web_event_user_identifier_client_side_cookie,
    -- email_value as web_event_email_address,
    LOWER(TO_HEX(MD5(LOWER(TRIM(email_value))))) as web_event_email_address,

    -- strings - marketing attribution
    cast( null as string ) as web_event_marketing_utm_campaign_natural_key,
    cast( null as string ) as web_event_marketing_utm_ad_group_natural_key,
    cast( null as string ) as web_event_marketing_utm_medium_name,
    cast( null as string ) as web_event_marketing_utm_source_name,
    cast( null as string ) as web_event_marketing_utm_ad_natural_key,
    cast( 'regional' as string ) as web_event_mmm_geo_grain,
    cast( null as string ) as web_event_page_url,
    cast( country_code as string ) as web_event_country_code,
    cast( user_ipaddress as string ) as web_event_ip_address,
    cast( postal_code as string ) as web_event_postal_code,

    -- strings - other
    cast( 'snowplow' as string ) as web_event_connector_source,
    cast( 'form_submission' as string ) as web_event_name,
    cast( LOWER(TO_HEX(MD5(LOWER(TRIM(email_value))))) as string ) as web_event_natural_key_customer_facing,
    cast( null as string ) as web_event_tracker_type,

    -- timestamps
    cast( derived_tstamp as timestamp ) as web_event_timestamp,
    cast( load_tstamp as timestamp ) as web_event_timestamp_replicated,

  from find_latest_email_record

)

select * from conform_and_rename_and_order_columns order by web_event_timestamp desc