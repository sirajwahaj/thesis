
with

source_campaigns as (

  select * from adelfi-iprod.stackadapt_ads.campaign

),

filter_advertiser as (

  select * from source_campaigns
  where advertiser_id = 57150

),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( id as string ) as campaign_natural_key,

    -- strings
    cast( 'stackadapt' as string ) as campaign_connector_source,
    cast( 'display' as string ) as campaign_medium_name,
    cast( name as string ) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- dates
    cast( start_date as timestamp ) as campaign_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as campaign_timestamp_replicated,
  
  from filter_advertiser

)

select * from rename_cast_and_order_columns