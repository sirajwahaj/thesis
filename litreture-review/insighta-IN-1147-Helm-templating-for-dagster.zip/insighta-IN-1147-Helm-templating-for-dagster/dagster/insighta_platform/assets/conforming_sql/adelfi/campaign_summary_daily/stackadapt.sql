with

source_campaign_summary_daily as (

   select * from adelfi-iprod.stackadapt_ads.stats_delivery_campaign

),

filter_advertiser as (

   select *
   from source_campaign_summary_daily
   where advertiser_id = 57150

),

rename_and_cast as (

   select 

      --natural keys
      cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,

      --strings
      cast( 'stackadapt' as string ) as campaign_summary_daily_connector_source,

      --numbers
      cast( cost as numeric ) as campaign_summary_daily_cost,
      cast( click as numeric ) as campaign_summary_daily_clicks,
      cast( conv as numeric ) as campaign_summary_daily_conversions,
      cast( conv_rev as numeric ) as campaign_summary_daily_conversions_value,
      cast( imp as numeric ) as campaign_summary_daily_impressions,
   
      --timestamps
      cast( date as date ) as campaign_summary_daily_date,
      cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated

   from filter_advertiser

),

create_natural_key as (

   select *,
      campaign_summary_daily_campaign_natural_key
        || '_' || campaign_summary_daily_date
      as campaign_summary_daily_natural_key,

   from rename_and_cast

),

order_columns as (

   select

      -- natural keys
      campaign_summary_daily_natural_key,
      campaign_summary_daily_campaign_natural_key,

      -- strings
      campaign_summary_daily_connector_source,

      -- numbers
      campaign_summary_daily_clicks,
      campaign_summary_daily_conversions,
      campaign_summary_daily_conversions_value,
      campaign_summary_daily_cost,
      campaign_summary_daily_impressions,

      -- dates
      campaign_summary_daily_date,
      campaign_summary_daily_timestamp_replicated,

   from create_natural_key

)

select * from order_columns