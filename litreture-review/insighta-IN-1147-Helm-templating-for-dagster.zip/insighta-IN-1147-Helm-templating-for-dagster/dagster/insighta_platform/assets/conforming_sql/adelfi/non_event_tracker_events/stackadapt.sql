with

stackadapt_impression_source as (

  select * from adelfi-iprod.stackadapt.Adelfi_CJ_Data_Updated
  
),

source_orders as (

  select * from adelfi-iprod.analytics_conformed_sources.web_events__snowplow_conversions


),

filter_to_conversion_orders as (

  select distinct * from stackadapt_impression_source
  where CLIENT_DATA is not null

),

rename_cast_and_order_columns as (

  select 

    -- natural keys
    cast( filter_to_conversion_orders.imp_id as string ) as non_event_tracker_event_natural_key,
    cast( cast(filter_to_conversion_orders.campaign_id as numeric ) as string ) as non_event_tracker_event_campaign_natural_key,
    cast( null as string ) as non_event_tracker_event_country_code,

    --strings
    cast( 'stackadapt' as string ) as non_event_tracker_event_connector_source,
    cast( lower(CLIENT_DATA) as string ) non_event_tracker_event_email_address,
    cast( 'display' as string ) as non_event_tracker_event_medium_name,
    cast('display ad view' as string ) as non_event_tracker_event_name,


   
    cast( null as string ) as non_event_tracker_event_ip_address,
    cast( null as string ) as non_event_tracker_event_postal_code,

    -- numbers
    cast( null as numeric ) as non_event_tracker_event_cost,

    --datetime
    cast( filter_to_conversion_orders.first_imp_date as timestamp ) as non_event_tracker_event_timestamp,
    cast( filter_to_conversion_orders.first_imp_date as timestamp ) as non_event_tracker_event_timestamp_replicated,

  from filter_to_conversion_orders

)

select * from rename_cast_and_order_columns