with

source_ads as (

  select * from adelfi-iprod.stackadapt_ads.creative

),

source_advertiser as (

  select * from adelfi-iprod.stackadapt_ads.stats_delivery_native_ad 

),

filter_advertiser as (

  select 
    advertiser_id,
    native_ad_id
  from source_advertiser
  where advertiser_id = 57150

),

join_advertiser as (

    select 
    source_ads.*,
  from source_ads
  inner join filter_advertiser
    on source_ads.id = filter_advertiser.native_ad_id
),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( id as string ) as ad_natural_key,

    -- strings
    cast( 'stackadapt' as string ) as ad_connector_source,  
    cast( 'display' as string ) as ad_medium_name,
    cast( name as string ) as ad_name,
    cast( null as string ) as ad_text,
    cast( null as string ) as ad_url,

    -- booleans 
    cast( true as boolean ) as is_directly_attributable,
    
    -- dates
    cast( updated_at as timestamp ) as ad_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as ad_timestamp_replicated,
  
  from join_advertiser

)

select * from rename_cast_and_order_columns