with 

source_catalog_mailers as (

 SELECT * FROM lagence-420415.analytics_ftp.belardiwong__catalog_mailers_2__8__file_replication

),

create_unique_campaigns as (

  select 
    *,
    concat(campaign,' ',description) as concat_campaign_description
  from source_catalog_mailers


),

cast_and_rename as (

  select 
    -- natural keys
    cast(keycode as string) as campaign_natural_key,

    -- strings
    cast('belardi wong' as string) as campaign_connector_source,
    cast('direct mailer' as string) as campaign_medium_name,
    cast(concat_campaign_description as string) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- timestamps
    max(timestamp(in_home_date)) campaign_timestamp_updated,
    max(timestamp(in_home_date)) as campaign_timestamp_replicated,
  from create_unique_campaigns
  group by all

)

select * from cast_and_rename