with

source_orders as (

  select * from lagence-420415.shopify_custom.order

),

filter_conversion_channel as (

  select *,
    case 
      when(
        lower( source_orders.billing_address_country_code )  = 'us'
      )
      then  regexp_extract( source_orders.billing_address_zip, r'^\d{5}' )
      else source_orders.billing_address_zip
      end as postal_code,
  from source_orders
  where source_name not in ('198258393089','2907783','2833803','Point of Sale - Merlose Prior')

),

extract_nested_note_attributes as (

    select

        filter_conversion_channel.*,
        
        max(case when json_extract_scalar( unnested_note_attributes , '$.name') = 'network_userid' then json_extract_scalar( unnested_note_attributes , '$.value') end) as network_userid,
        max(case when json_extract_scalar( unnested_note_attributes , '$.name') = 'domain_userid' then json_extract_scalar( unnested_note_attributes , '$.value') end) as domain_userid,
    
    from filter_conversion_channel

        left join

            unnest(json_extract_array(  filter_conversion_channel.note_attributes  )) as  unnested_note_attributes
    
    group by all

),

add_order_type_channel_and_sub_channel as (

  select 
    
    *,
    
    'D2C' as order_type,
    
    case 
      when source_name = 'pos' then 'pos' 
      else 'web'
    end as order_channel,
    
    case 
      when source_name = 'pos' then 'pos'
      when source_name = '2329312' then 'meta'
      when source_name = '3890849' then 'shop app'
      else 'shopify'
    end as order_sub_channel,

    case 
      when source_name = 'pos' then true
      when source_name = '2329312' then true
      when source_name = '3890849' then true
      else true
    end as is_directly_attributable

  from extract_nested_note_attributes

),

rename_cast_and_order_columns as (

  select

    -- natural keys - regular
    cast( id as string ) as order_natural_key,

    -- natural keys - identity resolution
    cast( null as string ) as order_user_identifier_application,
    cast( cart_token as string ) as order_user_identifier_cart_token,
    cast( null as string ) as order_user_identifier_fingerprint,
    cast( network_userid as string ) as order_user_identifier_server_side_cookie,
    cast( domain_userid as string ) as order_user_identifier_client_side_cookie,

    -- strings
    cast( order_channel as string) as order_channel,
    'shopify' as order_connector_source,
    lower( cast( billing_address_country_code as string ) ) as order_country_code,
    cast( email as string ) as order_email_address,
    cast( browser_ip as string ) as order_ip_address,
    cast( 'regional' as string ) as order_mmm_geo_grain,
    cast( order_number as string ) as order_natural_key_customer_facing,
    cast( postal_code as string ) order_postal_code,
    cast( order_sub_channel as string ) as order_sub_channel,
    cast( order_type as string ) as order_type,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- numbers
    cast( subtotal_price as numeric ) as order_amount_total,

    -- timestamps
    cast( created_at as timestamp ) as order_timestamp,
    cast( _fivetran_synced as timestamp ) as order_timestamp_replicated,
  
  from add_order_type_channel_and_sub_channel

)

select * from rename_cast_and_order_columns