with

source_ad_summary_daily as (

  select * from lagence-420415.analytics_ftp.lagence_keynes_ftp_destination_tables__keynes_ad_summary_daily_1__29__file_replication

),

create_compound_key as (

  select *,

    creative_id
      || '-' || date
      || '-' || campaign_id
    as compound_key

  from source_ad_summary_daily

),

rename_and_order_columns as (

  select

    -- natural keys
    cast( compound_key as string ) as ad_summary_daily_natural_key,
    cast( creative_id as string ) as ad_summary_daily_ad_natural_key,

    -- strings
    cast( 'keynes digital' as string ) as ad_summary_daily_connector_source,

    -- numbers
    cast( clicks as numeric ) as ad_summary_daily_clicks,
    cast( conversions as numeric ) as ad_summary_daily_conversions,
    cast( conversion_value as numeric ) as ad_summary_daily_conversions_value,
    cast( ad_spend_cost as numeric ) as ad_summary_daily_cost,
    cast( impressions as numeric ) as ad_summary_daily_impressions,

    -- dates
    cast( date as date ) as ad_summary_daily_date,
    cast( _INSIGHTA_REPLICATION_TIMESTAMP as timestamp ) as ad_summary_daily_timestamp_replicated,
  
  from create_compound_key

)

select * from rename_and_order_columns