with

source_ads as (

  select * from lagence-420415.analytics_ftp.lagence_keynes_ftp_destination_tables__keynes_ad_summary_daily_1__29__file_replication
),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( creative_id as string ) as ad_natural_key,

    -- strings
    cast( 'keynes digital' as string ) as ad_connector_source,
    cast( 'ctv' as string ) as ad_medium_name,
    cast( creative_name as string ) as ad_name,
    cast( creative_message as string ) as ad_text,
    cast( creative_url as string ) as ad_url,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- dates
    max(cast( date as timestamp )) as ad_timestamp_updated,
    max(cast( _INSIGHTA_REPLICATION_TIMESTAMP as timestamp )) as ad_timestamp_replicated,
  
  from source_ads
  group by all

)

select * from rename_cast_and_order_columns