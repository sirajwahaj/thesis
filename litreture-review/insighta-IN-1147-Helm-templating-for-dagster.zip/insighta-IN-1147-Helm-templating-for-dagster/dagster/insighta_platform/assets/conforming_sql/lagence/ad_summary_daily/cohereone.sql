with 

source_catalog_mailers as (

  select * from lagence-420415.email.cohereone_catalog_mailer 
  qualify row_number() over (partition by combined_key order by _fivetran_synced desc) = 1

),

source_conversion_matchback as (

  select 
    * 
  from lagence-420415.email.cohereone_conversion_matchback
  qualify row_number() over (partition by order_number order by _fivetran_synced desc) = 1
  
),

aggregate_conversions_by_keycode_timestamp as (

  SELECT
    combined_key,
    SUM(CAST(REGEXP_REPLACE(gross_sales, r'[\$,]', '') AS NUMERIC)) AS ad_summary_daily_conversions_value,
    COUNT(cast(order_number as numeric)) AS ad_summary_daily_conversions
  FROM source_conversion_matchback
  GROUP BY combined_key

),

-- clicks, impressions, cost
filter_catalog_invalid_timestamp as (

  select 
    *,
    TIMESTAMP(SAFE.PARSE_DATE('%m/%d/%Y', in_home_date)) AS in_home_date_format,
    CAST(REGEXP_REPLACE(total_qty_mailed, r'[\$,]', '') AS NUMERIC) as total_qty_mailed_format,
     CAST(REGEXP_REPLACE(catalog_cost, r'[\$,]', '') AS NUMERIC) as catalog_cost_format
   from source_catalog_mailers
  where in_home_date is not null

),

cast_key_and_in_home_date as (

  select 
    -- natural keys
    concat(in_home_date_format, combined_key) as ad_summary_daily_natural_key,
    cast( combined_key as string ) as ad_summary_daily_ad_natural_key,
    date( in_home_date_format ) as ad_summary_daily_date,
    timestamp( _fivetran_synced ) as ad_summary_daily_timestamp_replicated,
    sum( cast( total_qty_mailed_format as numeric ) ) as ad_summary_daily_clicks,
    sum( cast (total_qty_mailed_format as numeric ) ) as ad_summary_daily_impressions,
    sum( cast( catalog_cost_format as numeric ) * cast( total_qty_mailed_format as numeric )) as ad_summary_daily_cost,
  from filter_catalog_invalid_timestamp
  group by all

),

left_join_conversions_on_impressions_clicks_spend as (

  select * 
  from cast_key_and_in_home_date
  left join aggregate_conversions_by_keycode_timestamp
  on cast_key_and_in_home_date.ad_summary_daily_ad_natural_key = aggregate_conversions_by_keycode_timestamp.combined_key

),

select_and_sort_columns as (

  select 

    -- natural keys
    ad_summary_daily_natural_key,
    ad_summary_daily_ad_natural_key,
    
    -- strings
    cast( 'cohereone' as string ) as ad_summary_daily_connector_source,

    -- numbers
    cast(ad_summary_daily_clicks as numeric) as ad_summary_daily_clicks,
    cast(ad_summary_daily_conversions as numeric) as ad_summary_daily_conversions,
    cast(ad_summary_daily_conversions_value as numeric) as ad_summary_daily_conversions_value,
    cast(ad_summary_daily_cost as numeric) as ad_summary_daily_cost,
    cast(ad_summary_daily_impressions as numeric) as ad_summary_daily_impressions,
    -- dates
    ad_summary_daily_date,

    -- timestamps 
    ad_summary_daily_timestamp_replicated,

  from left_join_conversions_on_impressions_clicks_spend

)

select * from select_and_sort_columns