with 

source_catalog_mailers as (

 select * from lagence-420415.email.cohereone_catalog_mailer
 qualify row_number() over (partition by combined_key order by _fivetran_synced desc) = 1  

),

filter_invalid_timestamp as (

  select * from source_catalog_mailers
  where in_home_date is not null

),

normalize_concat_fields AS (

  SELECT
    *,
    IFNULL(campaign_name, '')    AS campaign_norm,
    IFNULL(version, '') AS version_norm,
    IFNULL(description, '') AS description_norm,
    IFNULL(fixed_recency, '')      AS freq_norm
  FROM filter_invalid_timestamp

),

create_unique_ads as (

  select 
    *,
    concat(campaign_name, ' ', version_norm, ' ', description_norm, ' ', freq_norm, ' ', freq_norm, ' ', combined_key) as concat_ad_description
  from normalize_concat_fields

),

cast_and_rename as (

  select 
    -- natural keys
    cast(combined_key as string) as ad_natural_key,
    
    -- strings
    cast('cohereone' as string) as ad_connector_source,
    cast('direct mailer' as string) as ad_medium_name,
    cast(concat_ad_description as string) as ad_name,
    cast( null as string ) as ad_text,
    cast( null as string ) as ad_url,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- timestamps
    max(TIMESTAMP(SAFE.PARSE_DATE('%m/%d/%Y', in_home_date)) ) as ad_timestamp_updated,
    max(timestamp(_fivetran_synced)) as ad_timestamp_replicated,
  from create_unique_ads
  group by all

)

select * from cast_and_rename