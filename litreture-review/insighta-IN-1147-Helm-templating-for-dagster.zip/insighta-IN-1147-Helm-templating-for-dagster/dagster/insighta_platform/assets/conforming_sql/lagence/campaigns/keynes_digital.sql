with

source_campaigns as (
     select * from lagence-420415.analytics_ftp.lagence_keynes_ftp_destination_tables__keynes_campaign_summary_daily_1__28__file_replication

),

rename_cast_and_order_columns as (

  select
    distinct
    -- natural keys
    cast( campaign_id as string ) as campaign_natural_key,

    -- strings
    cast( 'keynes digital' as string ) as campaign_connector_source,
    cast( 'ctv' as string ) as campaign_medium_name,
    cast( campaign_name as string ) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- dates
    min(cast( date as timestamp )) as campaign_timestamp_updated,
    max(cast( _INSIGHTA_REPLICATION_TIMESTAMP as timestamp )) as campaign_timestamp_replicated
  
  from source_campaigns
  group by all

)

select * from rename_cast_and_order_columns