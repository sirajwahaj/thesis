--Conforming SQL for Stackadapt Non-Event Tracker Events
with

keynes_impression_source as (

  select * from lagence-420415.analytics_ftp.lagence_keynes_ftp_destination_tables__keynes_converted_impression_feed_1__27__file_replication

),

source_orders as (
  
  {{ ref('orders', 'shopify') }} 

),

create_non_event_tracker_event_natural_key as (

  select *,
    cast( EVENT_TYPE as string)
      || '_' || cast(EVENT_CAMPAIGN_ID as string)
      || '_' || cast(EVENT_AD_SET_ID as string)
      || '_' || cast(EVENT_CREATIVE_ID as string)
      || '_' || cast(ORDER_ID as string)
      || '_' || cast( event_time_utc as string)
      as non_event_tracker_event_natural_key
  from keynes_impression_source

),

rename_cast_and_order_columns as (

  select 

    -- natural keys
    cast( create_non_event_tracker_event_natural_key.non_event_tracker_event_natural_key as string ) as non_event_tracker_event_natural_key,
    cast( create_non_event_tracker_event_natural_key.EVENT_CAMPAIGN_ID as string ) as non_event_tracker_event_campaign_natural_key,
    cast( order_country_code as string ) as non_event_tracker_event_country_code,

    --strings
    cast( 'keynes digital' as string ) as non_event_tracker_event_connector_source,
    cast( order_email_address as string ) as non_event_tracker_event_email_address,
    cast( 'ctv' as string ) as non_event_tracker_event_medium_name,
    case 
     when lower(event_type) = 'impression' then 'display ad view' 
     when lower(event_type) = 'click' then 'display ad click' 
     else 'undefined' 
    end as non_event_tracker_event_name,
    cast( order_ip_address as string ) as non_event_tracker_event_ip_address,
    cast( order_postal_code as string ) as non_event_tracker_event_postal_code,

    -- numbers
    cast( 1 as numeric ) as non_event_tracker_event_cost,

    --datetime
    cast( create_non_event_tracker_event_natural_key.event_time_utc as timestamp ) as non_event_tracker_event_timestamp,
    cast( create_non_event_tracker_event_natural_key._INSIGHTA_REPLICATION_TIMESTAMP as timestamp ) as non_event_tracker_event_timestamp_replicated,

  from create_non_event_tracker_event_natural_key

    left join source_orders 
    
      on cast(create_non_event_tracker_event_natural_key.order_id as string) =  cast(source_orders.order_natural_key as string)

)

select * from rename_cast_and_order_columns