with

source_campaign_summary_daily as (

   select * from lagence-420415.analytics_ftp.lagence_keynes_ftp_destination_tables__keynes_campaign_summary_daily_1__28__file_replication

),

rename_and_cast as (

   select 

      --natural keys
      cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,

      --strings
      cast( 'keynes digital' as string ) as campaign_summary_daily_connector_source,

      --numbers
      cast( ad_spend_cost as numeric ) as campaign_summary_daily_cost,
      cast( clicks as numeric ) as campaign_summary_daily_clicks,
      cast( conversions as numeric ) as campaign_summary_daily_conversions,
      cast( conversion_value as numeric ) as campaign_summary_daily_conversions_value,
      cast( impressions as numeric ) as campaign_summary_daily_impressions,
   
      --timestamps
      cast( date as date ) as campaign_summary_daily_date,
      cast( _INSIGHTA_REPLICATION_TIMESTAMP as timestamp ) as campaign_summary_daily_timestamp_replicated

   from source_campaign_summary_daily

),

create_natural_key as (

   select *,
      campaign_summary_daily_campaign_natural_key
        || '_' || campaign_summary_daily_date
      as campaign_summary_daily_natural_key,

   from rename_and_cast

),

order_columns as (

   select

      -- natural keys
      campaign_summary_daily_natural_key,
      campaign_summary_daily_campaign_natural_key,

      -- strings
      campaign_summary_daily_connector_source,

      -- numbers
      campaign_summary_daily_clicks,
      campaign_summary_daily_conversions,
      campaign_summary_daily_conversions_value,
      campaign_summary_daily_cost,
      campaign_summary_daily_impressions,

      -- dates
      campaign_summary_daily_date,
      campaign_summary_daily_timestamp_replicated,

   from create_natural_key

)

select * from order_columns