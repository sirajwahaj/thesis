with 

ad_group_source as (

    select * from lagence-420415.analytics_ftp.lagence_keynes_ftp_destination_tables__keynes_campaign_summary_daily_1__28__file_replication

),

create_history_key as (

  select

    *,
    concat(campaign_id,'keynes_digital_adgroup') as history_key

  from ad_group_source

),

cast_rename_and_order as (

  select 
  
    cast( history_key as string ) as history_key,
    cast( 'keynes_digital_adgroup' as string ) as ad_group_natural_key,
    cast( campaign_id as string ) as campaign_natural_key,
    cast( null as timestamp ) as validity_timestamp_start,
    cast( null as timestamp ) as validity_timestamp_end,

  from create_history_key 

)

select * from cast_rename_and_order
