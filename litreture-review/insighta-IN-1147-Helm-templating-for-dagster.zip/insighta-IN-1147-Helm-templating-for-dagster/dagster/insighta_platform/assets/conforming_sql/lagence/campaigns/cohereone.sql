with 

source_catalog_mailers as (

 select * from lagence-420415.email.cohereone_catalog_mailer
 qualify row_number() over (partition by combined_key order by _fivetran_synced desc) = 1  

),

filter_invalid_timestamp as (

  select * from source_catalog_mailers
  where in_home_date is not null

),

cast_and_rename as (

  select 
    -- natural keys
    cast(campaign_name as string) as campaign_natural_key,
    
    -- strings
    cast('cohereone' as string) as campaign_connector_source,
    cast('direct mailer' as string) as campaign_medium_name,
    cast(campaign_name as string) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- timestamps
    max(TIMESTAMP(SAFE.PARSE_DATE('%m/%d/%Y', in_home_date)) ) campaign_timestamp_updated,
    max(timestamp(_fivetran_synced)) as campaign_timestamp_replicated,
  from filter_invalid_timestamp
  group by all

)

select * from cast_and_rename