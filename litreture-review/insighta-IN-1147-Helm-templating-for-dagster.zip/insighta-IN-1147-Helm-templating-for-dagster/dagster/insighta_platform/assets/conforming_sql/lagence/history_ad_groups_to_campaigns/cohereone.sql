with 

ad_group_source as (

  select * from lagence-420415.email.cohereone_catalog_mailer
  qualify row_number() over (partition by combined_key order by _fivetran_synced desc) = 1  

),

filter_campaign_name as (

  select 
    * 
  from ad_group_source
  where campaign_name is not null

),

create_history_key as (

  select
    *,
    concat(campaign_name,'cohereone_adgroup') as history_key

  from filter_campaign_name

),

cast_rename_and_order as (

  select 
    distinct
    cast( history_key as string ) as history_key,
    cast( 'cohereone_adgroup' as string ) as ad_group_natural_key,
    cast( campaign_name as string ) as campaign_natural_key,
    cast( null as timestamp ) as validity_timestamp_start,
    cast( null as timestamp ) as validity_timestamp_end,

  from create_history_key 

)

select * from cast_rename_and_order
