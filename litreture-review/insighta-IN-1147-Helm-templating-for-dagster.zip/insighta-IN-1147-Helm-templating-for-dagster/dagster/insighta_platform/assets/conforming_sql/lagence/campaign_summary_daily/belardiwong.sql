with 

source_catalog_mailers as (

  select * from lagence-420415.analytics_ftp.belardiwong__catalog_mailers_2__8__file_replication

),

source_conversion_matchback as (

  select * from lagence-420415.analytics_ftp.belardiwong__conversion_matchback_1__1__file_replication

),

  cleaned_catalog_mailers AS (
    select
 
      *,
      -- remove non-digits (commas etc.) and cast to INT64
      cast(regexp_replace(mailed_qty, r'[^0-9]', '') as numeric) as mailed_qty_num,
      
      -- remove dollar signs (and anything except digits/dot) and cast to NUMERIC
      cast(regexp_replace(TOTAL_CATALOG_COST_PIECE, r'[^0-9\.]', '') as numeric) as total_catalog_cost_piece_num

    from source_catalog_mailers
  ),

cast_key_and_in_home_date as (

  select 
    -- natural keys
    cast( concat(REGEXP_REPLACE(keycode, r'#', ''), ' ', cast(in_home_date as date)) as string ) as campaign_summary_daily_natural_key,
    cast( keycode as string ) as campaign_summary_daily_campaign_natural_key,
    cast( in_home_date as date ) as campaign_summary_daily_date,
    cast( in_home_date as timestamp ) as campaign_summary_daily_timestamp_replicated,
    sum( mailed_qty_num ) as campaign_summary_daily_clicks,
    sum( mailed_qty_num ) as campaign_summary_daily_impressions,
    sum( mailed_qty_num * total_catalog_cost_piece_num ) as campaign_summary_daily_cost,
  from cleaned_catalog_mailers
  group by all

),

join_timestamp_on_conversion_matchback as (

  select 
    *
  from source_conversion_matchback
  left join cast_key_and_in_home_date
    on source_conversion_matchback.keycode = cast_key_and_in_home_date.campaign_summary_daily_campaign_natural_key

),

filter_out_null_in_home_date as (

  select
    *
  from join_timestamp_on_conversion_matchback
  where campaign_summary_daily_date is not null

),

create_distinct_event_key as (

  select 
    *,
    cast( concat(REGEXP_REPLACE(order_id, r'#', ''), '-', cast(campaign_summary_daily_date as date)) as string ) as non_event_tracker_event_natural_key
  from filter_out_null_in_home_date
  

),


create_campaign_summary_daily_allocation_cost_json as (

  select 
    cast_key_and_in_home_date.campaign_summary_daily_natural_key,
    cast_key_and_in_home_date.campaign_summary_daily_campaign_natural_key,
    cast('belardi wong' as string) as campaign_summary_daily_connector_source,
    cast_key_and_in_home_date.campaign_summary_daily_clicks,
    cast(count(distinct create_distinct_event_key.order_id) as numeric) as campaign_summary_daily_conversions,
    cast(sum(create_distinct_event_key.DOLLARS) as numeric) as campaign_summary_daily_conversions_value,
    cast_key_and_in_home_date.campaign_summary_daily_cost,
    cast_key_and_in_home_date.campaign_summary_daily_impressions,
    cast_key_and_in_home_date.campaign_summary_daily_date,
    cast_key_and_in_home_date.campaign_summary_daily_timestamp_replicated,
  from cast_key_and_in_home_date
  left outer join create_distinct_event_key
    using(campaign_summary_daily_natural_key)
  group by all

),

select_and_sort_columns as (

  select 

    -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,
    
    -- strings
    campaign_summary_daily_connector_source,

    -- numbers
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,

    -- timestamps 
    campaign_summary_daily_timestamp_replicated,

  from create_campaign_summary_daily_allocation_cost_json

)

select * from select_and_sort_columns