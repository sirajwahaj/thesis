with 

ad_source as (

  select * from lagence-420415.analytics_ftp.lagence_keynes_ftp_destination_tables__keynes_ad_summary_daily_1__29__file_replication

),

create_history_key as (

  select

    *,
    concat(creative_id,'keynes_digital_adgroup') as history_key

  from ad_source

),

cast_rename_and_order as (

  select 
  
    cast( history_key as string ) as history_key,
    cast( creative_id as string ) as ad_natural_key,
    cast( 'keynes_digital_adgroup' as string ) as ad_group_natural_key,
    cast( null as timestamp ) as validity_timestamp_start,
    cast( null as timestamp ) as validity_timestamp_end,

  from create_history_key 

)

select * from cast_rename_and_order
