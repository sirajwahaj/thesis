with 

source_catalog_mailers as (

  SELECT * FROM lagence-420415.analytics_ftp.belardiwong__catalog_mailers_2__8__file_replication

),

source_conversion_matchback as (

  SELECT * FROM lagence-420415.analytics_ftp.belardiwong__conversion_matchback_1__1__file_replication

),

source_orders as (

  {{ ref('orders', 'shopify') }}

),

cast_key_and_in_home_date as (

  select 
    keycode,
    cast( in_home_date as timestamp ) as in_home_date
  from source_catalog_mailers

),

join_timestamp_on_conversion_matchback as (

  select 
    *,
    CASE 
      WHEN STARTS_WITH(order_id, '#') THEN SUBSTR(order_id, 2)
      ELSE order_id
    END AS join_order_number,
  from source_conversion_matchback
  left join cast_key_and_in_home_date
  using (keycode) 

),

filter_out_null_in_home_date as (

  select
    *
  from join_timestamp_on_conversion_matchback
  where in_home_date is not null

),

create_distinct_event_key as (

  select 
    *,
    cast( concat(REGEXP_REPLACE(order_id, r'#', ''), '-', cast(in_home_date as date)) as string ) as concat_order_id_and_in_home_date
  from filter_out_null_in_home_date
  

),

join_conversion_email as (

  select
    create_distinct_event_key.*,
    ifnull(source_orders.order_email_address, create_distinct_event_key.EMAIL_ADDRESS) as order_email_address,
    source_orders.order_ip_address,
    source_orders.order_postal_code,
    source_orders.order_country_code,
  from create_distinct_event_key
  left outer join source_orders
    on create_distinct_event_key.join_order_number = source_orders.order_natural_key_customer_facing

),

cast_and_rename as (

  select 

    cast(concat_order_id_and_in_home_date as string) as non_event_tracker_event_natural_key,
    cast(keycode as string) as non_event_tracker_event_campaign_natural_key,
    cast(order_country_code as string) as non_event_tracker_event_country_code,
    cast('belardi wong' as string) as non_event_tracker_event_connector_source,
    cast(lower(order_email_address) as string) as non_event_tracker_event_email_address,
    cast('direct mailer' as string) as non_event_tracker_event_medium_name,
    cast('direct mailer sent' as string) as non_event_tracker_event_name,
    cast( order_ip_address as string ) as non_event_tracker_event_ip_address,
    cast( order_postal_code as string ) as non_event_tracker_event_postal_code,
    cast( 1 as numeric ) as non_event_tracker_event_cost, -- set to 1 because before IN-844 it was calculated in the campaign_summary_daily model like this: cast( 1/(count(*) over (partition by campaign_summary_daily_natural_key)) as numeric) as ratio_cost
    timestamp(in_home_date) as non_event_tracker_event_timestamp,
    timestamp(in_home_date) as non_event_tracker_event_timestamp_replicated,

  from join_conversion_email

)

select * from cast_and_rename
