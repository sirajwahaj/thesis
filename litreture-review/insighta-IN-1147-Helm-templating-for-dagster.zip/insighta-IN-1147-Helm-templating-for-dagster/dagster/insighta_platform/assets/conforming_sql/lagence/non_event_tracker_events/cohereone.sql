with 

source_catalog_mailers as (  

 select * from `lagence-420415.email.cohereone_catalog_mailer`  
 qualify row_number() over (partition by combined_key order by _fivetran_synced desc) = 1  


),  

source_conversion_matchback as (  

  SELECT 
    division_name,  
    final_match_type_description,  
    merge_key,  
    mail_key,  
    combined_key,  
    order_number,  
    max(_fivetran_synced) as _fivetran_synced  
  from lagence-420415.email.cohereone_conversion_matchback  
  group by all  

),  

source_orders as (  

  --select * from `lagence-420415.analytics_conformed_sources.orders__shopify`  
  {{ ref('orders', 'shopify') }}  

),  

attach_in_home_date as (  

  select  
    source_conversion_matchback.*,  
    TIMESTAMP(SAFE.PARSE_DATE('%m/%d/%Y', source_catalog_mailers.in_home_date)) as in_home_date,  
  from source_conversion_matchback  
  inner join source_catalog_mailers 
    on cast(source_conversion_matchback.combined_key as string) = cast(source_catalog_mailers.combined_key as string)  

),  

join_conversion_email as (  

  select  
    cast( concat(REGEXP_REPLACE(cast(attach_in_home_date.order_number as string), r'#', ''), '-', cast(attach_in_home_date.combined_key as string)) as string ) as concat_order_id_and_combined_key,  
    attach_in_home_date.*,  
    source_orders.order_email_address as order_email_address,  
    source_orders.order_ip_address,  
    source_orders.order_postal_code,  
    source_orders.order_country_code,  
  from attach_in_home_date  
  left outer join source_orders  
    on cast(attach_in_home_date.order_number as string) = cast(source_orders.order_natural_key as string)  

),  

cast_and_rename as (  

  select 

    cast(concat_order_id_and_combined_key as string) as non_event_tracker_event_natural_key,  
    cast(combined_key as string) as non_event_tracker_event_campaign_natural_key,  
    cast(order_country_code as string) as non_event_tracker_event_country_code,  
    cast('cohere one' as string) as non_event_tracker_event_connector_source,  
    cast(lower(order_email_address) as string) as non_event_tracker_event_email_address,  
    cast('direct mailer' as string) as non_event_tracker_event_medium_name,  
    cast('direct mailer sent' as string) as non_event_tracker_event_name,  
    cast( order_ip_address as string ) as non_event_tracker_event_ip_address,  
    cast( order_postal_code as string ) as non_event_tracker_event_postal_code,  
    cast( 1 as numeric ) as non_event_tracker_event_cost, 
    timestamp(in_home_date) as non_event_tracker_event_timestamp,  
    timestamp(_fivetran_synced) as non_event_tracker_event_timestamp_replicated,  

  from join_conversion_email  

)  

select * from cast_and_rename where true  