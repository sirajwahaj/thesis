
with 

source_campaigns as (

  select * from {{ gcp_project_id_prod }}.ascend_by_partnerize.transaction_details_resource
  qualify row_number() over (partition by id order by _fivetran_synced desc) = 1
  
),

rename_cast_and_order_columns as (

  select distinct
    
      -- natural keys
    cast(publisher_id as string) as campaign_natural_key,

      -- strings
    cast( 'ascend by partnerize' as string ) as campaign_connector_source,
    cast( 'affiliate' as string ) as campaign_medium_name,
    cast( company as string ) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,
    
    --timestamps
    cast(start_date as timestamp) as campaign_timestamp_updated,
    cast(_fivetran_synced as timestamp ) as campaign_timestamp_replicated,
    
  from source_campaigns

)

select distinct * from rename_cast_and_order_columns
