with

source_ad_summary_daily as (

   select * from {{ gcp_project_id_prod }}.snapchat_ads.ad_daily_report

),

rename_and_cast as (

   select 

      --natural keys
      cast( ad_id as string ) as ad_summary_daily_ad_natural_key,
      cast( date as string ) as ad_summary_daily_date_natural_key,

      --strings
      cast( 'snapchat' as string ) as ad_summary_daily_connector_source,

      --numbers
      cast( spend as numeric ) as ad_summary_daily_cost_micros,
      cast( swipes as numeric ) as ad_summary_daily_clicks,
      cast( conversion_purchases as numeric ) as ad_summary_daily_conversions,
      cast( conversion_purchases_value as numeric ) as ad_summary_daily_conversions_value_micros,
      cast( impressions as numeric ) as ad_summary_daily_impressions,
   
      --timestamps
      cast( date as date ) as ad_summary_daily_date,
      cast( _fivetran_synced as timestamp ) as ad_summary_daily_timestamp_replicated

   from source_ad_summary_daily

),

convert_cost_to_dollars as (

   select rename_and_cast.*,

   ad_summary_daily_cost_micros/1000000 as ad_summary_daily_cost,
   ad_summary_daily_conversions_value_micros/1000000 as ad_summary_daily_conversions_value,
   
   from rename_and_cast

),

create_natural_key as (

   select *,

      ad_summary_daily_ad_natural_key
         || '_' || ad_summary_daily_date_natural_key
         as ad_summary_daily_natural_key,

   from convert_cost_to_dollars

),

order_columns as (

   select

      -- natural keys
      ad_summary_daily_natural_key,
      ad_summary_daily_ad_natural_key,

      -- strings
      ad_summary_daily_connector_source,

      -- numbers
      ad_summary_daily_clicks,
      ad_summary_daily_conversions,
      ad_summary_daily_conversions_value,
      ad_summary_daily_cost,
      ad_summary_daily_impressions,

      -- dates
      ad_summary_daily_date,
      ad_summary_daily_timestamp_replicated,

   from create_natural_key

)

select * from order_columns