with

source_ad_summary_daily as (

   select * from {{ gcp_project_id_prod }}.tiktok_ads.ad_report_daily

),

create_compound_key as (

   select *,

      ad_id
         || '-' || stat_time_day
         as compound_key

   from source_ad_summary_daily

),

rename_cast_and_order_columns as (

   select 

      --natural keys
      cast( compound_key as string ) as ad_summary_daily_natural_key,
      cast( ad_id as string ) as ad_summary_daily_ad_natural_key,

      --strings
      cast( 'tiktok' as string ) as ad_summary_daily_connector_source,

      --numbers
      cast( clicks as numeric ) as ad_summary_daily_clicks,
      cast( complete_payment as numeric ) as ad_summary_daily_conversions,
      cast( total_complete_payment_rate as numeric ) as ad_summary_daily_conversions_value,
      cast( spend as numeric ) as ad_summary_daily_cost,
      cast( impressions as numeric ) as ad_summary_daily_impressions,

      --timestamps
      cast( stat_time_day as date ) as ad_summary_daily_date,
      cast( _fivetran_synced as timestamp ) as ad_summary_daily_timestamp_replicated

   from create_compound_key

)

select * from rename_cast_and_order_columns