with 

source_ads as (

  select * from {{ gcp_project_id_prod }}.twitter_ads.promoted_tweet_history

),

create_history_key as (

  select

    *,
    concat(id,line_item_id) as history_key

  from source_ads

),

cast_rename_and_order as (

  select 
  
    cast( history_key as string ) as history_key,
    cast( id as string ) as ad_natural_key,
    cast( line_item_id as string ) as ad_group_natural_key,
    cast( created_at as timestamp ) as validity_timestamp_start,
    cast( null as timestamp ) as validity_timestamp_end,

  from create_history_key 

)

select * from cast_rename_and_order