--grin campaigns

with 

source_campaigns as (

  select * from {{ gcp_project_id_prod }}.grin.conversion
  qualify row_number() over (partition by order_id, order_number order by _fivetran_synced desc) = 1
  
),

rename_cast_and_order_columns as (

  select distinct
    
      -- natural keys
    cast(affiliate_link_id as string) as campaign_natural_key,

      -- strings
    cast( 'grin' as string ) as campaign_connector_source,
    cast( 'affiliate' as string ) as campaign_medium_name,
    cast(json_value(meta_data, '$.name') as string ) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    --timestamps
    cast(updated_at as timestamp) as campaign_timestamp_updated,
    cast(_fivetran_synced as timestamp ) as campaign_timestamp_replicated,
    
  from source_campaigns

)

select distinct * from rename_cast_and_order_columns