with

source_campaign_summary_daily_non_conversion as (

   select * from {{ gcp_project_id_prod }}.reddit_ads.campaign_report

),

source_campaign_summary_daily_conversions as (

   select * from {{ gcp_project_id_prod }}.reddit_ads.campaign_conversions_report

),

rename_and_cast_non_conversion_metrics as (

   select 

      --natural keys
      cast(campaign_id as string) as campaign_summary_daily_campaign_natural_key,

      --strings
      cast( 'reddit' as string ) as campaign_summary_daily_connector_source,

      --numbers
      cast( spend as numeric ) as campaign_summary_daily_cost_micros,
      cast( clicks as numeric ) as campaign_summary_daily_clicks,
      cast( impressions as numeric ) as campaign_summary_daily_impressions,
   
      --timestamps
      cast( date as date ) as campaign_summary_daily_date,
      cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated

   from source_campaign_summary_daily_non_conversion

),

rename_filter_and_cast_conversion_metrics as (

   select 

      --natural keys
      cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,


      --numbers
      cast( total_items as numeric ) as campaign_summary_daily_conversions,
      cast( total_value as numeric ) as cents_total_value,
   
      --timestamps
      cast( date as date ) as campaign_summary_daily_date,

   from source_campaign_summary_daily_conversions
   where event_name = 'purchase'

),

join_onto_conversion_metrics as (

   select 
      
      rename_and_cast_non_conversion_metrics.*,
      rename_filter_and_cast_conversion_metrics.campaign_summary_daily_conversions,
      rename_filter_and_cast_conversion_metrics.cents_total_value

   from rename_and_cast_non_conversion_metrics
   left join rename_filter_and_cast_conversion_metrics
   on rename_and_cast_non_conversion_metrics.campaign_summary_daily_campaign_natural_key = rename_filter_and_cast_conversion_metrics.campaign_summary_daily_campaign_natural_key
   and rename_and_cast_non_conversion_metrics.campaign_summary_daily_date = rename_filter_and_cast_conversion_metrics.campaign_summary_daily_date

),

convert_micros_and_cents_to_dollars as (

   select join_onto_conversion_metrics.*,

   campaign_summary_daily_cost_micros/1000000 as campaign_summary_daily_cost,
   cents_total_value/100 as campaign_summary_daily_conversions_value
   
   from join_onto_conversion_metrics

),

create_natural_key as (

   select *,

      -- campaign_id, date
      campaign_summary_daily_campaign_natural_key
         || '_' || campaign_summary_daily_date
         as campaign_summary_daily_natural_key,

   from convert_micros_and_cents_to_dollars

),

order_columns as (

   select

      -- natural keys
      campaign_summary_daily_natural_key,
      campaign_summary_daily_campaign_natural_key,

      -- strings
      campaign_summary_daily_connector_source,

      -- numbers
      campaign_summary_daily_clicks,
      campaign_summary_daily_conversions,
      campaign_summary_daily_conversions_value,
      campaign_summary_daily_cost,
      campaign_summary_daily_impressions,

      -- dates
      campaign_summary_daily_date,
      campaign_summary_daily_timestamp_replicated,

   from create_natural_key

)

select * from order_columns