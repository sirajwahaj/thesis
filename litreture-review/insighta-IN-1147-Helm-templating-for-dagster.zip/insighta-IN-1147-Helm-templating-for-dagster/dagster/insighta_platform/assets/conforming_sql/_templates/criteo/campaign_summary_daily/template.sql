with

source_adset as (

  select * from {{ gcp_project_id_prod }}.criteo_ads.adset

),

source_campaign_summary_daily as (

  select * from {{ gcp_project_id_prod }}.criteo_ads.adset_statistics_report

),

join_campaign_id_onto_adset_statistics as (

  select
    source_campaign_summary_daily.*,
    source_adset.campaign_id
  from source_campaign_summary_daily
  left outer join source_adset on source_campaign_summary_daily.adset_id = source_adset.id

),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( _fivetran_id as string ) as campaign_summary_daily_natural_key,
    cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,

    -- strings
    cast ('criteo' as string) as campaign_summary_daily_connector_source,

    -- metrics
    cast( clicks  as numeric ) as campaign_summary_daily_clicks,
    cast( sales_all_client_attribution  as numeric ) as campaign_summary_daily_conversions,
    cast( revenue_generated_all_client_attribution  as numeric ) as campaign_summary_daily_conversions_value,
    cast( advertiser_cost  as numeric ) as campaign_summary_daily_cost,
    cast( displays  as numeric ) as campaign_summary_daily_impressions,

    -- dates
    cast( day  as date ) as campaign_summary_daily_date,
    cast( _fivetran_synced  as timestamp ) as campaign_summary_daily_timestamp_replicated,

  from join_campaign_id_onto_adset_statistics

)

select * from rename_cast_and_order_columns