
with promoted_tweet_history as (

select * from {{ gcp_project_id_prod }}.twitter_ads.promoted_tweet_history

),

tweet as (

  select * from {{ gcp_project_id_prod }}.twitter_ads.tweet

),

promoted_tweet_history_filtered_and_renamed as (

  select 
  
    cast( id as string ) as ad_natural_key,
    cast( tweet_id as string ) as tweet_fk,
    cast( 'x' as string ) as ad_connector_source,
    cast( 'social' as string ) as ad_medium_name,
    cast( updated_at as timestamp ) as ad_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as ad_timestamp_replicated

  from promoted_tweet_history

),

tweet_filtered_and_named as (

select 
    distinct
    cast( id as string ) as tweet_pk,
    cast( name as string ) as ad_name,

from tweet
where name is not null

),

join_name_onto_ads as (

  select * 
  from promoted_tweet_history_filtered_and_renamed 
  left join tweet_filtered_and_named
  on promoted_tweet_history_filtered_and_renamed.tweet_fk = tweet_filtered_and_named.tweet_pk

),

cast_filter_and_order_columns as (

  select 
    
    --keys
    ad_natural_key,

    --strings
    ad_connector_source,
    ad_medium_name,
    ad_name,
    cast( null as string ) as ad_text,
    cast( null as string ) as ad_url,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    --timestamps
    ad_timestamp_updated,
    ad_timestamp_replicated,
    
  from join_name_onto_ads
)

select * from cast_filter_and_order_columns
