with

source_campaign_summary_daily as (

   select * from {{ gcp_project_id_prod }}.adroll.all_campaigns

),

create_compound_key as (

  select *,

    date
      || '-' || eid
      as compound_key

  from source_campaign_summary_daily

),

rename_and_cast as (

  select 

    --natural keys
    cast( compound_key as string ) as campaign_summary_daily_natural_key,
    cast( eid as string ) as campaign_summary_daily_campaign_natural_key,

    --strings
    cast( 'adroll' as string ) as campaign_summary_daily_connector_source,

    --numbers
    cast( clicks as numeric ) as campaign_summary_daily_clicks,
    cast( conversions as numeric ) as campaign_summary_daily_conversions,
    cast( click_revenue as numeric ) as campaign_summary_daily_conversions_value_click,
    cast( view_revenue as numeric ) as campaign_summary_daily_conversions_value_view,
    cast( cost as numeric ) as campaign_summary_daily_cost,
    cast( impressions as numeric ) as campaign_summary_daily_impressions,
  
    --timestamps
    cast( date as date ) as campaign_summary_daily_date,
    cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated

  from create_compound_key

),

calculate_conversions_value as (

  select rename_and_cast.*,

  campaign_summary_daily_conversions_value_click
    + campaign_summary_daily_conversions_value_view as campaign_summary_daily_conversions_value
   
  from rename_and_cast

),

order_columns as (

   select

      -- natural keys
      campaign_summary_daily_natural_key,
      campaign_summary_daily_campaign_natural_key,

      -- strings
      campaign_summary_daily_connector_source,

      -- numbers
      campaign_summary_daily_clicks,
      campaign_summary_daily_conversions,
      campaign_summary_daily_conversions_value,
      campaign_summary_daily_cost,
      campaign_summary_daily_impressions,

      -- dates
      campaign_summary_daily_date,
      campaign_summary_daily_timestamp_replicated,

   from calculate_conversions_value

)

select * from order_columns