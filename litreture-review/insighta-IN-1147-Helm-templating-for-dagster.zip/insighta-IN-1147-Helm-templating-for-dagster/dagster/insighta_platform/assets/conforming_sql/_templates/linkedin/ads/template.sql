with

source_ad as (

  select * from {{ gcp_project_id_prod }}.linkedin_ads.creative_history

),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( id as string ) as ad_natural_key,
    -- strings
    cast( 'linkedin' as string ) as ad_connector_source,
    cast ( 'social' as string ) as ad_medium_name,
    cast( text_ad_headline as string ) as ad_name,
    cast( null as string ) as ad_text,
    cast( null as string ) as ad_url,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- dates
    cast( last_modified_at as timestamp ) as ad_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as ad_timestamp_replicated,
  
  from source_ad

)

select * from rename_cast_and_order_columns