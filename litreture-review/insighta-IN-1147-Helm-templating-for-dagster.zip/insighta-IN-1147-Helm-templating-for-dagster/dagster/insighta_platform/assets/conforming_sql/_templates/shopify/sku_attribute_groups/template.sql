select 
  cast( 1 as string ) as sku_attribute_group_natural_key,
  cast( 'Parent SKU' as string ) as sku_attribute_group_name, 

union all

select 
  cast( 2 as string ) as sku_attribute_group_natural_key,
  cast( 'Product Type' as string ) as sku_attribute_group_name, 

union all

select 
  cast( 3 as string ) as sku_attribute_group_natural_key,
  cast( 'Variant SKU' as string ) as sku_attribute_group_name, 