with 

grin_base_distinct_id as (

  select * from {{ gcp_project_id_prod }}.grin.conversion
  qualify row_number() over (partition by order_number, order_id order by _fivetran_synced desc) = 1

),

coalesce_order_number_and_order_id as (

  select 
    *,
    cast( coalesce(order_number,order_id) as string ) as coalesce_order_id,
  from grin_base_distinct_id
),

total_metrics_by_campaign_day as (

  select 

    -- natural keys
    cast( CONCAT(CAST(affiliate_link_id as string), '-', cast(created_at as date)) as string) as campaign_summary_daily_natural_key,
    cast( affiliate_link_id as string ) as campaign_summary_daily_campaign_natural_key,

    -- strings
    cast( 'grin' as string ) as campaign_summary_daily_connector_source,


    -- numbers
    cast( count(created_at) as numeric ) as campaign_summary_daily_clicks,
    cast( count(distinct coalesce_order_id) as numeric ) as campaign_summary_daily_conversions,
    cast( sum( amount ) as numeric ) as campaign_summary_daily_conversions_value,
    cast( sum( commission_amount ) as numeric ) as campaign_summary_daily_cost,
    cast( null as numeric ) as campaign_summary_daily_impressions,

    -- dates
    cast( created_at as date ) as campaign_summary_daily_date,

    -- timestamps
    max(cast( _fivetran_synced as timestamp )) as campaign_summary_daily_timestamp_replicated
  from coalesce_order_number_and_order_id
  group by all

),

select_and_sort_columns as (

  select 

    -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,
    
    -- strings
    campaign_summary_daily_connector_source,

    -- numbers
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,

    -- timestamps 
    campaign_summary_daily_timestamp_replicated,

  from total_metrics_by_campaign_day

)

select * from select_and_sort_columns