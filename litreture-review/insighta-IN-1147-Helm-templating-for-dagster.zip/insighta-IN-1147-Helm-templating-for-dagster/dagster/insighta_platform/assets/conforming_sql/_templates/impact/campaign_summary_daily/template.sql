with 

impact_base_distinct_id as (

  select 
    *
  from {{ gcp_project_id_prod }}.impact.action_event
  qualify row_number() over (partition by id order by _fivetran_synced desc) = 1
  
),

total_metrics_by_campaign_day as (

  select 

    -- natural keys
    cast( CONCAT(CAST(media_partner_id AS STRING), '-', cast(referring_date as date)) as string) as campaign_summary_daily_natural_key,
    cast( media_partner_id as string ) as campaign_summary_daily_campaign_natural_key,

    -- strings
    cast( 'impact' as string ) as campaign_summary_daily_connector_source,


    -- numbers
    cast( count(distinct id) as numeric ) as campaign_summary_daily_clicks,
    cast( count(distinct o_id) as numeric ) as campaign_summary_daily_conversions,
    cast( sum( amount ) as numeric ) as campaign_summary_daily_conversions_value,
    cast( sum( client_cost ) as numeric ) as campaign_summary_daily_cost,
    cast( null as numeric ) as campaign_summary_daily_impressions,

    -- dates
    cast( referring_date as date ) as campaign_summary_daily_date,

    -- timestamps
    max(cast( _fivetran_synced as timestamp )) as campaign_summary_daily_timestamp_replicated
  from impact_base_distinct_id
  group by all

),

select_and_sort_columns as (

  select 

    -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,
    
    -- strings
    campaign_summary_daily_connector_source,

    -- numbers
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,

    -- timestamps 
    campaign_summary_daily_timestamp_replicated,

  from total_metrics_by_campaign_day

)

select * from select_and_sort_columns
