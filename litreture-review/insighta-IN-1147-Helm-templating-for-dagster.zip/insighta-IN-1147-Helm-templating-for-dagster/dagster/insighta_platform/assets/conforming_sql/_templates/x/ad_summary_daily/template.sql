with ad_report as (

  select * from {{ gcp_project_id_prod }}.twitter_ads.promoted_tweet_report

),

ad_report_rename_cast as (

  select 

    --keys
    cast( concat( promoted_tweet_id, cast( date as date ) ) as string ) as ad_summary_daily_natural_key,
    cast( promoted_tweet_id as string ) as ad_summary_daily_ad_natural_key,

    --strings
    cast( 'x' as string ) as ad_summary_daily_connector_source,

    --numbers
    cast( billed_charge_local_micro as numeric ) as unconverted_spend,
    cast( clicks as numeric ) as ad_summary_daily_clicks,
    cast( impressions as numeric ) as ad_summary_daily_impressions,
    cast( conversion_purchases_order_quantity as numeric ) as ad_summary_daily_conversions,
    cast( conversion_purchases_sale_amount as numeric ) as ad_summary_daily_conversions_value,

    --dates
    cast(date as date) as ad_summary_daily_date,

    --timestamps
    cast( _fivetran_synced as timestamp ) as ad_summary_daily_timestamp_replicated
  
  from ad_report

),

convert_spend_to_dollars as (

  select *,

    cast( unconverted_spend/1000000 as numeric ) as ad_summary_daily_cost

  from ad_report_rename_cast

),

order_columns as (

 select

     -- natural keys
    ad_summary_daily_natural_key,
    ad_summary_daily_ad_natural_key,
    
    -- strings
    ad_summary_daily_connector_source,

    -- numbers
    ad_summary_daily_clicks,
    ad_summary_daily_conversions,
    ad_summary_daily_conversions_value,
    ad_summary_daily_cost,
    ad_summary_daily_impressions,

    -- dates
    ad_summary_daily_date,
    ad_summary_daily_timestamp_replicated,

  from convert_spend_to_dollars 
  
)

select * from order_columns