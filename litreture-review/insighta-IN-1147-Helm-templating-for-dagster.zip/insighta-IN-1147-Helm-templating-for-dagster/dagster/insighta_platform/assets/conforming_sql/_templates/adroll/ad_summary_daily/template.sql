with

source_ad_summary_daily as (

   select * from {{ gcp_project_id_prod }}.adroll.all_ads

),

create_compound_key as (

  select *,

    date
      || '-' || eid
      as compound_key

  from source_ad_summary_daily

),

rename_and_cast as (

  select 

    --natural keys
    cast( compound_key as string ) as ad_summary_daily_natural_key,
    cast( eid as string ) as ad_summary_daily_ad_natural_key,

    --strings
    cast( 'adroll' as string ) as ad_summary_daily_connector_source,

    --numbers
    cast( clicks as numeric ) as ad_summary_daily_clicks,
    cast( conversions as numeric ) as ad_summary_daily_conversions,
    cast( click_revenue as numeric ) as ad_summary_daily_conversions_value_click,
    cast( view_revenue as numeric ) as ad_summary_daily_conversions_value_view,
    cast( cost as numeric ) as ad_summary_daily_cost,
    cast( impressions as numeric ) as ad_summary_daily_impressions,
  
    --timestamps
    cast( date as date ) as ad_summary_daily_date,
    cast( _fivetran_synced as timestamp ) as ad_summary_daily_timestamp_replicated

  from create_compound_key

),

calculate_conversions_value as (

  select rename_and_cast.*,

  ad_summary_daily_conversions_value_click
    + ad_summary_daily_conversions_value_view as ad_summary_daily_conversions_value
   
  from rename_and_cast

),

order_columns as (

   select

      -- natural keys
      ad_summary_daily_natural_key,
      ad_summary_daily_ad_natural_key,

      -- strings
      ad_summary_daily_connector_source,

      -- numbers
      ad_summary_daily_clicks,
      ad_summary_daily_conversions,
      ad_summary_daily_conversions_value,
      ad_summary_daily_cost,
      ad_summary_daily_impressions,

      -- dates
      ad_summary_daily_date,
      ad_summary_daily_timestamp_replicated,

   from calculate_conversions_value

)

select * from order_columns