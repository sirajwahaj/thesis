with 

ad_group_source as (

  select * from {{ gcp_project_id_prod }}.pinterest_ads.ad_group_history

),

create_history_key as (

  select

    *,
    concat(id, campaign_id) as history_key

  from ad_group_source

),

cast_rename_and_order as (

  select 
  
    cast( history_key as string ) as history_key,
    cast( id as string ) as ad_group_natural_key,
    cast( campaign_id as string ) as campaign_natural_key,
    cast( null as timestamp ) as validity_timestamp_start,
    cast( null as timestamp ) as validity_timestamp_end,

  from create_history_key 

)

select * from cast_rename_and_order
