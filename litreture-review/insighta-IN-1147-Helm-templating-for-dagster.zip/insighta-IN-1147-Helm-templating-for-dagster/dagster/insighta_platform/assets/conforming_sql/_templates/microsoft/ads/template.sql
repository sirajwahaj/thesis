with

source_ads as (

  select * from {{ gcp_project_id_prod }}.microsoft_ads.ad_history

),

rename_and_order_columns as (

  select

    -- natural keys
    cast( id as string ) as ad_natural_key,

    -- strings
    cast( 'bing' as string ) as ad_connector_source,
    cast( 'search' as string ) as ad_medium_name,
    cast( title as string ) as ad_name,
    cast( null as string ) as ad_text,
    cast( null as string ) as ad_url,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- dates
    cast( modified_time as timestamp ) as ad_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as ad_timestamp_replicated
  
  from source_ads

)

select * from rename_and_order_columns