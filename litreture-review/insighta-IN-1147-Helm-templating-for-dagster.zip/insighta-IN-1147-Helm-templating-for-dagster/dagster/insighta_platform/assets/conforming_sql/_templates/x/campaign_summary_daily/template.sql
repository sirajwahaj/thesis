with campaign_report as (

  select * from {{ gcp_project_id_prod }}.twitter_ads.campaign_report

),

campaign_report_rename_cast as (

  select 

    --keys
    cast( concat( campaign_id, cast( date as date ) ) as string ) as campaign_summary_daily_natural_key,
    cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,

    --strings
    cast( 'x' as string ) as campaign_summary_daily_connector_source,

    --numbers
    cast( billed_charge_local_micro as numeric ) as unconverted_spend,
    cast( clicks as numeric ) as campaign_summary_daily_clicks,
    cast( impressions as numeric ) as campaign_summary_daily_impressions,
    cast( conversion_purchases_order_quantity as numeric ) as campaign_summary_daily_conversions,
    cast( conversion_purchases_sale_amount as numeric ) as campaign_summary_daily_conversions_value,

    --dates
    cast(date as date) as campaign_summary_daily_date,

    --timestamps
    cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated
  
  from campaign_report

),

convert_spend_to_dollars as (

  select *,

    cast( unconverted_spend/1000000 as numeric ) as campaign_summary_daily_cost

  from campaign_report_rename_cast

),

order_columns as (

 select

     -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,
    
    -- strings
    campaign_summary_daily_connector_source,

    -- numbers
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,
    campaign_summary_daily_timestamp_replicated,

  from convert_spend_to_dollars
  
)

select * from order_columns