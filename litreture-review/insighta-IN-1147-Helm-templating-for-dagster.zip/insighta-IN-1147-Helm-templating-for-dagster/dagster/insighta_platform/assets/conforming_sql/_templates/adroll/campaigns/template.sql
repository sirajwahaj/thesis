with

source_campaigns as (

  select * from {{ gcp_project_id_prod }}.adroll.all_campaigns

),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( eid as string ) as campaign_natural_key,

    -- strings
    cast( 'adroll' as string ) as campaign_connector_source,
    cast( 'display' as string ) as campaign_medium_name,
    cast( name as string ) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- dates
    cast( updated_date as timestamp ) as campaign_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as campaign_timestamp_replicated,
  
  from source_campaigns

)

select * from rename_cast_and_order_columns