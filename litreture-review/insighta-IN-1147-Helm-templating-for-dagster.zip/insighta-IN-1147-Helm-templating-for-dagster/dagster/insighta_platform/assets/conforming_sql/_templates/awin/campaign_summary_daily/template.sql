with

source_campaign_summary_daily as (
  select * from {{ gcp_project_id_prod }}.awin.transaction
),

filter_out_null_transaction_dates as (
  select *
  from source_campaign_summary_daily
  where tracked_amount is not null
),

normalize_fields as (
  select
    *,
    date(click_date) as click_date_utc
  from filter_out_null_transaction_dates
),

total_metrics_by_campaign_day as (
  select 

    -- natural keys
    cast(concat(cast(publisher_id as string), '-', date(click_date_utc)) as string) as campaign_summary_daily_natural_key,
    cast(publisher_id as string) as campaign_summary_daily_campaign_natural_key,

    -- strings
    cast('awin' as string) as campaign_summary_daily_connector_source,

    -- numbers
    cast(count(distinct id) as numeric) as campaign_summary_daily_clicks,
    cast(count(distinct order_ref) as numeric) as campaign_summary_daily_conversions,
    cast(sum(tracked_amount) as numeric) as campaign_summary_daily_conversions_value,
    -- sum native commission (no conversion)
    cast(sum(commission_amount) as numeric) as campaign_summary_daily_cost,
    cast(null as numeric) as campaign_summary_daily_impressions,

    -- dates
    click_date_utc as campaign_summary_daily_date,

    -- timestamps
    max(cast(_fivetran_synced as timestamp)) as campaign_summary_daily_timestamp_replicated
  from normalize_fields
  group by all
),

create_campaign_summary_daily_allocation_cost_json as (
  select 
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,
    campaign_summary_daily_connector_source,
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,
    campaign_summary_daily_date,
    campaign_summary_daily_timestamp_replicated,
  from total_metrics_by_campaign_day
  group by all
),

select_and_sort_columns as (
  select 

    -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,

    -- strings
    campaign_summary_daily_connector_source,

    -- numbers
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,

    -- timestamps 
    campaign_summary_daily_timestamp_replicated

  from create_campaign_summary_daily_allocation_cost_json
)

select * from select_and_sort_columns
