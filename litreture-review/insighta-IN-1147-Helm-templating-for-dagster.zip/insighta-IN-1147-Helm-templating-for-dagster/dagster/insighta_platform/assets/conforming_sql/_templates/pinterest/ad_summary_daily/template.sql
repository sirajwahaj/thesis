with

source_ad_summary_daily as (

   select * from {{ gcp_project_id_prod }}.pinterest_ads.pin_promotion_report

),

create_compound_key as (

   select *,

      date
         || '-' || advertiser_id
         || '-' || pin_promotion_id
         as compound_key

   from source_ad_summary_daily

),

rename_and_cast as (

   select 

      --natural keys
      cast( compound_key as string ) as ad_summary_daily_natural_key,
      cast( pin_promotion_id as string ) as ad_summary_daily_ad_natural_key,

      --strings
      cast( 'pinterest' as string ) as ad_summary_daily_connector_source,

      --numbers
      cast( outbound_click_1 as numeric ) as ad_summary_daily_clicks_unsaved,
      cast( outbound_click_2 as numeric ) as ad_summary_daily_clicks_saved,
      cast( total_checkout as numeric ) as ad_summary_daily_conversions,
      cast( total_checkout_value_in_micro_dollar as numeric ) as ad_summary_daily_conversions_value_micros,
      cast( spend_in_micro_dollar as numeric ) as ad_summary_daily_cost_micros,
      cast( impression_1 as numeric ) as ad_summary_daily_impressions_unsaved,
      cast( impression_2 as numeric ) as ad_summary_daily_impressions_saved,
   
      --timestamps
      cast( date as date ) as ad_summary_daily_date,
      cast( _fivetran_synced as timestamp ) as ad_summary_daily_timestamp_replicated

   from create_compound_key

),

combine_split_numbers as (

   select *,

      COALESCE(ad_summary_daily_clicks_unsaved, 0)
         + COALESCE(ad_summary_daily_clicks_saved, 0)
      AS ad_summary_daily_clicks,

      COALESCE(ad_summary_daily_impressions_unsaved, 0)
         + COALESCE(ad_summary_daily_impressions_saved, 0)
      AS ad_summary_daily_impressions


   from rename_and_cast

),

convert_cost_to_dollars as (

   select *,

   ad_summary_daily_conversions_value_micros / 1000000 as ad_summary_daily_conversions_value,
   ad_summary_daily_cost_micros / 1000000 as ad_summary_daily_cost,
   
   from combine_split_numbers

),

order_columns as (

   select

      -- natural keys
      ad_summary_daily_natural_key,
      ad_summary_daily_ad_natural_key,

      -- strings
      ad_summary_daily_connector_source,

      -- numbers
      ad_summary_daily_clicks,
      ad_summary_daily_conversions,
      ad_summary_daily_conversions_value,
      ad_summary_daily_cost,
      ad_summary_daily_impressions,

      -- dates
      ad_summary_daily_date,
      ad_summary_daily_timestamp_replicated,

   from convert_cost_to_dollars

)

select * from order_columns