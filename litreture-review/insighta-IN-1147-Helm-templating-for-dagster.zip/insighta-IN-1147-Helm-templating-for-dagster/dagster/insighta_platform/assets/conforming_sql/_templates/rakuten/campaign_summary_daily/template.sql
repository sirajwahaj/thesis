with

source_campaign_summary_daily as (

   select * from {{ gcp_project_id_prod }}.rakuten.report

),

parse_transaction_dates as (

   select 
      CASE
         WHEN REGEXP_CONTAINS(_transaction_date, r'^\d{4}-\d{2}-\d{2}$') THEN PARSE_DATE('%Y-%m-%d', _transaction_date)
         WHEN REGEXP_CONTAINS(_transaction_date, r'^\d{1,2}/\d{1,2}/\d{2}$') THEN PARSE_DATE('%m/%d/%y', _transaction_date)
         ELSE NULL
      END as parsed_date,
      CASE
         WHEN REGEXP_CONTAINS(transaction_date, r'^\d{4}-\d{2}-\d{2}$') THEN PARSE_DATE('%Y-%m-%d', transaction_date)
         WHEN REGEXP_CONTAINS(transaction_date, r'^\d{1,2}/\d{1,2}/\d{2}$') THEN PARSE_DATE('%m/%d/%y', transaction_date)
         ELSE NULL
      END AS parsed_date_new,
      *
   from source_campaign_summary_daily

),

create_primary_key as (
   select 
      concat(coalesce(parsed_date,parsed_date_new),publisher_name) rakuten_key,
      coalesce(parsed_date,parsed_date_new) as coalesced_transaction_date,
      *
   from parse_transaction_dates
),

filter_null_transaction_date as (

   select * from create_primary_key
   where coalesced_transaction_date is not null

),

deduplicate_records as (
   
   select 
      *
   from filter_null_transaction_date
   where 1=1
   qualify row_number() over (
      partition by rakuten_key
      order by _fivetran_synced desc
   ) = 1

),

remove_commas_from_number_columns as (

   select *,

      replace( no_of_clicks, ',', '' ) as no_of_clicks_without_commas,
      
      replace( gross_sales, ',', '' ) as gross_sales_without_commas,
      replace( total_commission, ',', '' ) as total_commission_without_commas,

   from deduplicate_records

),

rename_and_cast as (

   select 

      --natural keys
      cast( rakuten_key as string ) as campaign_summary_daily_natural_key,
      cast( 'campaign rakuten' as string ) as campaign_summary_daily_campaign_natural_key,

      --strings
      cast( 'rakuten' as string ) as campaign_summary_daily_connector_source,
      cast( publisher_name as string ) as campaign_summary_daily_publisher_name,

      --numbers
      cast( no_of_clicks_without_commas as numeric ) as campaign_summary_daily_clicks,
      cast( no_of_orders as numeric ) as campaign_summary_daily_conversions,
      cast( gross_sales_without_commas as numeric ) as campaign_summary_daily_conversions_value,
      cast( total_commission_without_commas as numeric ) as campaign_summary_daily_cost,
      cast( null as numeric ) as campaign_summary_daily_impressions,
   
      --timestamps
      cast( coalesced_transaction_date as date ) as campaign_summary_daily_date,
      cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated,

   from remove_commas_from_number_columns

),

order_columns as (

   select

      -- natural keys
      campaign_summary_daily_natural_key,
      campaign_summary_daily_campaign_natural_key,

      -- strings
      campaign_summary_daily_connector_source,

      -- numbers
      campaign_summary_daily_clicks,
      campaign_summary_daily_conversions,
      campaign_summary_daily_conversions_value,
      campaign_summary_daily_cost,
      campaign_summary_daily_impressions,

      -- dates
      campaign_summary_daily_date,
      campaign_summary_daily_timestamp_replicated,

   from rename_and_cast

)

select * from order_columns