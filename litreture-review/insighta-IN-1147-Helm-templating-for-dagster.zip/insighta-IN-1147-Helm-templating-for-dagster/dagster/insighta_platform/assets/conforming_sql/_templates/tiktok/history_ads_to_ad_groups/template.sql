with 

ad_source as (

  select * from {{ gcp_project_id_prod }}.tiktok_ads.ad_history

),

create_history_key as (

  select

    *,
    concat(ad_id,adgroup_id) as history_key

  from ad_source

),

cast_rename_and_order as (

  select 
  
    cast( history_key as string ) as history_key,
    cast( ad_id as string ) as ad_natural_key,
    cast( adgroup_id as string ) as ad_group_natural_key,
    cast( null as timestamp ) as validity_timestamp_start,
    cast( null as timestamp ) as validity_timestamp_end,

  from create_history_key 

)

select * from cast_rename_and_order