-- improvement opportunity: replcae the placehplder code with actual conforming transformations

with

source_cte_to_force_lineage as (

    select * from {{ gcp_project_id }}.{{ bigquery_dataset }}_replication_mountain.non_event_tracker_events

),

schema_creation as (

    select
        cast( null as string ) as non_event_tracker_event_natural_key,
        cast( null as string ) as non_event_tracker_event_campaign_natural_key,
        cast( null as string ) as non_event_tracker_event_country_code,
        cast( null as string ) as non_event_tracker_event_connector_source,
        cast( null as string ) as non_event_tracker_event_email_address,
        cast( null as string ) as non_event_tracker_event_medium_name,
        cast( null as string ) as non_event_tracker_event_name,
        cast( null as string ) as non_event_tracker_event_ip_address,
        cast( null as string ) as non_event_tracker_event_postal_code,
        cast( null as string ) as non_event_tracker_event_cost,
        cast( null as string ) as non_event_tracker_event_timestamp,
        cast( null as string ) as non_event_tracker_event_timestamp_replicated,

),

row_removed as (

    select * from schema_creation where 1=2

)

select * from row_removed