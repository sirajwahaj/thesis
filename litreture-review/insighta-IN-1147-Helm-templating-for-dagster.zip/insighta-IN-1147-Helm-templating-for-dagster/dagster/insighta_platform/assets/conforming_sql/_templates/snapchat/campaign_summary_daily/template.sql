with

source_campaign_summary_daily as (

   select * from {{ gcp_project_id_prod }}.snapchat_ads.campaign_daily_report

),

rename_and_cast as (

   select 

      --natural keys
      cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,
      cast( date as string ) as campaign_summary_daily_date_natural_key,

      --strings
      cast( 'snapchat' as string ) as campaign_summary_daily_connector_source,

      --numbers
      cast( spend as numeric ) as campaign_summary_daily_cost_micros,
      cast( swipes as numeric ) as campaign_summary_daily_clicks,
      cast( conversion_purchases as numeric ) as campaign_summary_daily_conversions,
      cast( conversion_purchases_value as numeric ) as campaign_summary_daily_conversions_value_micros,
      cast( impressions as numeric ) as campaign_summary_daily_impressions,
   
      --timestamps
      cast( date as date ) as campaign_summary_daily_date,
      cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated

   from source_campaign_summary_daily

),

convert_cost_to_dollars as (

   select rename_and_cast.*,

   campaign_summary_daily_cost_micros/1000000 as campaign_summary_daily_cost,
   campaign_summary_daily_conversions_value_micros/1000000 as campaign_summary_daily_conversions_value
   
   from rename_and_cast

),

create_natural_key as (

   select *,

      -- _fivetran_id, date, customer id
      campaign_summary_daily_campaign_natural_key
         || '_' || campaign_summary_daily_date_natural_key
         as campaign_summary_daily_natural_key,

   from convert_cost_to_dollars

),

order_columns as (

   select

      -- natural keys
      campaign_summary_daily_natural_key,
      campaign_summary_daily_campaign_natural_key,

      -- strings
      campaign_summary_daily_connector_source,

      -- numbers
      campaign_summary_daily_clicks,
      campaign_summary_daily_conversions,
      campaign_summary_daily_conversions_value,
      campaign_summary_daily_cost,
      campaign_summary_daily_impressions,

      -- dates
      campaign_summary_daily_date,
      campaign_summary_daily_timestamp_replicated,

   from create_natural_key

)

select * from order_columns