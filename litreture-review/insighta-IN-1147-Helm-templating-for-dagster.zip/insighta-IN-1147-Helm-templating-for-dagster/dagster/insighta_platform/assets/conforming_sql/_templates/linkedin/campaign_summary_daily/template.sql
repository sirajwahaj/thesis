with

source_campaign_summary_daily_non_conversions_metrics as (

  select * from {{ gcp_project_id_prod }}.linkedin_ads.ad_analytics_by_campaign

),

create_compound_key_non_conversions_metrics as (

  select *,

    day
      || '-' || campaign_id
     as compound_key,

  from source_campaign_summary_daily_non_conversions_metrics

),

rename_cast_and_order_columns_non_conversions_metrics as (

  select

    -- natural keys
    cast( compound_key as string ) as campaign_summary_daily_natural_key,
    cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,

    -- strings
    'linkedin' as campaign_summary_daily_connector_source,

    -- metrics
    cast( clicks as numeric ) as campaign_summary_daily_clicks,
    cast( external_website_conversions as numeric ) as campaign_summary_daily_conversions,
    cast( conversion_value_in_local_currency as numeric ) as campaign_summary_daily_conversions_value,
    cast( cost_in_local_currency as numeric ) as campaign_summary_daily_cost,
    cast( impressions as numeric ) as campaign_summary_daily_impressions,


    -- dates
    cast( day as date ) as campaign_summary_daily_date,
    cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated,

  from create_compound_key_non_conversions_metrics

),

order_columns as (

  select

    -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,

    -- strings
    campaign_summary_daily_connector_source,

    -- metrics
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,
    campaign_summary_daily_timestamp_replicated,

  from rename_cast_and_order_columns_non_conversions_metrics

)

select * from order_columns