with 

ad_group_source as (

  select * from {{ gcp_project_id_prod }}.snapchat_ads.ad_squad_history

),

create_history_key as (

  select

  *,
  CONCAT(
  CAST(id AS STRING),
  CAST(campaign_id AS STRING),
  COALESCE(CAST(start_time AS STRING),''),
  COALESCE(CAST(end_time AS STRING), '')
  ) AS history_key

  from ad_group_source

),

cast_rename_and_order as (

  select 
  
  cast( history_key as string ) as history_key,
  cast( id as string ) as ad_group_natural_key,
  cast( campaign_id as string ) as campaign_natural_key,
  cast( start_time as timestamp ) as validity_timestamp_start,
  cast( end_time as timestamp ) as validity_timestamp_end,

  from create_history_key 

)

select * from cast_rename_and_order