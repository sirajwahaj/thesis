with 

source_campaign as (

  select * from {{ gcp_project_id_prod }}.reddit_ads.ad_group

),

create_history_key as (

  select

    *,
    concat(id,campaign_id) as history_key

  from source_campaign

),

cast_rename_and_order as (

  select 
  
    cast( history_key as string ) as history_key,
    cast( id as string ) as ad_group_natural_key,
    cast( campaign_id as string ) as campaign_natural_key,
    cast( null as timestamp ) as validity_timestamp_start,
    cast( null as timestamp ) as validity_timestamp_end,

  from create_history_key 

)

select * from cast_rename_and_order