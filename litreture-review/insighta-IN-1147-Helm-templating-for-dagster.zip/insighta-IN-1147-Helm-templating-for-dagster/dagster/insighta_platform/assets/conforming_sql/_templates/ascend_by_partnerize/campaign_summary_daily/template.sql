with 

ascend_base_distinct_id as (

  select 
    *
  from {{ gcp_project_id_prod }}.ascend_by_partnerize.transaction_details_resource
  qualify row_number() over (partition by order_id order by _fivetran_synced desc) = 1

  
),

total_metrics_by_campaign_day as (

  select 

    -- natural keys
    cast( CONCAT(CAST(publisher_id AS STRING), '-', cast(start_date as date)) as string) as campaign_summary_daily_natural_key,
    cast( publisher_id as string ) as campaign_summary_daily_campaign_natural_key,

    -- strings
    cast( 'ascend by partnerize' as string ) as campaign_summary_daily_connector_source,


    -- numbers
    cast( count(id) as numeric ) as campaign_summary_daily_clicks, --there are null click ids so using id instead
    cast( count(distinct order_id) as numeric ) as campaign_summary_daily_conversions,
    SUM(
      CAST(
        REGEXP_REPLACE(NULLIF(sale_amount, ''), r'[^0-9.]', '')
        AS NUMERIC
      )
    ) AS campaign_summary_daily_conversions_value,

    SUM(
      CAST(
        REGEXP_REPLACE(NULLIF(commission, ''), r'[^0-9.]', '')
        AS NUMERIC
      )
    ) AS campaign_summary_daily_cost,
    cast( null as numeric ) as campaign_summary_daily_impressions,

    -- dates
    cast( start_date as date ) as campaign_summary_daily_date,

    -- timestamps
    max(cast( _fivetran_synced as timestamp )) as campaign_summary_daily_timestamp_replicated
  from ascend_base_distinct_id
  group by all

),

select_and_sort_columns as (

  select 

    -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,
    
    -- strings
    campaign_summary_daily_connector_source,

    -- numbers
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,

    -- timestamps 
    campaign_summary_daily_timestamp_replicated,

  from total_metrics_by_campaign_day

)

select * from select_and_sort_columns