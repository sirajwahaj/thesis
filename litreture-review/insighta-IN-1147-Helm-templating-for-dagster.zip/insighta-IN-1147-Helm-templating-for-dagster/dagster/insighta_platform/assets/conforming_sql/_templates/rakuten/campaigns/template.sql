with

source_campaigns as (

  select * from {{ gcp_project_id_prod }}.rakuten.report

),

convert_string_col_to_date as (

   select *,

      parse_date('%m/%d/%y', _transaction_date) as _transaction_date_parsed

   from source_campaigns

),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( 'campaign rakuten' as string ) as campaign_natural_key,

    -- strings
    cast( 'rakuten' as string ) as campaign_connector_source,
    cast( 'affiliate' as string ) as campaign_medium_name,
    cast( 'campaign rakuten' as string ) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- dates
    cast( _transaction_date_parsed as timestamp ) as campaign_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as campaign_timestamp_replicated,
  
  from convert_string_col_to_date

)

select * from rename_cast_and_order_columns