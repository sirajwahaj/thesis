with

source_campaign_summary_daily as (

   select * from {{ gcp_project_id_prod }}.mountain.campaign_group

),

convert_string_col_to_date as (

   select *,

      parse_date('%m-%d-%Y', day) as day_parsed,

   from source_campaign_summary_daily

),

remove_dollars_from_number_columns as (

   select *,

      replace( spend, '$', '' ) as spend_without_dollars,
      replace( order_value, '$', '' ) as order_value_without_dollars,

   from convert_string_col_to_date
   
),

remove_commas_from_number_columns as (

   select *,

      replace( spend_without_dollars, ',', '' ) as spend_without_commas,
      replace( order_value_without_dollars, ',', '' ) as order_value_without_commas,
      replace( impressions, ',', '' ) as impressions_without_commas,

   from remove_dollars_from_number_columns

),

create_compound_key as (

   select *,

      id
         || '-' || day_parsed
         as compound_key

   from remove_commas_from_number_columns

),

rename_cast_and_order_columns as (

   select 

      --natural keys
      cast( compound_key as string ) as campaign_summary_daily_natural_key,
      cast( id as string ) as campaign_summary_daily_campaign_natural_key,

      --strings
      cast( 'mountain' as string ) as campaign_summary_daily_connector_source,

      --numbers
      cast( visits as numeric ) as campaign_summary_daily_clicks,
      cast( conversions as numeric ) as campaign_summary_daily_conversions,
      cast( order_value_without_commas as numeric ) as campaign_summary_daily_conversions_value,
      cast( spend_without_commas as numeric ) as campaign_summary_daily_cost,
      cast( impressions_without_commas as numeric ) as campaign_summary_daily_impressions,
   
      --timestamps
      cast( day_parsed as date ) as campaign_summary_daily_date,
      cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated,

   from create_compound_key

)

select * from rename_cast_and_order_columns