with

source_campaigns as (

  select * from {{ gcp_project_id_prod }}.criteo_ads.campaign

),

filter_to_advertiser as (

  select * from source_campaigns
),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( id as string ) as campaign_natural_key,

    -- strings
    'criteo' as campaign_connector_source,
    cast( 'display' as string ) as campaign_medium_name,
    cast( name as string ) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- dates
    cast( _fivetran_synced as timestamp ) as campaign_timestamp_updated, -- there is no duplication, but we need a value in this column for the agnostic staging model
    cast( _fivetran_synced as timestamp ) as campaign_timestamp_replicated,
  
  from filter_to_advertiser

)

select * from rename_cast_and_order_columns