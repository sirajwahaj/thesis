with

source_campaign_summary_daily_cost_impressions_and_clicks as (

 select * from {{ gcp_project_id_prod }}.facebook_ads.basic_campaign

),

source_campaign_summary_daily_conversions as (

 select * from {{ gcp_project_id_prod }}.facebook_ads.basic_campaign_actions

),

basic_ad_action_values as (

 select * from {{ gcp_project_id_prod }}.facebook_ads.basic_ad_action_values

),

campaign_select as (

 select distinct id, campaign_id from {{ gcp_project_id_prod }}.facebook_ads.ad_history

),

join_campaign_on_ad_action_values as (

 SELECT 
   campaign_select.campaign_id,
   max(basic_ad_action_values._fivetran_id) _fivetran_id,
   basic_ad_action_values.action_type,
   sum(basic_ad_action_values.value) value,
   basic_ad_action_values.date,
   max(basic_ad_action_values._fivetran_synced) _fivetran_synced,
 FROM basic_ad_action_values
 LEFT JOIN campaign_select
 ON CAST(basic_ad_action_values.ad_id AS STRING) = CAST(campaign_select.id AS STRING)
 group by all

),

filter_conversions_to_purchases as (

 select * from source_campaign_summary_daily_conversions
 where action_type = 'purchase'

),

filter_source_conversions_value_to_purchases as (

 select * from join_campaign_on_ad_action_values
 where action_type = 'purchase'

),
 
rename_and_cast_source_cost_impressions_and_clicks as (

 select 

  --natural keys
  cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,
  cast( account_id as string ) as campaign_summary_daily_account_natural_key,
  cast( _fivetran_id as string ) as campaign_summary_daily_fivetran_natural_key,

  --strings
  cast( 'facebook' as string ) as campaign_summary_daily_connector_source,

  --numbers
  cast( spend as numeric ) as campaign_summary_daily_cost,
  cast( inline_link_clicks as numeric ) as campaign_summary_daily_clicks,
  cast( impressions as numeric ) as campaign_summary_daily_impressions,

  --dates 
  cast( date as date ) as campaign_summary_daily_date,
  cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated

 from source_campaign_summary_daily_cost_impressions_and_clicks
 
),

rename_and_cast_source_conversions as (

 select 

  --natural keys
  cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,
  cast( _fivetran_id as string ) as campaign_summary_daily_fivetran_natural_key,

  --numbers
  cast( value as numeric ) as campaign_summary_daily_conversions,

  --dates
  cast( date as date ) as campaign_summary_daily_date,
  cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated

 from filter_conversions_to_purchases 

),

rename_and_cast_source_conversions_value as (

 select 

  --natural keys
  cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,
  cast( _fivetran_id as string ) as campaign_summary_daily_fivetran_natural_key,

  --numbers
  cast( value as numeric ) as campaign_summary_daily_conversions_value,

  --dates
  cast( date as date ) as campaign_summary_daily_date,
  cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated

 from filter_source_conversions_value_to_purchases 

),

join_conversions as (

 select 
 
  rename_and_cast_source_cost_impressions_and_clicks.*,

  rename_and_cast_source_conversions.campaign_summary_daily_conversions as campaign_summary_daily_conversions

 from rename_and_cast_source_cost_impressions_and_clicks 

  left join rename_and_cast_source_conversions 

   using (campaign_summary_daily_campaign_natural_key, campaign_summary_daily_date)

),

join_conversions_value as (

 select 

  join_conversions.*,

  rename_and_cast_source_conversions_value.campaign_summary_daily_conversions_value as campaign_summary_daily_conversions_value

 from join_conversions 

  left join rename_and_cast_source_conversions_value 

   using (campaign_summary_daily_campaign_natural_key, campaign_summary_daily_date)

),

create_natural_key as (

 select *,

   campaign_summary_daily_fivetran_natural_key
    || '-' || campaign_summary_daily_date
    || '-' || campaign_summary_daily_account_natural_key
    || '-' || campaign_summary_daily_campaign_natural_key
    as campaign_summary_daily_natural_key,

 from join_conversions_value

),

order_columns as (

 select

     -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,
    
    -- strings
    campaign_summary_daily_connector_source,

    -- numbers
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,
    campaign_summary_daily_timestamp_replicated,

  from create_natural_key
  
)

select * from order_columns