with source_products as (

  select * from {{ gcp_project_id_prod }}.shopify.product

),

source_product_variants as (

  select * from {{ gcp_project_id_prod }}.shopify.product_variant 

),

add_parent_to_variants as (

  select 
    concat(source_products.id,'-',source_product_variants.id) as id,
    source_products._fivetran_synced
  from source_products
  left join source_product_variants
    on source_products.id = source_product_variants.product_id

),

cast_and_rename as (
  
  select

    -- natural keys
    cast( id as string ) as sku_natural_key,

    -- timestamps
    cast( _fivetran_synced as timestamp ) as _timestamp_replicated,

  from add_parent_to_variants

)

select * from cast_and_rename