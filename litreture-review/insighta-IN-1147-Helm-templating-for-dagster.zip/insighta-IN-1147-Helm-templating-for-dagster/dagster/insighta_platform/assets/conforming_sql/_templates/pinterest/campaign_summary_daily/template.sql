with

source_campaign_summary_daily as (

   select * from {{ gcp_project_id_prod }}.pinterest_ads.campaign_report

),

create_compound_key as (

   select *,

      date
         || '-' || advertiser_id
         || '-' || campaign_id
         as compound_key

   from source_campaign_summary_daily

),

rename_and_cast as (

   select 

      --natural keys
      cast( compound_key as string ) as campaign_summary_daily_natural_key,
      cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,

      --strings
      cast( 'pinterest' as string ) as campaign_summary_daily_connector_source,

      --numbers
      cast( outbound_click_1 as numeric ) as campaign_summary_daily_clicks_unsaved,
      cast( outbound_click_2 as numeric ) as campaign_summary_daily_clicks_saved,
      cast( total_checkout as numeric ) as campaign_summary_daily_conversions,
      cast( total_checkout_value_in_micro_dollar as numeric ) as campaign_summary_daily_conversions_value_micros,
      cast( spend_in_micro_dollar as numeric ) as campaign_summary_daily_cost_micros,
      cast( impression_1 as numeric ) as campaign_summary_daily_impressions_unsaved,
      cast( impression_2 as numeric ) as campaign_summary_daily_impressions_saved,
   
      --timestamps
      cast( date as date ) as campaign_summary_daily_date,
      cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated

   from create_compound_key

),

combine_split_numbers as (

   select *,

   COALESCE(campaign_summary_daily_clicks_unsaved, 0)
      + COALESCE(campaign_summary_daily_clicks_saved, 0)
      AS campaign_summary_daily_clicks,

   COALESCE(campaign_summary_daily_impressions_unsaved, 0)
      + COALESCE(campaign_summary_daily_impressions_saved, 0)
      AS campaign_summary_daily_impressions


   from rename_and_cast

),

convert_cost_to_dollars as (

   select *,

   campaign_summary_daily_conversions_value_micros / 1000000 as campaign_summary_daily_conversions_value,
   campaign_summary_daily_cost_micros / 1000000 as campaign_summary_daily_cost,
   
   from combine_split_numbers

),

order_columns as (

   select

      -- natural keys
      campaign_summary_daily_natural_key,
      campaign_summary_daily_campaign_natural_key,

      -- strings
      campaign_summary_daily_connector_source,

      -- numbers
      campaign_summary_daily_clicks,
      campaign_summary_daily_conversions,
      campaign_summary_daily_conversions_value,
      campaign_summary_daily_cost,
      campaign_summary_daily_impressions,

      -- dates
      campaign_summary_daily_date,
      campaign_summary_daily_timestamp_replicated,

   from convert_cost_to_dollars

)

select * from order_columns