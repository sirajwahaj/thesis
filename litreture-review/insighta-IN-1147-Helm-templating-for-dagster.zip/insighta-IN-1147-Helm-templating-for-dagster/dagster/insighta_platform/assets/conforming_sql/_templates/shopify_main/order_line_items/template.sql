with source_order_line as (

  select * from {{ gcp_project_id_prod }}.shopify.order_line

),

filter_source as (

  select
    *
  from source_order_line
  where true
    and ifnull(price,0) > 0
    and ifnull(quantity,0) > 0

),

cast_and_rename as (
  
  select

    -- natural keys
    cast( id as string ) as order_line_item_natural_key,
    cast( order_id as string ) as order_natural_key,
    cast( concat(product_id,'-',variant_id) as string ) as sku_natural_key,

    -- numbers
    cast( quantity as numeric ) as order_line_quantity,
    cast( (price * quantity) as numeric ) as order_line_amount_total,

    -- timestamps
    cast( _fivetran_synced as timestamp ) as order_line_timestamp_replicated,

  from filter_source

)

select * from cast_and_rename