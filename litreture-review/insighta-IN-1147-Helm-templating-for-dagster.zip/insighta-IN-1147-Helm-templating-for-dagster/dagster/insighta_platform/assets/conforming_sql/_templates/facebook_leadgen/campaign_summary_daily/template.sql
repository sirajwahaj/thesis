with

source_campaign_summary_daily_cost_impressions_and_clicks as (

 select * from {{ gcp_project_id_prod }}.facebook_ads.basic_campaign

),

source_campaign_summary_daily_conversions as (

 select * from {{ gcp_project_id_prod }}.facebook_ads.basic_campaign_actions

),

campaign_select as (

 select distinct id, campaign_id from {{ gcp_project_id_prod }}.facebook_ads.ad_history

),

filter_conversions_to_purchases as (

 select * from source_campaign_summary_daily_conversions
 where action_type = 'purchase'

),
 
rename_and_cast_source_cost_impressions_and_clicks as (

 select 

  --natural keys
  cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,
  cast( account_id as string ) as campaign_summary_daily_account_natural_key,
  cast( _fivetran_id as string ) as campaign_summary_daily_fivetran_natural_key,

  --strings
  cast( 'facebook' as string ) as campaign_summary_daily_connector_source,

  --numbers
  cast( spend as numeric ) as campaign_summary_daily_cost,
  cast( inline_link_clicks as numeric ) as campaign_summary_daily_clicks,
  cast( impressions as numeric ) as campaign_summary_daily_impressions,

  --dates 
  cast( date as date ) as campaign_summary_daily_date,
  cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated

 from source_campaign_summary_daily_cost_impressions_and_clicks
 
),

rename_and_cast_source_conversions as (

 select 

  --natural keys
  cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,
  cast( _fivetran_id as string ) as campaign_summary_daily_fivetran_natural_key,

  --numbers
  cast( value as numeric ) as campaign_summary_daily_conversions,

  --dates
  cast( date as date ) as campaign_summary_daily_date,
  cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated

 from filter_conversions_to_purchases 

),

join_conversions as (

 select 
 
  rename_and_cast_source_cost_impressions_and_clicks.*,

  rename_and_cast_source_conversions.campaign_summary_daily_conversions as campaign_summary_daily_conversions

 from rename_and_cast_source_cost_impressions_and_clicks 

  left join rename_and_cast_source_conversions 

   using (campaign_summary_daily_campaign_natural_key, campaign_summary_daily_date)

),

hardcode_conversions_value as (

 select 

  join_conversions.*,

  cast(0 as numeric) as campaign_summary_daily_conversions_value

 from join_conversions 

),

create_natural_key as (

 select *,

   campaign_summary_daily_fivetran_natural_key
    || '-' || campaign_summary_daily_date
    || '-' || campaign_summary_daily_account_natural_key
    || '-' || campaign_summary_daily_campaign_natural_key
    as campaign_summary_daily_natural_key,

 from hardcode_conversions_value

),

order_columns as (

 select

     -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,
    
    -- strings
    campaign_summary_daily_connector_source,

    -- numbers
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,
    campaign_summary_daily_timestamp_replicated,

  from create_natural_key
  
)

select * from order_columns