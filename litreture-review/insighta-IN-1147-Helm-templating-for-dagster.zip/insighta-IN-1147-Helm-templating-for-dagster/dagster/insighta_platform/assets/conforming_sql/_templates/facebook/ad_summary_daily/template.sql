with

source_ad_summary_daily_cost_impressions_and_clicks as (

 select * from {{ gcp_project_id_prod }}.facebook_ads.basic_ad

),

source_ad_summary_daily_conversions as (

 select * from {{ gcp_project_id_prod }}.facebook_ads.basic_ad_actions

),

basic_ad_action_values as (

 select * from {{ gcp_project_id_prod }}.facebook_ads.basic_ad_action_values

),


filter_conversions_to_purchases as (

 select * from source_ad_summary_daily_conversions
 where action_type = 'purchase'

),

filter_conversions_value_to_purchases as (

 select * from basic_ad_action_values
 where action_type = 'purchase'

),

rename_and_cast_source_cost_impressions_and_clicks as (

 select 

  --natural keys
  cast( ad_id as string ) as ad_summary_daily_ad_natural_key,
  cast( account_id as string ) as ad_summary_daily_account_natural_key,
  cast( _fivetran_id as string ) as ad_summary_daily_fivetran_natural_key,

  --strings
  cast( 'facebook' as string ) as ad_summary_daily_connector_source,

  --numbers
  cast( spend as numeric ) as ad_summary_daily_cost,
  cast( inline_link_clicks as numeric ) as ad_summary_daily_clicks,
  cast( impressions as numeric ) as ad_summary_daily_impressions,

  --dates 
  cast( date as date ) as ad_summary_daily_date,
  cast( _fivetran_synced as timestamp ) as ad_summary_daily_timestamp_replicated

 from source_ad_summary_daily_cost_impressions_and_clicks
 
),

rename_and_cast_source_conversions as (

 select 

  --natural keys
  cast( ad_id as string ) as ad_summary_daily_ad_natural_key,
  cast( _fivetran_id as string ) as ad_summary_daily_fivetran_natural_key,

  --numbers
  cast( value as numeric ) as ad_summary_daily_conversions,

  --dates
  cast( date as date ) as ad_summary_daily_date,
  cast( _fivetran_synced as timestamp ) as ad_summary_daily_timestamp_replicated

 from filter_conversions_to_purchases 

),

rename_and_cast_source_conversions_value as (

 select 

  --natural keys
  cast( ad_id as string ) as ad_summary_daily_ad_natural_key,
  cast( _fivetran_id as string ) as ad_summary_daily_fivetran_natural_key,

  --numbers
  cast( value as numeric ) as ad_summary_daily_conversions_value,

  --dates
  cast( date as date ) as ad_summary_daily_date,
  cast( _fivetran_synced as timestamp ) as ad_summary_daily_timestamp_replicated

 from filter_conversions_value_to_purchases 

),

join_conversions as (

 select 
 
  rename_and_cast_source_cost_impressions_and_clicks.*,

  rename_and_cast_source_conversions.ad_summary_daily_conversions as ad_summary_daily_conversions

 from rename_and_cast_source_cost_impressions_and_clicks 

  left join rename_and_cast_source_conversions 

   using (ad_summary_daily_ad_natural_key, ad_summary_daily_date)

),

join_conversions_value as (

 select 

  join_conversions.*,

  rename_and_cast_source_conversions_value.ad_summary_daily_conversions_value as ad_summary_daily_conversions_value

 from join_conversions 

  left join rename_and_cast_source_conversions_value 

   using (ad_summary_daily_ad_natural_key, ad_summary_daily_date)

),

create_natural_key as (

 select *,

   ad_summary_daily_fivetran_natural_key
    || '-' || ad_summary_daily_date
    || '-' || ad_summary_daily_account_natural_key
    || '-' || ad_summary_daily_ad_natural_key
    as ad_summary_daily_natural_key,

 from join_conversions_value

),

order_columns as (

 select

     -- natural keys
    ad_summary_daily_natural_key,
    ad_summary_daily_ad_natural_key,
    
    -- strings
    ad_summary_daily_connector_source,

    -- numbers
    ad_summary_daily_clicks,
    ad_summary_daily_conversions,
    ad_summary_daily_conversions_value,
    ad_summary_daily_cost,
    ad_summary_daily_impressions,

    -- dates
    ad_summary_daily_date,
    ad_summary_daily_timestamp_replicated,

  from create_natural_key
  
)

select * from order_columns