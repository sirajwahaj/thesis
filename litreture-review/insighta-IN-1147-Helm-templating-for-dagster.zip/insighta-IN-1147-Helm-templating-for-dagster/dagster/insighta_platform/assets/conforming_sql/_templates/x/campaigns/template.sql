with

source_campaigns as (

  select * from {{ gcp_project_id_prod }}.twitter_ads.campaign_history

),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast( id as string ) as campaign_natural_key,

    -- strings
    cast( 'x' as string ) as campaign_connector_source,
    cast( 'social' as string ) as campaign_medium_name,
    cast( name as string ) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- dates
    cast( updated_at as timestamp ) as campaign_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as campaign_timestamp_replicated,
  
  from source_campaigns

)

select * from rename_cast_and_order_columns