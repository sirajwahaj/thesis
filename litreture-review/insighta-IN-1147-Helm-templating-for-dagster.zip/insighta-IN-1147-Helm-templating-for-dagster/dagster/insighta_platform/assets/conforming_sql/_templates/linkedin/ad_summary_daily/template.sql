with

source_ad_summary_daily_non_conversions_metrics as (

  select * from {{ gcp_project_id_prod }}.linkedin_ads.ad_analytics_by_creative

),

create_compound_key_non_conversions_metrics as (

  select *,

    day
      || '-' || creative_id
     as compound_key,

  from source_ad_summary_daily_non_conversions_metrics

),


rename_cast_and_order_columns_non_conversions_metrics as (

  select

    -- natural keys
    cast( compound_key as string ) as ad_summary_daily_natural_key,
    cast( creative_id as string ) as ad_summary_daily_ad_natural_key,

    -- strings
    'linkedin' as ad_summary_daily_connector_source,

    -- metrics
    cast( clicks as numeric ) as ad_summary_daily_clicks,
    cast( external_website_conversions as numeric ) as ad_summary_daily_conversions,
    cast( conversion_value_in_local_currency as numeric ) as ad_summary_daily_conversions_value,
    cast( cost_in_local_currency as numeric ) as ad_summary_daily_cost,
    cast( impressions as numeric ) as ad_summary_daily_impressions,


    -- dates
    cast( day as date ) as ad_summary_daily_date,
    cast( _fivetran_synced as timestamp ) as ad_summary_daily_timestamp_replicated,

  from create_compound_key_non_conversions_metrics

),

order_columns as (

  select

    -- natural keys
    ad_summary_daily_natural_key,
    ad_summary_daily_ad_natural_key,

    -- strings
    ad_summary_daily_connector_source,

    -- numbers
    ad_summary_daily_clicks,
    ad_summary_daily_conversions,
    ad_summary_daily_conversions_value,
    ad_summary_daily_cost,
    ad_summary_daily_impressions,

    -- dates
    ad_summary_daily_date,
    ad_summary_daily_timestamp_replicated,

  from rename_cast_and_order_columns_non_conversions_metrics

)

select * from order_columns