with source_products as (

  select * from {{ gcp_project_id_prod }}.shopify.product

),

source_product_variants as (

  select * from {{ gcp_project_id_prod }}.shopify.product_variant 

),

add_parent_to_variants as (

  select 
    concat(source_products.id,'-',source_product_variants.id) as id,
    source_products.title,
    source_products.product_type,
    source_product_variants.title as variant_title,
  from source_products
  left join source_product_variants
    on source_products.id = source_product_variants.product_id

),

product_name_filter_source as (

  select
    *,
    cast( 
      lower(
        regexp_replace(
          regexp_replace(
            trim(
              regexp_replace(title, r'[^\x20-\x7E]+', '')
            ),r'\s+', ' '
          ),r' ', '_'
        )
      ) AS string 
    ) title_key,
  from add_parent_to_variants
  where true
    and title is not null
    and title <> ""

),

product_type_filter_source as (

  select
    *,
    cast(
      lower(
        regexp_replace(
          regexp_replace(
            trim(
              regexp_replace(product_type, r'[^\x20-\x7E]+', '')
            ),r'\s+', ' '
          ),r' ', '_'
        )
      ) AS string 
    ) product_type_key,
  from add_parent_to_variants
  where true
    and product_type is not null
    and product_type <> ""

),

product_variant_filter_source as (

  select
    *,
    cast(
      lower(
        regexp_replace(
          regexp_replace(
            trim(
              regexp_replace(concat(title,'_',variant_title), r'[^\x20-\x7E]+', '')
            ),r'\s+', ' '
          ),r' ', '_'
        )
      ) as string 
    ) variant_title_key,
  from add_parent_to_variants
  where true
    and title is not null
    and title <> ""

),

product_name_cast_and_rename as (

  select 
    distinct
    cast( id as string ) 
      || '_' || cast( 1 as string ) 
      || '_' || title_key 
      as bridge_natural_key,
    cast( id as string ) as sku_natural_key,
    cast( 1 as string ) 
      || '_' || title_key
      as sku_attribute_value_natural_key,
  from product_name_filter_source

),

product_type_cast_and_rename as (

  select 
    distinct
    cast( id as string ) 
      || '_' || cast( 2 as string ) 
      || '_' || product_type_key 
      as bridge_natural_key,
    cast( id as string ) as sku_natural_key,
    cast( 2 as string ) 
      || '_' || product_type_key 
      as sku_attribute_value_natural_key,
  from product_type_filter_source

),

product_variant_cast_and_rename as (

  select 
    distinct
    cast( id as string ) 
      || '_' || cast( 3 as string ) 
      || '_' || variant_title_key 
      as bridge_natural_key,
    cast( id as string ) as sku_natural_key,
    cast( 3 as string ) 
      || '_' || variant_title_key
      as sku_attribute_value_natural_key,
  from product_variant_filter_source

),

union_cast_and_rename as (

  select * from product_name_cast_and_rename

  union all

  select * from product_type_cast_and_rename

  union all

  select * from product_variant_cast_and_rename
  
)

select * from union_cast_and_rename