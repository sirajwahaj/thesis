-- Facebook Ads → ads table with text + permalink
with

source_ads as (
  select *
  from {{ gcp_project_id_prod }}.facebook_ads.ad_history
),

with_creatives as (
  select
    a.*,
    c.title         as creative_title,
    c.body          as creative_body,
    c.image_hash    as creative_image_hash,
    cast(c.video_id as string) as creative_video_id
  from source_ads a
  left join {{ gcp_project_id_prod }}.facebook_ads.creative_history c
    on a.creative_id = c.id
),

with_media as (
  select
    wc.*,
    ih.permalink_url  as image_permalink_url,
    vh.permalink_url  as video_permalink_url
  from with_creatives wc
  left join {{ gcp_project_id_prod }}.facebook_ads.ad_image_history ih
    on wc.creative_image_hash = ih.hash
  left join {{ gcp_project_id_prod }}.facebook_ads.ad_video_history vh
    on wc.creative_video_id = cast(vh.id as string)
),

rename_cast_and_order_columns as (
  select
    -- natural keys
    cast(id as string) as ad_natural_key,

    -- strings
    cast('facebook' as string) as ad_connector_source,
    cast('social'   as string) as ad_medium_name,
    cast(name       as string) as ad_name,

    -- NEW: ad_text (Title + Body if present)
    REGEXP_REPLACE(
      trim(concat(
        IF(creative_title is not null and creative_title != '', concat('Title: ', creative_title, ' '), ''),
        IF(creative_body  is not null and creative_body  != '', concat('Body: ',  creative_body), '')
      )),
      r'\s+', ' '
    ) as ad_text,

    -- NEW: ad_permalink (prefer video, then image)
    COALESCE(video_permalink_url, image_permalink_url) as ad_url,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- dates
    cast(updated_time     as timestamp) as ad_timestamp_updated,
    cast(_fivetran_synced as timestamp) as ad_timestamp_replicated

  from with_media
)

select * from rename_cast_and_order_columns
