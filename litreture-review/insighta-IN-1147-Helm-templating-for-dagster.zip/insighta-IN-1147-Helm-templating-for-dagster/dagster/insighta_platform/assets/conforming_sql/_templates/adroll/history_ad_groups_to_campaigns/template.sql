
with 

source_adgroups as (

  select * from {{ gcp_project_id_prod }}.adroll.all_adgroups

),


valid_timestamp_start_end as (

  select 
  
    eid,
    campaign,
    -- first “running” date  → assignment timestamp @ 00:00:00 UTC
    -- campaigns were never active hence the null timestamps do not have a start date
    timestamp(
      min(if(status = 'running', date(date), null))
    ) as validity_timestamp_start,

    -- first non-running date → removal timestamp @ 00:00:00 UTC
    timestamp(
      min(if(status <> 'running', date(date), null))
    ) as validity_timestamp_end
  
  from source_adgroups
  group by all

),

create_ad_history_key as (

  select

    *,
    concat(eid,campaign) as history_key

  from valid_timestamp_start_end

),

rename_cast_and_order_columns as (

  select

    -- natural keys
    cast(history_key as string) as history_key,
    cast( eid as string ) as ad_group_natural_key,
    cast( campaign as string ) as campaign_natural_key,

    --timestamps
    validity_timestamp_start,
    validity_timestamp_end
  
  from create_ad_history_key

)

select * from  rename_cast_and_order_columns


