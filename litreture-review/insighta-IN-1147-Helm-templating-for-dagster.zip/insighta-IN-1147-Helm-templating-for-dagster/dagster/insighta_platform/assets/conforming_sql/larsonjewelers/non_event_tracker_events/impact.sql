with

impact_info as (

  select * from larsonjewelers.impact.action_event
  qualify row_number() over (partition by id order by _fivetran_synced desc) = 1


),

source_orders as (

  select * from larsonjewelers.shopify.order

),

extract_location as (

  select *,
    case 
      when( lower( source_orders.billing_address_country_code )  = 'us' )
      then regexp_extract( source_orders.billing_address_zip, r'^\d{5}' )
      else source_orders.billing_address_zip
      end as postal_code,
  from source_orders

),

rename_cast_and_order_columns as (

  select 

    -- natural keys
    cast (impact_info.id as string ) as non_event_tracker_event_natural_key,
    cast (impact_info.campaign_id as string ) as non_event_tracker_event_campaign_natural_key,
    lower( cast( billing_address_country_code as string ) ) as non_event_tracker_event_country_code,

    --strings
    cast( 'impact' as string ) as non_event_tracker_event_connector_source,
    cast( extract_location.email as string ) as non_event_tracker_event_email_address,
    cast( 'affiliate' as string ) as non_event_tracker_event_medium_name,
    cast( 'affiliate link click' as string ) as non_event_tracker_event_name,
    cast( browser_ip as string ) as non_event_tracker_event_ip_address,
    cast( postal_code as string ) as non_event_tracker_event_postal_code,

    -- numbers
    cast( impact_info.client_cost as numeric ) as non_event_tracker_event_cost,

    --datetime
    cast( impact_info.referring_date as timestamp ) as non_event_tracker_event_timestamp,
    cast( impact_info._fivetran_synced as timestamp ) as non_event_tracker_event_timestamp_replicated,

  from impact_info

    inner join extract_location 
    
      on cast(impact_info.o_id as string) =  cast(extract_location.order_number as string)

)

select * from rename_cast_and_order_columns
