with 

source_campaigns as (

  select * from larsonjewelers.impact.action_event
  qualify row_number() over (partition by id order by _fivetran_synced desc) = 1

  
),

rename_cast_and_order_columns as (

  select distinct
    
      -- natural keys
    cast(campaign_id as string) as campaign_natural_key,

      -- strings
    cast( 'impact' as string ) as campaign_connector_source,
    cast( 'affiliate' as string ) as campaign_medium_name,
    cast( 'impact' as string ) as campaign_name,

    --timestamps
    cast(referring_date as timestamp) as campaign_timestamp_updated,
    cast(_fivetran_synced as timestamp ) as campaign_timestamp_replicated,
    
  from source_campaigns

)

select * from rename_cast_and_order_columns
