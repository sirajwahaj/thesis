with

--start magento orders--
shopify_order as (

  select * from larsonjewelers.shopify.order

),

magento_orders as (

  select * from larsonjewelers.fileshare.orders_historic_magento

),

create_shopify_join_id as (

  SELECT 
    CAST(id AS STRING) AS order_natrual_key,  
    cast(substr(name, 1, 11) as string) as join_id,
    lower(cast(email as string)) as email,
    shopify_order.billing_address_country_code,
    case 
      when(
        lower( shopify_order.billing_address_country_code )  = 'us'
      )
      then  regexp_extract( shopify_order.billing_address_zip, r'^\d{5}' )
      else shopify_order.billing_address_zip
      end as postal_code,
      shopify_order.browser_ip
  FROM shopify_order
  where 1 =1

),

join_magento_orders AS (
SELECT 
    create_shopify_join_id.order_natrual_key,
    cast( null as string ) as order_user_identifier_application,
    cast( null as string ) as order_user_identifier_fingerprint,
    cast( null as string ) as order_user_identifier_cart_token,
    cast( null as string ) as order_user_identifier_server_side_cookie,
    cast( null as string ) as order_user_identifier_client_side_cookie,

    'shopify' as order_connector_source,

    lower( cast( create_shopify_join_id.billing_address_country_code as string ) ) as country_code,
    cast( email as string ) as order_email_address,
    cast( browser_ip as string ) as ip_address,
    cast( postal_code as string ) postal_code,
    cast( magento_orders.grand_total as numeric ) as order_amount_total,
    timestamp(magento_orders.created_at) as created_at,
    cast( null as timestamp ) as order_timestamp_replicated,
FROM magento_orders
LEFT JOIN create_shopify_join_id 
ON CAST(create_shopify_join_id.join_id AS STRING) = CAST(magento_orders.increment_id AS STRING)


),

filter_historic_orders as (

  select * 
  from join_magento_orders
  where created_at < timestamp('2024-01-15') --filter to when the data breaks

),

--end magento orders--

--start shopify orders--

extract_nested_note_attributes as (

    select

        shopify_order.*,
        case when( lower( shopify_order.billing_address_country_code )  = 'us' ) then  regexp_extract( shopify_order.billing_address_zip, r'^\d{5}' )
        else shopify_order.billing_address_zip
        end as postal_code,
        
        max(case when json_extract_scalar( unnested_note_attributes , '$.name') = 'network_userid' then json_extract_scalar( unnested_note_attributes , '$.value') end) as network_userid,
        max(case when json_extract_scalar( unnested_note_attributes , '$.name') = 'domain_userid' then json_extract_scalar( unnested_note_attributes , '$.value') end) as domain_userid,
    
    from shopify_order

        left join

            unnest(json_extract_array(  shopify_order.note_attributes  )) as  unnested_note_attributes
    
    group by all

),

rename_cast_and_order_columns as (

  select

    -- natural keys - regular
    cast( id as string ) as order_natural_key,

    -- natural keys - identity resolution
    cast( null as string ) as order_user_identifier_application,
    cast( cart_token as string ) as order_user_identifier_cart_token,
    cast( null as string ) as order_user_identifier_fingerprint,
    cast( network_userid as string ) as order_user_identifier_server_side_cookie,
    cast( domain_userid as string ) as order_user_identifier_client_side_cookie,

    -- strings
    'shopify' as order_connector_source,
    lower( cast( billing_address_country_code as string ) ) as order_country_code,
    cast( email as string ) as order_email_address,
    cast( browser_ip as string ) as order_ip_address,
    cast( postal_code as string ) order_postal_code,

    -- numbers
    cast( current_total_price as numeric ) as order_amount_total,

    -- timestamps
    cast( created_at as timestamp ) as order_timestamp,
    cast( _fivetran_synced as timestamp ) as order_timestamp_replicated,
  
  from extract_nested_note_attributes

),

filter_to_current_shopify as (

  SELECT *
  FROM rename_cast_and_order_columns
  WHERE CAST(order_timestamp AS DATE) >= DATE('2024-01-15') --filter to when the data breaks

),

--end shopify orders--

--join magento and shopify orders -- 
union_historic_and_current as (

  select * from filter_to_current_shopify

  union all

  select * from filter_historic_orders

),

filter_out_null_order_natural_keys_and_zero_order_value as (

  select 
  *
  from union_historic_and_current
  where 1=1
  and order_amount_total > 0 
  and order_natural_key is not null 
)

select * from filter_out_null_order_natural_keys_and_zero_order_value
order by 5 desc
