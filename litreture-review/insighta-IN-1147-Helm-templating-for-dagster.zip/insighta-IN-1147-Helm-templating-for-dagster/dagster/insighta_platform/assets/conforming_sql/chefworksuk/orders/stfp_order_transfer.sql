with

source_orders as (

  select * FROM chefworks-429121.analytics_ftp.chefworks_ftp_destination_tables__orders_uk_1__16__file_replication

),

snowplow_events as (
  
  select * from {{ gcp_project_id }}.{{ bigquery_dataset }}_pre_conforming.pc_dispatch__snowcatcloud_events

),

unnest_location as (

  SELECT *,
    lower( location.country.iso_code ) country_code,
    case 
      when(
        lower( location.country.iso_code ) = 'us'
      )
      then regexp_extract(location.postal.code, r'^\d{5}')
      else location.postal.code
      end as post_code_stg
  from snowplow_events,
  UNNEST (contexts_com_dbip_location_1_0_0) AS location

),

standardize_location as (

  select *,
    last_value(post_code_stg ignore nulls) over (
      partition by event_id
      order by load_tstamp
      rows between unbounded preceding and unbounded following
    ) as postal_code
  from unnest_location

),

filter_to_specified_shop_and_remove_canceled_orders as (

    select

        source_orders.*,
    
    from source_orders
    where website_id = '7' --chefworks.co.uk
      and order_status != 'canceled'
      and cast(increment_id as string) like 'UKC%'

),

cast_and_rename_stfp_order_transfer_orders as (

  select

    -- natural keys - regular
    cast( increment_id as string ) as order_natural_key,
    cast( customer_id as string ) as contact_pk,

    -- natural keys - identity resolution
    cast( null as string ) as order_user_identifier_application,
    cast( null as string ) as order_user_identifier_fingerprint,
    cast( null as string ) as order_user_identifier_cart_token,

    -- strings
    'stfp_order_transfer' as order_connector_source,
    cast( order_email_address as string ) as order_email_address,
CAST(
  CASE
    WHEN CUSTOM_CW_CUSTOMER_PRICING = "" THEN "D2C"
    WHEN CUSTOM_CW_CUSTOMER_PRICING = "B2C" THEN "D2C"
    ELSE IFNULL(CUSTOM_CW_CUSTOMER_PRICING, "D2C")
  END
AS STRING) AS order_type,

    -- numbers
    cast( grand_total as numeric ) as order_amount_total,

    -- timestamps
   TIMESTAMP(created_at) AS order_timestamp,

    cast( _insighta_replication_timestamp as timestamp ) as order_timestamp_replicated,

  from filter_to_specified_shop_and_remove_canceled_orders

),

cast_and_rename_filter_snowplow_events as (

  select 
  
    cast(app_id as string) as organization_identifier,
    cast(derived_tstamp as timestamp) as event_timestamp,
    cast(tr_orderid as string) as event_join_order_natural_key,
    cast(null as string) as event_user_identifier_application,
    cast(null as string) as event_user_identifier_fingerprint,
    cast(network_userid as string) as event_user_identifier_server_side_cookie,
    cast(domain_userid as string) as event_user_identifier_client_side_cookie,
    lower( cast(country_code as string) ) country_code,
    cast( postal_code as string ) postal_code,
    cast( user_ipaddress as string ) as order_ip_address,
    
  from standardize_location

),

deduplicate_to_snowplow_first_order_event as (

  select 
    *
  from cast_and_rename_filter_snowplow_events
  qualify row_number() over(partition by event_join_order_natural_key order by event_timestamp asc) = 1 

),

join_orders_and_identifiers_and_select_relevant_fields as (

  select 
  
    cast_and_rename_stfp_order_transfer_orders.order_natural_key,
    deduplicate_to_snowplow_first_order_event.event_user_identifier_application as order_user_identifier_application,
    deduplicate_to_snowplow_first_order_event.event_join_order_natural_key as order_user_identifier_cart_token,
    deduplicate_to_snowplow_first_order_event.event_user_identifier_fingerprint as order_user_identifier_fingerprint,
    deduplicate_to_snowplow_first_order_event.event_user_identifier_server_side_cookie as order_user_identifier_server_side_cookie,
    deduplicate_to_snowplow_first_order_event.event_user_identifier_client_side_cookie as order_user_identifier_client_side_cookie,
    cast('web' as string) as order_channel,
    cast_and_rename_stfp_order_transfer_orders.order_connector_source,
    country_code as order_country_code,
    cast_and_rename_stfp_order_transfer_orders.order_email_address,
    order_ip_address as order_ip_address,
    cast( 'regional' as string ) as order_mmm_geo_grain,
    cast_and_rename_stfp_order_transfer_orders.order_natural_key as order_natural_key_customer_facing,
    cast( postal_code as string ) as order_postal_code,
    cast('magento' as string) as order_sub_channel,
    order_type,
    cast( true as boolean ) as is_directly_attributable,
    cast_and_rename_stfp_order_transfer_orders.order_amount_total,
    cast_and_rename_stfp_order_transfer_orders.order_timestamp,
    cast_and_rename_stfp_order_transfer_orders.order_timestamp_replicated,

  from cast_and_rename_stfp_order_transfer_orders
  left join deduplicate_to_snowplow_first_order_event
    on deduplicate_to_snowplow_first_order_event.event_join_order_natural_key = cast_and_rename_stfp_order_transfer_orders.order_natural_key

)

select * from join_orders_and_identifiers_and_select_relevant_fields