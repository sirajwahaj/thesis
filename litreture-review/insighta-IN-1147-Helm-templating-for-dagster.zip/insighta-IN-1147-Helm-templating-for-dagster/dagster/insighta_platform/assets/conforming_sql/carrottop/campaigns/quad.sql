with 

source_catalog_mailers as (

 select * from carrottop-416504.email.quad_catalog_mailer

),

filter_invalid_timestamp as (

  select * from source_catalog_mailers
  where in_home_date != '#N/A'

),

create_unique_campaigns as (

  select 
    *,
    concat(keycode,' ', campaign) as concat_campaign_description
  from filter_invalid_timestamp

),

cast_and_rename as (

  select 
    -- natural keys
    cast(keycode as string) as campaign_natural_key,
    
    -- strings
    cast('quad' as string) as campaign_connector_source,
    cast('direct mailer' as string) as campaign_medium_name,
    cast(concat_campaign_description as string) as campaign_name,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- timestamps
    max(timestamp(in_home_date)) campaign_timestamp_updated,
    max(timestamp(_modified)) as campaign_timestamp_replicated,
  from create_unique_campaigns
  group by all

)

select * from cast_and_rename