with 

source_catalog_mailers as (

  select * from carrottop-416504.email.quad_catalog_mailer 
  qualify row_number() over (partition by keycode order by _fivetran_synced desc) = 1

),

source_conversion_matchback as (

  select 
    * 
  from carrottop-416504.email.quad_conversion_matchback
  qualify row_number() over (partition by order_id order by _fivetran_synced desc) = 1
  
),

conversion_matchback_filter_to_carrottop_orders as (

  select 
    *,
   from source_conversion_matchback
  where 1=1
    and amount is not null
    and quantity is not null
    and right(order_id,2) = '-C' --this needs to be uncommented and we need to filter the quad_catalog_mailer to only Carrot top campaigns 
    and amount != '#N/A'
    and quantity != '#N/A'

),

conversion_matchabck_map_unassigned_keycode as (

  select 
    *,
    case when keycode = 'UNASSIGNED' then 'GS2504B' else keycode end as enhanced_keycode,
  from conversion_matchback_filter_to_carrottop_orders

),

cast_key_and_in_home_date as (

  select 
    keycode,
    cast( in_home_date as timestamp ) as in_home_date
  from source_catalog_mailers
  where in_home_date != '#N/A'

),

join_timestamp_on_conversion_matchback as (

  select 
    *
  from conversion_matchabck_map_unassigned_keycode
  left join cast_key_and_in_home_date
  using (keycode) 

),

filter_out_null_in_home_date as (

  select
    *
  from join_timestamp_on_conversion_matchback

),

create_distinct_event_key as (

  select 
    *,
    cast(substr(order_id, 1, 10) as string) as event_order_natural_key,
  from filter_out_null_in_home_date
  

),

source_netsuite_orders as (

  {{ ref('orders', 'netsuite') }}

),

join_conversion_email as (

  select
    create_distinct_event_key.*,
    source_netsuite_orders.order_timestamp,
    source_netsuite_orders.order_email_address as order_email_address,
    source_netsuite_orders.order_ip_address,
    source_netsuite_orders.order_postal_code,
    source_netsuite_orders.order_country_code,
  from create_distinct_event_key
  left outer join source_netsuite_orders
    on create_distinct_event_key.event_order_natural_key = source_netsuite_orders.order_natural_key

),

cast_and_rename as (

  select 

    concat(event_order_natural_key, coalesce(timestamp(in_home_date), timestamp_trunc(order_timestamp, day))) as non_event_tracker_event_natural_key,
    cast(keycode as string) as non_event_tracker_event_campaign_natural_key,
    cast(order_country_code as string) as non_event_tracker_event_country_code,
    cast('quad' as string) as non_event_tracker_event_connector_source,
    cast(lower(order_email_address) as string) as non_event_tracker_event_email_address,
    cast('direct mailer' as string) as non_event_tracker_event_medium_name,
    cast('direct mailer sent' as string) as non_event_tracker_event_name,
    cast( order_ip_address as string ) as non_event_tracker_event_ip_address,
    cast( order_postal_code as string ) as non_event_tracker_event_postal_code,
    cast( 1 as numeric ) as non_event_tracker_event_cost, -- set to 1 because before IN-844 it was calculated in the campaign_summary_daily model like this: cast( 1/(count(*) over (partition by campaign_summary_daily_natural_key)) as numeric) as ratio_cost
    coalesce(timestamp(in_home_date), timestamp_trunc(order_timestamp, day)) as non_event_tracker_event_timestamp,
    timestamp(_fivetran_synced) as non_event_tracker_event_timestamp_replicated,

  from join_conversion_email

)

select * from cast_and_rename
where non_event_tracker_event_timestamp is not null