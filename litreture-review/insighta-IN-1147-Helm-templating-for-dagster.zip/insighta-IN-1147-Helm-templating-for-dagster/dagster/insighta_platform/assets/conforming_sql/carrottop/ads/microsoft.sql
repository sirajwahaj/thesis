with

source_ads as (

  select * from carrottop-416504.microsoft_ads.ad_history

),

source_cti_ads as (

  select distinct ad_id from carrottop-416504.microsoft_ads.ad_performance_daily_report
  where account_id = 556037

),

filter_to_cti_ads as (

  select sa.*
  from source_ads sa
  inner join source_cti_ads scti
    on sa.id = scti.ad_id

),

rename_and_order_columns as (

  select

    -- natural keys
    cast( id as string ) as ad_natural_key,

    -- strings
    cast( 'bing' as string ) as ad_connector_source,
    cast( 'search' as string ) as ad_medium_name,
    cast( title as string ) as ad_name,
    cast( null as string ) as ad_text,
    cast( null as string ) as ad_url,

    -- booleans
    cast( true as boolean ) as is_directly_attributable,

    -- dates
    cast( modified_time as timestamp ) as ad_timestamp_updated,
    cast( _fivetran_synced as timestamp ) as ad_timestamp_replicated
  
  from filter_to_cti_ads

)

select * from rename_and_order_columns