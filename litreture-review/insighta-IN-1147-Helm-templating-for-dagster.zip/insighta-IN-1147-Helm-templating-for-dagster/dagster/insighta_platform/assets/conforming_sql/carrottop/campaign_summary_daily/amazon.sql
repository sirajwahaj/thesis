with

source_campaign_summary_daily_sponsored_paid as (

  select * from carrottop-416504.amazon_ads.campaign_level_report

),

source_campaign_summary_daily_sponsored_brand as (

  select * from carrottop-416504.amazon_ads.sb_campaign_report

),

create_compound_key_sponsored_paid as (

  select *,

    date
      || '-' || campaign_id
      as compound_key,
  
  from source_campaign_summary_daily_sponsored_paid

),

create_compound_key_sponsored_brand as (

  select *,

    report_date
      || '-' || campaign_id
      as compound_key,
  
  from source_campaign_summary_daily_sponsored_brand

),

rename_and_cast_source_sponsored_paid as (

  select

    -- natural keys
    cast( compound_key as string ) as campaign_summary_daily_natural_key,
    cast( campaign_id as string ) as campaign_summary_daily_campaign_natural_key,

    -- strings
    'sponsored paid' as campaign_summary_daily_ad_type,

    -- numbers
    cast( clicks as numeric ) as campaign_summary_daily_clicks,
    cast( purchases_14_d as numeric ) as campaign_summary_daily_conversions,
    cast( sales_14_d as numeric ) as campaign_summary_daily_conversions_value,
    cast( spend as numeric ) as campaign_summary_daily_cost,
    cast( impressions as numeric ) as campaign_summary_daily_impressions,

    -- dates
    cast( date as date ) as campaign_summary_daily_date,
    cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated,

  from create_compound_key_sponsored_paid

),

rename_and_cast_source_sponsored_brand as (

  select

    -- natural keys
    cast( compound_key as string ) as campaign_summary_daily_natural_key,
    cast( campaign_id as string )  as campaign_summary_daily_campaign_natural_key,

    -- strings
    'sponsored brand' as campaign_summary_daily_ad_type,

    -- numbers
    cast( clicks as numeric ) as campaign_summary_daily_clicks,
    cast( attributed_conversions_14_d as numeric ) as campaign_summary_daily_conversions,
    cast( attributed_sales_14_d as numeric ) as campaign_summary_daily_conversions_value,
    cast( cost as numeric ) as campaign_summary_daily_cost,
    cast( impressions as numeric ) as campaign_summary_daily_impressions,

    -- dates
    cast( report_date as date ) as campaign_summary_daily_date,
    cast( _fivetran_synced as timestamp ) as campaign_summary_daily_timestamp_replicated,

  from create_compound_key_sponsored_brand

),

union_together_the_different_ad_type_sources as (

  select * from rename_and_cast_source_sponsored_paid 

  union all

  select * from rename_and_cast_source_sponsored_brand 

),

add_connector_source as (

  select *,

    'amazon' as campaign_summary_daily_connector_source

  from union_together_the_different_ad_type_sources

),

select_and_order_columns as (

  select

    -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,

    -- strings
    campaign_summary_daily_connector_source,

    -- numbers
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,
    campaign_summary_daily_timestamp_replicated,

  from add_connector_source

)

select * from select_and_order_columns