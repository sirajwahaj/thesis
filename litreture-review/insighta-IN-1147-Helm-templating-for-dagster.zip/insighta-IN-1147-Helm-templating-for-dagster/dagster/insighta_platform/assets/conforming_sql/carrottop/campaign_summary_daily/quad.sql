with 

source_catalog_mailers as (

  select * from carrottop-416504.email.quad_catalog_mailer 
  qualify row_number() over (partition by keycode order by _fivetran_synced desc) = 1

),

source_conversion_matchback as (

  select 
    * 
  from carrottop-416504.email.quad_conversion_matchback
  qualify row_number() over (partition by order_id order by _fivetran_synced desc) = 1
  
),

filter_to_carrottop_orders as (

  select 
    *,
   from source_conversion_matchback
  where 1=1
    and amount is not null
    and quantity is not null
    and right(order_id,2) = '-C'
    and amount != '#N/A'
    and quantity != '#N/A'

),

enhance_keycode as (

  select 
    *,
    case when keycode = 'UNASSIGNED' then 'GS2504B' else keycode end as enhanced_keycode,
  
  from filter_to_carrottop_orders 

),

aggregate_conversions_by_keycode_timestamp as (

  select
    -- date(createddate) as conversion_date,
    enhanced_keycode,
    sum(cast(amount as numeric)) as campaign_summary_daily_conversions_value,
    sum(cast(quantity as numeric)) as campaign_summary_daily_conversions

  from enhance_keycode
  group by all
),

-- clicks, impressions, cost
filter_catalog_invalid_timestamp as (

  select * from source_catalog_mailers
  where in_home_date != '#N/A'

),

cast_key_and_in_home_date as (

  select 
    -- natural keys
    cast( concat(keycode, ' ', date(in_home_date)) as string ) as campaign_summary_daily_natural_key,
    cast( keycode as string ) as campaign_summary_daily_campaign_natural_key,
    date( in_home_date ) as campaign_summary_daily_date,
    timestamp( in_home_date ) as campaign_summary_daily_timestamp_replicated,
    sum( cast( mailed_qty as numeric ) ) as campaign_summary_daily_clicks,
    sum( cast (mailed_qty as numeric ) ) as campaign_summary_daily_impressions,
    sum( cast( mailed_qty as numeric ) * cast( total_catalog_cost_piece as numeric )) as campaign_summary_daily_cost,
  from filter_catalog_invalid_timestamp
  group by all

),

left_join_conversions_on_impressions_clicks_spend as (

  select * 
  from cast_key_and_in_home_date
  left join aggregate_conversions_by_keycode_timestamp
  -- on cast_key_and_in_home_date.campaign_summary_daily_date = aggregate_conversions_by_keycode_timestamp.conversion_date
  on cast_key_and_in_home_date.campaign_summary_daily_campaign_natural_key = aggregate_conversions_by_keycode_timestamp.enhanced_keycode

),

select_and_sort_columns as (

  select 

    -- natural keys
    campaign_summary_daily_natural_key,
    campaign_summary_daily_campaign_natural_key,
    
    -- strings
    cast( 'quad' as string ) as campaign_summary_daily_connector_source,

    -- numbers
    campaign_summary_daily_clicks,
    campaign_summary_daily_conversions,
    campaign_summary_daily_conversions_value,
    campaign_summary_daily_cost,
    campaign_summary_daily_impressions,

    -- dates
    campaign_summary_daily_date,

    -- timestamps 
    campaign_summary_daily_timestamp_replicated,

  from left_join_conversions_on_impressions_clicks_spend

)

select * from select_and_sort_columns