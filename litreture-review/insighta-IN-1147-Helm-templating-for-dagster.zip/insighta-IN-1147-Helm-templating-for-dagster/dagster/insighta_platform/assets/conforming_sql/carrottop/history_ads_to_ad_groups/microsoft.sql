with 

ad_source as (

  select * from carrottop-416504.microsoft_ads.ad_history

),

source_cti_ads as (

  select distinct ad_id from carrottop-416504.microsoft_ads.ad_performance_daily_report
  where account_id = 556037

),

filter_to_cti_ads as (

  select sa.*
  from ad_source sa
  inner join source_cti_ads scti
    on sa.id = scti.ad_id

),

create_history_key as (

  select

    *,
    concat(id,ad_group_id) as history_key

  from filter_to_cti_ads

),

cast_rename_and_order as (

  select 
  
    cast( history_key as string ) as history_key,
    cast( id as string ) as ad_natural_key,
    cast( ad_group_id as string ) as ad_group_natural_key,
    cast( null as timestamp ) as validity_timestamp_start,
    cast( null as timestamp ) as validity_timestamp_end,

  from create_history_key 

)

select * from cast_rename_and_order