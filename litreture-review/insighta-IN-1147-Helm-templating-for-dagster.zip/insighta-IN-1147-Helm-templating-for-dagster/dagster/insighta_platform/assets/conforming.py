# standard library imports
import os
from hashlib import md5
from datetime import datetime, timedelta, timezone
from typing import Generator, List, Optional
import re
from jinja2 import Template

# third-party imports
import dagster as dg
from dagster_gcp import BigQueryResource
import pandas as pd
import yaml

# local imports
from ..constants.core import CONSTANT_BIGQUERY_DATASET
from ..resources.supabase import organizations_df
from ..utils.datawarehouse_manager import (
    safe_ensure_dataset_exists,
    execute_query,
)
from ..utils.dbml import (
    generate_placeholder_sql_from_dbml_schema,
    parse_dbml_schema,
)

physical_model_dbml_schema: dict = parse_dbml_schema(dg.file_relative_path(__file__, "conforming_sql/physical_model_sources.dbml"))

def query_last_replicated_timestamp(
    client: BigQueryResource,
    table_identifier: str,
    column_name_timestamp_replicated: str,
    ) -> Optional[datetime]:
    """Get the last replicated timestamp from the table."""
    sql = f"select max({column_name_timestamp_replicated}) from {table_identifier}"
    row = next(client.query(sql).result(), None)

    timestamp_value = None
    if row and row[0]:
        try:
            timestamp_value = row[0].replace(tzinfo=timezone.utc) if row and row[0] else None
        except TypeError:
            # needed for belleandjune's conversions (bigcommerce) to get around "TypeError: str.replace() takes no keyword arguments". For context, row equalled: Row(('2025-04-02 05:51:53',), {'f0_': 0})
            timestamp_value = datetime.strptime(row[0], "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc) if row and row[0] else None

    return timestamp_value

def extract_column_name_based_on_end_of_string(
    sql_definition: str,
    column_name_end: str,
):
    """Extract the column name based on the end of the string"""

    import re

    # Use a regular expression to find the column name ending with column_name_end
    # This regex looks for a word that ends with column_name_end
    column_pattern = re.compile(r"\b\w+" + column_name_end + r"\b")
    match = column_pattern.search(sql_definition)

    if match:
        column_extracted_from_sql_definition = match.group(0)
    else:
        column_extracted_from_sql_definition = None

    return column_extracted_from_sql_definition

def _build_freshness_check(
        asset_key: dg.AssetKey,
        table_identifier: str,
        column_name_timestamp_replicated: str,
        organization_name: str,
        freshness_threshold_hours: int,
        ):
    """Factory function to build a freshness check for a given asset."""
    asset_name: str = "_".join(asset_key.path)
    bigquery_resource_key: str = f"bigquery_resource_{organization_name}"
    @dg.asset_check(
            name=f"asset_check_freshness_fivetran_replicated",
            description=f"""
                Ensures the data for {asset_name} is fresher than {freshness_threshold_hours} hours. This test is not enforced for placeholder assets.

                If no new data has come from Fivetran in the last {freshness_threshold_hours} hours, an asset check failure will occur. However, the dagster run will not stop since blocking is disabled. This is because a lack of data might not be an issue. Smaller clients might just not have conversions or new ads placed for a few days. In that case, we still want the job to process.

                The benefit this provides is that we will see in one place (dagster) whether any conforming layer assets are failing these tests. This way we won't have to wait until a client asks us why they're not seeing recent data. This happened with one client over the winter of 24/25. Instead we can proactively learn about the stale data and contact the clients.
                
                This doesn't use build_last_update_freshness_checks because we don't know the external asset identifiers, since they are defined in a non-structured way (pure sql).

                Instead we build custom freshness checks by querying a last updated timestamp of the pre-union conformed sources, which is the earliest point in the pipeline the output schema is structured in a way that we can build factory functions for freshness checks.
            """,
            asset=asset_key,
            blocking=False,
            required_resource_keys={bigquery_resource_key},
            )
    def _freshness_check(context: dg.AssetCheckExecutionContext) -> dg.AssetCheckResult:
        
        bigquery_client = next(getattr(context.resources, bigquery_resource_key))

        if 'placeholder' in asset_name:
            return dg.AssetCheckResult(
                passed=True,
                severity=dg.AssetCheckSeverity.ERROR,
                metadata={"reason": f"Placeholder asset {asset_name} is not expected to have fresh data"}
            )
        
        last_replicated_timestamp = query_last_replicated_timestamp(
            client=bigquery_client,
            table_identifier=table_identifier,
            column_name_timestamp_replicated=column_name_timestamp_replicated,
        )
        if last_replicated_timestamp is None:
            return dg.AssetCheckResult(
                passed=False,
                severity=dg.AssetCheckSeverity.ERROR,
                metadata={"reason": f"No last replicated timestamp found in {table_identifier}"}
            )

        current_time = datetime.now(timezone.utc)
        freshness_threshold = timedelta(hours=freshness_threshold_hours)

        age_of_data = current_time - last_replicated_timestamp

        is_fresh = age_of_data <= freshness_threshold

        metadata = {
            "age_of_data_in_hours": age_of_data.total_seconds() / 3600,
            "current_time": current_time.isoformat(),
            "freshness_threshold": freshness_threshold_hours,
            "last_replicated_timestamp": last_replicated_timestamp.isoformat(),
            "table_identifier": table_identifier,
            "column_name_timestamp_replicated": column_name_timestamp_replicated,
        }

        return dg.AssetCheckResult(
            passed=is_fresh,
            severity=dg.AssetCheckSeverity.ERROR,
            metadata=metadata,
        )

    return _freshness_check
    

def inject_project_id_into_templates_for_one_connector_source(
    templates_dir: str,
    connector_source_name: str,
    gcp_project_id: str,
    gcp_project_id_prod: str,
    ) -> dict[str, str]:
    """
    Injects the gcp project id into Jinja-style templates for a specific connector source.
    Args:
        templates_dir (str): The directory containing the Jinja-style SQL templates. Within this, each template .sql file is under a subdirectory named after the conformed source name.
        connector_source_name (str): The name of the connector source.
    Returns:
        dict[str, str]: A dictionary mapping conformed source names to their corresponding rendered SQL strings.
    Example:
        {
            "ads": "... select * from my_gcp_project_id.adroll.all_ads ...",
            "campaigns": "... select * from my_gcp_project_id.adroll.all_campaigns ...",
        }
    """
    conforming_sql_made_from_templates = {}
    conformed_source_templates_dir = os.path.join(templates_dir, connector_source_name)

    for root, _, files in os.walk(conformed_source_templates_dir):
        for file in files:
            if file.endswith(".sql"):
                # Extract conformed_source_name from the relative path
                rel_path = os.path.relpath(root, conformed_source_templates_dir)
                parts = rel_path.split(os.sep)
                if len(parts) < 1:
                    continue
                conformed_source_name = parts[0]

                # Read the content of the sql file
                with open(os.path.join(root, file), "r") as sql_file:
                    template_sql = sql_file.read()


                # Generate the conforming SQL by injecting the GCP project ID and bigquery_dataset
                template = Template(template_sql)
                conforming_sql = template.render(
                    gcp_project_id=gcp_project_id,
                    gcp_project_id_prod=gcp_project_id_prod,
                    bigquery_dataset=CONSTANT_BIGQUERY_DATASET,
                )

                conforming_sql_made_from_templates[conformed_source_name] = conforming_sql
    
    if not conforming_sql_made_from_templates:
        raise ValueError(f"No conforming sql templates found for connector source '{connector_source_name}'. This may occur if you enable templating for a connector source that doesn't have any templates defined yet. Please add the templates in the directory '{conformed_source_templates_dir}'.")

    return conforming_sql_made_from_templates

def invert_dictionary(
    d: dict[str, dict[str, str]]
) -> dict[str, dict[str, str]]:
    """
    Invert a dictionary of dictionaries, swapping the outer and inner keys.

    This is useful for transforming a structure like:
        {
            "adroll": {"ads": "sql1", "campaigns": "sql2"},
            "facebook": {"ads": "sql3"}
        }
    into:
        {
            "ads": {"adroll": "sql1", "facebook": "sql3"},
            "campaigns": {"adroll": "sql2"}
        }

    Args:
        d (dict[str, dict[str, str]]): The dictionary to invert. Example input:
            {connector: {table: sql}}

    Returns:
        dict[str, dict[str, str]]: The inverted dictionary. Example output:
            {table: {connector: sql}}
    """
    inverted = {}
    for key, sub_dict in d.items():
        for sub_key, value in sub_dict.items():
            inverted.setdefault(sub_key, {})[key] = value
    return inverted

def inject_project_into_templates_for_all_enabled_templated_connector_sources(
    enabled_templated_connector_sources: list[str],
    templates_dir: str,
    gcp_project_id: str,
    gcp_project_id_prod: str,
) -> dict[str, dict[str, str]]:
    """
    Injects the gcp project id into Jinja-style templates for all enabled and templated connector sources.

    Args:
        enabled_templated_connector_sources (list[str]): List of enabled connector sources.
        templates_dir (str): The directory containing the Jinja-style SQL templates. Within this, each template .sql file is under a subdirectory named after the conformed source name.
        gcp_project_id (str): The GCP project ID to inject into the template.

    Returns:
        dict[str, dict[str, str]]: A dictionary mapping conformed source names to dictionaries of conformed source names and their corresponding rendered SQL strings.
    Example:
        {
            "ads": {
                "adroll": "... select * from my_gcp_project_id.adroll.all_ads ...",
                "facebook": "... select * from my_gcp_project_id.facebook.all_ads ...",
            },
            "campaigns": {
                "adroll": "... select * from my_gcp_project_id.adroll.all_campaigns ...",
            },
        }
    """
    Inverted_conforming_sql_made_from_templates = {}
    for connector_source_name in enabled_templated_connector_sources:
        Inverted_conforming_sql_made_from_templates[connector_source_name] = inject_project_id_into_templates_for_one_connector_source(
            templates_dir=templates_dir,
            connector_source_name=connector_source_name,
            gcp_project_id=gcp_project_id,
            gcp_project_id_prod=gcp_project_id_prod,
        )
    
    # Invert from {connector: {table: sql}} to {table: {connector: sql}}
    conforming_sql_made_from_templates: dict[str, dict[str, str]] = invert_dictionary(Inverted_conforming_sql_made_from_templates)
    return conforming_sql_made_from_templates

def inject_project_into_templates_for_organization(
        org_dir: str,
        conforming_sql_dir: str,
        gcp_project_id: str,
        gcp_project_id_prod: str,
    ) -> dict[str, dict[str, str]]:
    """
    Injects the gcp project id into templates for all enabled templated connector sources in the organization.

    This function differs from inject_project_into_templates_for_all_enabled_templated_connector_sources in that it establishes whether any templated connector sources are enabled.

    Args:
        org_dir (str): The directory for the organization containing the conforming SQL templates.
        conforming_sql_dir (str): The base directory containing the conforming SQL templates.
        gcp_project_id (str): The GCP project ID to inject into the template.
        organization_name (str): The name of the organization.
    Returns:
        dict[str, dict[str, str]]: A dictionary mapping conformed source names to dictionaries of conformed source names and their corresponding rendered SQL strings.
    Example:
        {
            "ads": {
                "adroll": "... select * from my_gcp_project_id.adroll.all_ads ...",
                "facebook": "... select * from my_gcp_project_id.facebook.all_ads ...",
            },
            "campaigns": {
                "adroll": "... select * from my_gcp_project_id.adroll.all_campaigns ...",
            },
        }
    """
    # get list of enabled templated connector sources from org dir, enabled_templated_connector_sources.yaml if it exists
    enabled_templated_connector_sources_file: str = os.path.join(org_dir, "enabled_templated_connector_sources.yaml")
    enabled_templated_connector_sources: List[str] = []
    if os.path.isfile(enabled_templated_connector_sources_file):
        with open(enabled_templated_connector_sources_file, "r") as file:
            loaded_yaml = yaml.safe_load(file)
            enabled_templated_connector_sources = loaded_yaml.get("enabled_templated_connector_sources", [])

    conforming_sql_made_from_templates: dict[str, dict[str, str]] = {}
    # If there are enabled templated connector sources, generate conforming SQL from templates
    if enabled_templated_connector_sources:
        conforming_sql_made_from_templates = inject_project_into_templates_for_all_enabled_templated_connector_sources(
            enabled_templated_connector_sources=enabled_templated_connector_sources,
            templates_dir=os.path.join(conforming_sql_dir, "_templates"),
            gcp_project_id=gcp_project_id,
            gcp_project_id_prod=gcp_project_id_prod,
        )
    
    return conforming_sql_made_from_templates

def load_conforming_sql_from_manual_sql_files(
    org_dir: str,
) -> dict[str, dict[str, str]]:
    """
    Loads conforming SQL from manually defined SQL files in the organization's directory.
    Args:
        org_dir (str): The directory for the organization containing the conforming SQL files.
    Returns:
        dict[str, dict[str, str]]: A dictionary mapping conformed source names to dictionaries of connector source names and their corresponding SQL strings.
    Example:
        {
            "ads": {
                "adroll": "... select * from adroll.all_ads ...",
                "facebook": "... select * from facebook.all_ads ...",
            },
            "campaigns": {
                "adroll": "... select * from adroll.all_campaigns ...",
            },
        }
    """
    conforming_sql_made_from_manual_sql_files: dict[str, dict[str, str]] = {}

    # for copilot: org_dir structure is conformed_source_name/connector_source_name.sql
    # write the code below:

    # Walk through the organization directory to find all .sql files
    for root, _, files in os.walk(org_dir):
        for file in files:
            if file.endswith(".sql"):
                # Extract conformed_source_name from the relative path
                rel_path = os.path.relpath(root, org_dir)
                parts = rel_path.split(os.sep)
                if len(parts) < 1:
                    continue
                conformed_source_name = parts[0]

                # Use filename (without extension) as connector_source_name
                connector_source_name = os.path.splitext(file)[0]

                # Read the content of the sql file
                with open(os.path.join(root, file), "r") as sql_file:
                    raw_sql = sql_file.read()

                # Add to the dictionary
                if conformed_source_name not in conforming_sql_made_from_manual_sql_files:
                    conforming_sql_made_from_manual_sql_files[conformed_source_name] = {}
                
                conforming_sql_made_from_manual_sql_files[conformed_source_name][connector_source_name] = raw_sql
    
    return conforming_sql_made_from_manual_sql_files

def resolve_cross_model_references_in_conforming_sql(
        models: list[dict[str, str]],
        organization_name: str,
        ) -> list[dict[str, str]]:
    """
    Resolves cross-model references in conforming SQL, inlining referenced SQL and detecting cycles.
    Reference syntax: {{ ref('conformed_source_name', 'connector_source_name') }}
    Reference syntax example: {{ ref('ads', 'adroll') }}

    Args:
        models: List of dicts, each with 'conformed_source_name', 'connector_source_name', 'conforming_sql'.

    Returns:
        List of dicts with 'conforming_sql' having all references inlined.

    Raises:
        ValueError if a circular reference or missing reference is detected.

    Example:
        models = [
            {
                "conformed_source_name": "ads",
                "connector_source_name": "adroll",
                "conforming_sql": "select * from ( {{ ref('campaigns', 'facebook') }} ) where ad_id is not null"
            },
            {
                "conformed_source_name": "campaigns",
                "connector_source_name": "facebook",
                "conforming_sql": "select * from base_campaigns"
            },
        ]

        resolved = resolve_cross_model_references_in_conforming_sql(models)
        print(resolved[0]["conforming_sql"])
        
        output: select * from (select * from base_campaigns) where ad_id is not null

    """

    # Step 1: index models by unique key for quick lookup
    model_map: dict[tuple[str, str], str] = {
        (m["conformed_source_name"], m["connector_source_name"]): m["conforming_sql"]
        for m in models
    }

    # Step 2: regex to find references like {{ ref('ads', 'adroll') }}
    ref_pattern = re.compile(r"\{\{\s*ref\(\s*'([^']+)'\s*,\s*'([^']+)'\s*\)\s*\}\}")

    # Step 3: build dependency graph {model: [referenced_models]}
    graph: dict[tuple[str, str], list[tuple[str, str]]] = {}
    for model_key, sql in model_map.items():
        refs = ref_pattern.findall(sql)
        graph[model_key] = [(r[0], r[1]) for r in refs]

    # Step 4: detect circular references and topologically sort
    resolved: dict[tuple[str, str], str] = {}
    visiting: set[tuple[str, str]] = set()
    visited: set[tuple[str, str]] = set()

    def dfs(node: tuple[str, str]) -> str:
        """Depth-first search to resolve SQL for a model, inlining references."""
        if node in resolved:
            return resolved[node]
        if node in visiting:
            raise ValueError(f"Conforming layer circular reference detected involving organization {organization_name} and model {node}")
        visiting.add(node)

        sql = model_map.get(node)
        if sql is None:
            raise ValueError(f"Missing model for key {node}")

        # recursively resolve references
        for dep in graph[node]:
            if dep not in model_map:
                raise ValueError(
                    f"Model {node} references missing model {dep}"
                )
            resolved_sql = dfs(dep)
            pattern = rf"\{{\{{\s*ref\(\s*'{dep[0]}'\s*,\s*'{dep[1]}'\s*\)\s*\}}\}}"
            sql = re.sub(pattern, lambda m: f"{resolved_sql}", sql)

        visiting.remove(node)
        visited.add(node)
        resolved[node] = sql
        return sql

    # Step 5: resolve all models
    for key in model_map:
        if key not in resolved:
            dfs(key)

    # Step 6: produce updated list
    updated_models = []
    for m in models:
        key = (m["conformed_source_name"], m["connector_source_name"])
        updated_models.append({
            **m,
            "conforming_sql": resolved[key],
        })

    return updated_models

def compile_conforming_sql(
    organization_row: pd.Series,
    for_unit_test: bool = False,
) -> pd.DataFrame:
    """
    Generates a DataFrame of conforming sql for a given organization. 

    There are two separate hierarchies that determine how this is compiled.

    Within hierarchy 1, the following evaluation occurs for each combination of conformed_source_name+connector_source_name:
    1. if there is a manual SQL file, it is used
    2. otherwise, if there is a template SQL file, it is used (added in IN-881/PR380)

    Hierarchy 2 is evaluated afterwards for each conformed_source_name:
    1. if hierarchy 1 yielded at least one conforming SQL, it is used
    2. otherwise, a placeholder SQL is generated based on the physical_model_dbml_schema

    Args:
        organization_name (str): The name of the organization to search for.
        for_unit_test (bool): Whether this is being run for a unit test. If True, upstream dbt models
            are replaced with their underlying source tables where possible (e.g. pre_conforming dbt refs).
            However, conforming models whose SQL reads from pull-based API replication tables cannot be
            substituted — those tables only exist after a human or deployment has explicitly materialized
            the replication asset. Doing this for every CI run for every client is not viable.
            Callers (e.g. test_manual_pre_union_conformed_sources_have_required_schema) should detect and
            skip such rows using extract_api_replication_deps_from_conforming_sql.

    Returns:
        pd.DataFrame: A DataFrame containing the pre-union conformed sources information.
    """

    organization_name: str = organization_row["organization_name"]
    gcp_project_id_prod: str = organization_row["organization_conformed_source_gcp_project_id"]
    gcp_project_id_resolved: str = organization_row["resolved_gcp_project_id"]


    # Create the path to the directory containing the organization's conforming SQL files
    current_dir: str = os.path.dirname(os.path.abspath(__file__))
    conforming_sql_dir: str = os.path.join(current_dir, "conforming_sql")
    org_dir: str = os.path.join(conforming_sql_dir, organization_name)

    # If the organization directory doesn't exists, return an empty DataFrame.
    if not os.path.isdir(org_dir):
        print(f"The directory for organization '{organization_name}' does not exist. Skipping.")
        return pd.DataFrame()
    
    conforming_sql_made_from_placeholders: dict[str, str] = {
        table_name: generate_placeholder_sql_from_dbml_schema(table_name, [col[0] for col in columns]) for table_name, columns in physical_model_dbml_schema.items()
    }

    conforming_sql_made_from_templates: dict[str, dict[str, str]] = inject_project_into_templates_for_organization(
        org_dir=org_dir,
        conforming_sql_dir=conforming_sql_dir,
        gcp_project_id=gcp_project_id_resolved,
        gcp_project_id_prod=gcp_project_id_prod,
    )

    conforming_sql_made_from_manual_sql_files: dict[str, dict[str, str]] = load_conforming_sql_from_manual_sql_files(
        org_dir=org_dir,
    )

    conformed_source_pre_union_data_before_cross_model_rendered: List[dict[str, str]] = []

    # Hierarchy 1: iterate through the physical_model_dbml_schema to generate conforming SQL (one or many) for each conformed source
    handled_keys = set()

    for conformed_source_name, columns in physical_model_dbml_schema.items():
        matched_records = []

        manual_sqls = conforming_sql_made_from_manual_sql_files.get(conformed_source_name, {})
        template_sqls = conforming_sql_made_from_templates.get(conformed_source_name, {})

        for connector_source_name in set(manual_sqls.keys()) | set(template_sqls.keys()):
            key = (conformed_source_name, connector_source_name)

            if connector_source_name in manual_sqls:
                matched_records.append({
                    "conformed_source_name": conformed_source_name,
                    "connector_source_name": connector_source_name,
                    "conforming_sql": manual_sqls[connector_source_name],
                    "generation_method": "manual_sql",
                })
            elif connector_source_name in template_sqls:
                matched_records.append({
                    "conformed_source_name": conformed_source_name,
                    "connector_source_name": connector_source_name,
                    "conforming_sql": template_sqls[connector_source_name],
                    "generation_method": "template_sql",
                })

            handled_keys.add(conformed_source_name)

        if matched_records:
            conformed_source_pre_union_data_before_cross_model_rendered.extend(matched_records)

    # Hierarchy 2: add placeholder SQL for any conformed_source_name not already handled
    for conformed_source_name in physical_model_dbml_schema:
        if conformed_source_name not in handled_keys:
            conformed_source_pre_union_data_before_cross_model_rendered.append({
                "conformed_source_name": conformed_source_name,
                "connector_source_name": "placeholder",
                "conforming_sql": conforming_sql_made_from_placeholders[conformed_source_name],
                "generation_method": "placeholder_sql",
            })

    # IN-1199 resolve cross-model references
    conformed_source_pre_union_data: List[dict[str, str]] = resolve_cross_model_references_in_conforming_sql(
        models=conformed_source_pre_union_data_before_cross_model_rendered,
        organization_name=organization_name,
    )

    for row in conformed_source_pre_union_data:

        # Inject GCP project IDs and bigquery_dataset into all conforming_sql after cross-model references are resolved.
        # {{ gcp_project_id }} resolves to the environment-specific project (staging or prod).
        # {{ gcp_project_id_prod }} always resolves to the prod project (used by legacy Fivetran templates
        # whose source data always lands in prod, even when dagster is running in staging).
        template = Template(row["conforming_sql"])
        row["conforming_sql"] = template.render(
            gcp_project_id=gcp_project_id_resolved,
            gcp_project_id_prod=gcp_project_id_prod,
            bigquery_dataset=CONSTANT_BIGQUERY_DATASET,
        )

        if for_unit_test:
            row["conforming_sql"] = replace_upstream_dbt_models_with_underlying_sources(row["conforming_sql"])


    # Convert the list of dictionaries to a DataFrame
    conformed_source_pre_union_df = pd.DataFrame(conformed_source_pre_union_data)
    return conformed_source_pre_union_df

def replace_upstream_dbt_models_with_underlying_sources(sql_string: str) -> str:
    """
    Replaces references to upstream dbt models in the SQL string with their underlying source tables.
    This is necessary because otherwise we would need to materialize the dbt models before we can run a dry run query to extract the schema.
    These dbt models exist to SAVE on compute, so we don't want to materialize them just for testing.

    Note: this approach only works while none of the upstream dbt models change the schema of the underlying source tables.
    Args:
        sql_string (str): The SQL string to replace the dbt models in.
    Returns:
        str: The SQL string with the dbt models replaced.

    Example:
        Input SQL string (after Jinja rendering):
            select * from `my-gcp-project.dev_amir_pre_conforming.pc_dispatch__snowcatcloud_events`
        Output SQL string:
            select * from `snowcatcloud-insighta.snowcatcloud.events`
    """
    return re.sub(
        r"[\w-]+\.[\w_]+_pre_conforming\.pc_dispatch__snowcatcloud_events",
        "snowcatcloud-insighta.snowcatcloud.events",
        sql_string,
    )

def build_conformed_source_pre_union_multi_assets() -> List[dg.AssetsDefinition]:
    """
    Build multi-assets for each organization's pre-union conformed sources.
    """
    list_conformed_sources_pre_union_multi_assets: List[dg.AssetsDefinition] = []
    for organization_index, organization_row in organizations_df.iterrows():
        multi_asset = build_conformed_source_pre_union_multi_asset_for_one_org(organization_row=organization_row)
        if multi_asset is not None:
            list_conformed_sources_pre_union_multi_assets.append(multi_asset)
    
    return list_conformed_sources_pre_union_multi_assets

def extract_api_replication_deps_from_conforming_sql(
    organization_name: str,
    conforming_sql: str,
) -> list[dg.AssetKey]:
    """
    Scans a rendered conforming SQL string for references to pull-based API replication tables
    and returns the corresponding Dagster asset keys.

    The convention in api_replication.py is that every replication table lands in a BigQuery
    dataset named ``{BIGQUERY_DATASET}_replication_{connector_source}``. After Jinja rendering,
    the conforming SQL therefore contains a literal substring of the form:

        {BIGQUERY_DATASET}_replication_{connector_source}.{table_name}

    Whitespace (including newlines) around the dot is tolerated, which matters for SQL that is
    formatted across lines, e.g. in a CTE source clause:

        select * from {{ gcp_project_id }}.{{ bigquery_dataset }}_replication_mountain
            .non_event_tracker_events

    After rendering with ``bigquery_dataset=CONSTANT_BIGQUERY_DATASET`` this becomes:

        select * from my-gcp-project.dev_amir_replication_mountain
            .non_event_tracker_events

    The regex ``{BIGQUERY_DATASET}_replication_(\\w+)\\s*\\.\\s*(\\w+)`` then extracts:
        - Group 1 → ``mountain``      (connector_source)
        - Group 2 → ``non_event_tracker_events``  (table_name)

    These map directly to the asset key registered by ``create_api_replication_asset``:
        ``[organization_name, "replication", "api", connector_source, table_name]``

    Args:
        organization_name: The organization name (used as the first segment of the asset key).
        conforming_sql: A fully Jinja-rendered conforming SQL string.

    Returns:
        A deduplicated list of ``dg.AssetKey`` objects, one per unique
        ``(connector_source, table_name)`` pair found in the SQL.
        Returns an empty list if no replication references are found.

    Example:
        >>> sql = \"\"\"
        ...     select * from my-project.dev_amir_replication_mountain
        ...         .non_event_tracker_events
        ... \"\"\"
        >>> extract_api_replication_deps_from_conforming_sql("osbornhomecare", sql)
        [AssetKey(["osbornhomecare", "replication", "api", "mountain", "non_event_tracker_events"])]
    """
    replication_pattern = re.compile(
        r"\b" + re.escape(CONSTANT_BIGQUERY_DATASET) + r"_replication_(\w+)\s*\.\s*(\w+)"
    )
    matches = replication_pattern.findall(conforming_sql)
    return [
        dg.AssetKey([organization_name, "replication", "api", connector_source, table_name])
        for connector_source, table_name in dict.fromkeys(matches)  # deduplicate while preserving order
    ]


def build_deps(
    organization_name: str,
    conformed_source_name: str,
    conforming_sql: str,
) -> list[dg.AssetKey]:
    """
    Build the dependencies for a given conformed source.

    For web_events, we depend on the pc_dispatch__snowcatcloud_events asset in the pre_conforming layer,
    since that's where the raw data lands and we need it to be there before we can create the pre-union
    conformed source.

    For data populated through pull-based api replication we know the dependencies by dataset and table
    name, so we can directly depend on the pre-union conformed source of that connector source by checking
    if that substring exists in the pre-union conformed source sql definition.

    For other conformed sources, we don't have any dependencies yet.
    """
    if conformed_source_name == "web_events":
        return [dg.AssetKey([organization_name, "pre_conforming", "pc_dispatch__snowcatcloud_events"])]

    return extract_api_replication_deps_from_conforming_sql(organization_name, conforming_sql)

def build_conformed_source_pre_union_multi_asset_for_one_org(
    organization_row: pd.Series,
) -> Optional[dg.AssetsDefinition]:
    """
    Build a multi-asset for an organization's pre-union conformed sources.
    """
    organization_name: str = organization_row["organization_name"]

    organization_conformed_sources_pre_union_df: pd.DataFrame = compile_conforming_sql(
        organization_row=organization_row
    )
    # If org has no pre-union conformed sources, skip the asset creation
    if organization_conformed_sources_pre_union_df.empty:
        return None
    list_of_asset_specs: List[dg.AssetSpec] = []
    sql_to_generate_all_conformed_sources_pre_union_of_organization: str = f""

    key_prefix: List[str] = [
        organization_name,
        'conformed_sources',
        'pre_union',
    ]
    dataset_id: str = f"{organization_row['resolved_gcp_project_id']}.{CONSTANT_BIGQUERY_DATASET}_conformed_sources"
    for (
        conformed_source_pre_union_index,
        organization_conformed_source_pre_union_row,
    ) in organization_conformed_sources_pre_union_df.iterrows():
        asset_name: str = f"{organization_conformed_source_pre_union_row['conformed_source_name']}__{organization_conformed_source_pre_union_row['connector_source_name']}"
        table_identifier: str = f"`{dataset_id}.{asset_name}`"
        conformed_source_name: str = organization_conformed_source_pre_union_row['conformed_source_name']
        connector_source_name: str = organization_conformed_source_pre_union_row['connector_source_name']
        conforming_sql: str = organization_conformed_source_pre_union_row['conforming_sql']

        sql_to_generate_conformed_source_pre_union: str = f"""
            create or replace view {table_identifier}
            as
            {conforming_sql}
        """
        hashed_sql_to_generate_conformed_source_pre_union = md5(sql_to_generate_conformed_source_pre_union.encode()).hexdigest()
        
        sql_to_generate_all_conformed_sources_pre_union_of_organization += sql_to_generate_conformed_source_pre_union + ";\n\n"

        metadata = {
            "conformed source": organization_conformed_source_pre_union_row[
                "conformed_source_name"
            ],
            "connector source": connector_source_name,
            "table identifier": table_identifier,
            "sql definition": dg.MetadataValue.md(f"```sql\n{sql_to_generate_conformed_source_pre_union}\n```"),
            "sql to generate all of organization's pre-union conformed sources": dg.MetadataValue.md(f"```sql\n{sql_to_generate_all_conformed_sources_pre_union_of_organization}\n```"),
        }

        asset_spec: dg.AssetSpec = dg.AssetSpec(
            key=dg.AssetKey([*key_prefix, asset_name]),
            description=f"BigQuery table of organization {organization_name}'s '{organization_conformed_source_pre_union_row['connector_source_name']}' part of conformed source '{organization_conformed_source_pre_union_row['conformed_source_name']}'",
            code_version=hashed_sql_to_generate_conformed_source_pre_union,
            kinds={'bigquery'},
            metadata=metadata,
            deps=build_deps(
                organization_name=organization_name,
                conformed_source_name=conformed_source_name,
                conforming_sql=conforming_sql,
            )
        )
        list_of_asset_specs.append(asset_spec)
    bigquery_resource_key: str = f"bigquery_resource_{organization_name}"
    
    @dg.multi_asset(
        group_name=organization_name,
        name=f"{organization_name}__conformed_sources_pre_union",
        specs=list_of_asset_specs,
        required_resource_keys={bigquery_resource_key},
    )
    def _multi_asset(
        context: dg.AssetExecutionContext,
    ) -> Generator[dg.MaterializeResult, None, None]:
        """
        Multi-asset for all pre-union conformed sources of an organization.
        """
        bigquery_client = next(getattr(context.resources, bigquery_resource_key))

        safe_ensure_dataset_exists(
            context=context,
            client=bigquery_client,
            dataset_id=dataset_id,
        )

        context.log.info(f"Attempting to create all pre-union conformed sources for organization: {organization_name}")
        execute_query(bigquery_client, sql_to_generate_all_conformed_sources_pre_union_of_organization)
        context.log.info(f"All tables created for organization: {organization_name}")

        for spec in list_of_asset_specs:
            yield dg.MaterializeResult(
                asset_key=spec.key,
            )

    return _multi_asset

def build_conformed_source_pre_union_asset_checks() -> List[dg.AssetsDefinition]:
    """
    Build asset checks for each organization's pre-union conformed sources (a.k.a. conforming sql).

    """
    asset_checks_conformed_sources_pre_union: List[dg.AssetsDefinition] = []
    for organization_index, organization_row in organizations_df.iterrows():
        organization_name: str = organization_row["organization_name"]
        freshness_threshold_hours_orders: int = organization_row.get("conforming_orders_models_freshness_threshold_hours", 48) # improvement opportunity: after release/1.7.7 this can be changed to organization_row["conforming_orders_models_freshness_threshold_hours"]
        freshness_threshold_hours_non_orders: int = 48
        organization_conformed_sources_pre_union_df: pd.DataFrame = compile_conforming_sql(
            organization_row=organization_row
        )
        for (
            conformed_source_pre_union_index,
            organization_conformed_source_pre_union_row,
        ) in organization_conformed_sources_pre_union_df.iterrows():
            list_high_throughpout_conformed_sources_post_union = [ # we only test freshness for certain conformed sources
                "orders",
                "web_events",
            ]
            conformed_source_name: str = organization_conformed_source_pre_union_row['conformed_source_name']
            if conformed_source_name in list_high_throughpout_conformed_sources_post_union:

                key_prefix: List[str] = [
                    organization_name,
                    'conformed_sources',
                    'pre_union',
                ]
                asset_name: str = f"{organization_conformed_source_pre_union_row['conformed_source_name']}__{organization_conformed_source_pre_union_row['connector_source_name']}"

                dataset_id: str = f"{organization_row['resolved_gcp_project_id']}.{CONSTANT_BIGQUERY_DATASET}_conformed_sources"
                table_identifier: str = f"`{dataset_id}.{asset_name}`"
                
                column_name_timestamp_replicated = extract_column_name_based_on_end_of_string(
                    sql_definition=organization_conformed_source_pre_union_row["conforming_sql"],
                    column_name_end="_timestamp_replicated",
                )

                asset_key = dg.AssetKey([*key_prefix, asset_name])
                asset_check_freshness_to_append = _build_freshness_check(
                    asset_key=asset_key,
                    table_identifier=table_identifier,
                    column_name_timestamp_replicated=column_name_timestamp_replicated,  # type: ignore
                    organization_name=organization_name,
                    freshness_threshold_hours=freshness_threshold_hours_orders if conformed_source_name == "orders" else freshness_threshold_hours_non_orders,
                )
                asset_checks_conformed_sources_pre_union.append(asset_check_freshness_to_append)

    return asset_checks_conformed_sources_pre_union

def build_conformed_source_post_union_multi_assets() -> List[dg.AssetsDefinition]:
    """
    Build multi-assets for each organization's post-union conformed sources e.g ads.
    """
    list_conformed_sources_post_union_multi_assets: List[dg.AssetsDefinition] = []
    for organization_index, organization_row in organizations_df.iterrows():
        multi_asset = build_conformed_source_post_union_multi_asset_for_one_org(organization_row=organization_row)
        if multi_asset is not None:
            list_conformed_sources_post_union_multi_assets.append(multi_asset)
    
    return list_conformed_sources_post_union_multi_assets

def build_conformed_source_post_union_multi_asset_for_one_org(
    organization_row: pd.Series,
) -> Optional[dg.AssetsDefinition]:
    """
    Build a multi-asset for an organization's post-union conformed sources e.g. ads.
    """
    organization_name: str = organization_row["organization_name"]
    organization_conformed_sources_pre_union_df: pd.DataFrame = compile_conforming_sql(
        organization_row=organization_row
    )
    # If org has no conformed_sources_pre_union, skip the asset creation
    if organization_conformed_sources_pre_union_df.empty:
        return None
    
    list_of_asset_specs: List[dg.AssetSpec] = []
    
    sql_to_generate_all_conformed_sources_post_union_of_organization: str = f""
    dataset_id: str = f"{organization_row['resolved_gcp_project_id']}.{CONSTANT_BIGQUERY_DATASET}_conformed_sources"
    for conformed_source_name in physical_model_dbml_schema:
        # Filter conformed_sources_pre_union to the conformed_source_name
        conformed_sources_pre_union_filtered_to_conformed_source_name_df = organization_conformed_sources_pre_union_df[
            organization_conformed_sources_pre_union_df["conformed_source_name"]
            == conformed_source_name
        ]

        # Build the SQL to union all the pre-union conformed sources
        asset_name: str = f"{conformed_source_name}"
        table_identifier: str = f"`{dataset_id}.{asset_name}`"
        sql_parts_for_conformed_source_post_union: list[str] = [
            f"select * from `{dataset_id}.{organization_conformed_source_pre_union['conformed_source_name']}__{organization_conformed_source_pre_union['connector_source_name']}`"
            for _, organization_conformed_source_pre_union in conformed_sources_pre_union_filtered_to_conformed_source_name_df.iterrows()
        ]

        sql_one_conformed_source_post_union: str = f"""
            create or replace view {table_identifier}
            as
            select * from (
                {" union all ".join(sql_parts_for_conformed_source_post_union)}
            )
        """

        hashed_sql_to_generate_conformed_source_post_union = md5(sql_one_conformed_source_post_union.encode()).hexdigest()

        sql_to_generate_all_conformed_sources_post_union_of_organization += sql_one_conformed_source_post_union + ";\n\n"

        metadata = {
            "conformed source": conformed_source_name,
            "connector sources": str(
                [
                    organization_conformed_source_pre_union["connector_source_name"]
                    for _, organization_conformed_source_pre_union in conformed_sources_pre_union_filtered_to_conformed_source_name_df.iterrows()
                ]
            ),
            "table identifier": table_identifier,
            "sql definition": dg.MetadataValue.md(f"```sql\n{sql_one_conformed_source_post_union}\n```"),
            "sql to generate all of organization's post-union conformed sources": dg.MetadataValue.md(f"```sql\n{sql_to_generate_all_conformed_sources_post_union_of_organization}\n```"),
        }

        asset_spec: dg.AssetSpec = dg.AssetSpec(
            key=dg.AssetKey(
                [
                    organization_name,
                    'conformed_sources',
                    'post_union',
                    asset_name,
                ]
            ),
            description=f"BigQuery table of organization {organization_name}'s conformed source '{conformed_source_name}'. It is designed to be consumed by dbt as a 'source'",
            code_version=hashed_sql_to_generate_conformed_source_post_union,
            metadata=metadata,
            deps=[
                dg.AssetKey(
                    [
                        organization_name,
                        "conformed_sources",
                        "pre_union",
                        f'{organization_conformed_source_pre_union["conformed_source_name"]}__{organization_conformed_source_pre_union["connector_source_name"]}',
                    ]
                )
                for _, organization_conformed_source_pre_union in conformed_sources_pre_union_filtered_to_conformed_source_name_df.iterrows()
            ],
            kinds={'bigquery'},
        )
        list_of_asset_specs.append(asset_spec)

    bigquery_resource_key: str = f"bigquery_resource_{organization_name}"
    @dg.multi_asset(
        group_name=organization_name,
        name=f"{organization_name}__conformed_sources_post_union",
        specs=list_of_asset_specs,
        required_resource_keys={bigquery_resource_key},
    )
    def _multi_asset(
        context: dg.AssetExecutionContext,
    ) -> Generator[dg.MaterializeResult, None, None]:
        """
        Multi-asset for all post-union conformed sources of an organization.
        """
        bigquery_client = next(getattr(context.resources, bigquery_resource_key))

        context.log.info(f"Attempting to create all post-union conformed sources for organization: {organization_name}")
        execute_query(bigquery_client, sql_to_generate_all_conformed_sources_post_union_of_organization)
        context.log.info(f"All post-union conformed sources created for organization: {organization_name}")

        for spec in list_of_asset_specs:
            yield dg.MaterializeResult(
                asset_key=spec.key,
            )

    return _multi_asset

asset_checks_conformed_sources_pre_union: List[dg.AssetsDefinition] = build_conformed_source_pre_union_asset_checks()
list_conformed_sources_pre_union_multi_assets: List[dg.AssetsDefinition] = build_conformed_source_pre_union_multi_assets()
list_conformed_sources_post_union_multi_assets: List[dg.AssetsDefinition] = build_conformed_source_post_union_multi_assets()